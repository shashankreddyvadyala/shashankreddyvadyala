'''
This module creates a FAISS vectordb locally in order to help retrieve similar examples for few-shot learning.
'''

import argparse
import boto3
import json
import os

from langchain.embeddings import BedrockEmbeddings
from langchain.vectorstores import FAISS

from text2sql.conf import config as cfg


def create_vector_db(db_name):
    """Create FAISS vectorDB for a given database."""
    
    db_cfg = cfg.DATABASES[db_name]
    embed_model_id = cfg.EMBED_MODEL_IDs[0] # "amazon.titan-embed-g1-text-02"
    faiss_dict_examples_path = db_cfg["few_shot"]["golden_examples_path"]
    faiss_index_dir = db_cfg["few_shot"]["vectordb_dir"]

    # Create embeddings model
    bedrock_runtime = boto3.client("bedrock-runtime")
    llm_embed = BedrockEmbeddings(client=bedrock_runtime, model_id=embed_model_id)

    # Load Dictionary of examples
    with open(faiss_dict_examples_path, "r") as fp:
        few_shot_examples = json.load(fp)

    questions = list(few_shot_examples.keys())

    # If not existing, Create embeddings for the sample questions and save
    if not os.path.exists(faiss_index_dir):
        os.makedirs(faiss_index_dir, exist_ok=False)

        db = FAISS.from_texts(questions, llm_embed)
        db.save_local(faiss_index_dir)
    else:
        raise ValueError(f"{faiss_index_dir} already exists. Remove first to create a new one.")
        
    print(f'FAISS VectorDB successfully created at {faiss_index_dir}')
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Create vectordb.')
    
    parser.add_argument('--database_name', type=str, help='Name of the database. The name has to be the same as in config.py')
    
    args = parser.parse_args()
    
    db_name = args.database_name

    create_vector_db(db_name)
