"""
The config contains important settings to run the Text-to-SQL Streamlit App.
"""

from text2sql.conf.prompts import *

# Amazon Bedrock Models for SQL generation
SQL_MODEL_IDs = ['anthropic.claude-v2', 'anthropic.claude-v2:1', 'anthropic.claude-instant-v1']

# LLM Model Config
SQL_MODEL_CONFIG = {
    "max_tokens_to_sample": 512,
    "temperature": 0,
    "top_p": 1,
    "top_k": 50,
    "stop_sequences": ["\n\nHuman:", "</function_calls>"],
}

# Embedding models for few-shot learning
EMBED_MODEL_IDs = ["amazon.titan-embed-g1-text-02"]

# Prompt template
PROMPT = PROMPT_V1

# User feedback file path
USER_FEEDBACK_PATH = 'outputs/user_feedback.txt'

# Code Mappings (e.g., gender, race, etc.) to be used with tools
CODE_MAPPING_PATHS = {
    "gender": '../data/code_mappings/gender.json',
    "race": '../data/code_mappings/race.json',
    "state": '../data/code_mappings/state.json',
}

# Databases and their corresponding configs
DATABASES = {
    # DESynPUF database
    "DESynPUF": {
        # Path for tables description file
        "tables_desc_path": '../data/databases/synpuf/tables_description.csv',
        # Path for column descriptions file
        "columns_desc_path": '../data/databases/synpuf/columns_description.csv',
        # Path for the tables DDL statements and sample data for each table
        "tables_info_path": '../data/databases/synpuf/db_tables_info.txt',
        # Few shot learning configs
        "few_shot": {
            # Directory containing VectorDB files 
            "vectordb_dir": '../data/databases/synpuf/faiss_index/',
            # Path for golden examples with question-SQL pairs
            "golden_examples_path": '../data/databases/synpuf/few_shot_examples.json',
            #Number of few shot examples to be used
            "num_few_shot_examples": 3,
        },
        # Redshift parameters and credentials for database connection
        "redshift_params": {
            # Database schema
            "schema_name": 'rwdex_raw_synpuf',
            # Database host
            "host": "redshift-synpuf-db-cluster-1.ckbiikj73zqo.us-east-1.redshift.amazonaws.com",
            # Database host
            "port": 5439,
            # Database name
            "database": 'dev',
            # Database username
            "username": "awsuser",
            # Database password
            "password": "Merck123",
        },
    },
    # Similar config for another database
    "Premier_Hospital_Database": {
        "tables_desc_path": '../data/databases/premier/tables_description.csv',
        "columns_desc_path": '../data/databases/premier/columns_description.csv',
        "tables_info_path": '../data/databases/premier/db_tables_info.txt',
        "few_shot": {
            "vectordb_dir": '../data/databases/premier/faiss_index/',
            "golden_examples_path": '../data/databases/premier/few_shot_examples.json',
            "num_few_shot_examples": 0,
        },
        "redshift_params": {
            "schema_name": 'rwdex_raw_premier_hospital',
            "host": "redshift-premier-db-cluster-1.ckbiikj73zqo.us-east-1.redshift.amazonaws.com",
            "port": 5439,
            "database": 'dev',
            "username": "awsuser",
            "password": "Merck123",
        },
    },

}