"""
Copyright 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.

This is AWS Content subject to the terms of the Customer Agreement
----------------------------------------------------------------------
File content:
    The file contains utility functions to be used when building the LLM application.
"""

import os
import boto3
import re
import pandas as pd
from IPython.display import display, HTML

from langchain.vectorstores import FAISS
from langchain.llms.bedrock import Bedrock
from langchain.utilities import SQLDatabase

import text2sql.conf.config as cfg
from text2sql.lib.function_calls import create_prompt, run_loop


def get_bedrock_llm(model_id, model_config, verbose=False):
    """Creates Bedrock LLM based on the given model-id and config."""
    bedrock_runtime = boto3.client("bedrock-runtime")
    llm = Bedrock(
        client=bedrock_runtime,
        model_id=model_id,
        verbose=verbose,
        model_kwargs=model_config,
    )
    return llm


def extract_xml(tags, text):
    """Extract content enclosed in XML tags and remove newline symbols within the tag."""
    # First, extract content between the tags
    for tag in tags:
        xml_pattern = f"(?:<{tag}.*?>)(.*?)(?:<\\/{tag}>)"
        extracted_content = re.findall(xml_pattern, text, re.DOTALL)

        if extracted_content:
            # Then, remove newline symbols from the extracted content
            return extracted_content[0].strip()

    return None


def get_llm_output(row0, llm, prompt0, inputs0, question_col, gt_sql_executed_col):
    """Gets the generated SQL and question summary based on the input question and whether the GT SQL is executable."""
    row = row0.copy()
    inputs = inputs0.copy()

    question = row[question_col]
    inputs["question"] = question

    sql = "GT SQL Non-Executable"
    summary = ""
    if row[gt_sql_executed_col]:
        prompt = create_prompt(prompt0, inputs)
        response = run_loop(llm, prompt)
        sql = extract_xml(tags=["sql"], text=response)
        summary = extract_xml(tags=["summary"], text=response)

    row[f"sql_predicted"] = sql
    row[f"question_summary"] = summary
    return row


def get_redshift_db(redshift_params):
    """Connect to Redshift and get database object"""
    redshift_endpoint = f"redshift+psycopg2://{redshift_params['username']}:{redshift_params['password']}@{redshift_params['host']}:{redshift_params['port']}/{redshift_params['database']}"
    db = SQLDatabase.from_uri(redshift_endpoint,  schema=f"{redshift_params['schema_name']}")
    return db


def get_db_tables_info(redshift_params, tables_info_path):
    """
    Gets the table schema with create table statements and sample rows from each table.
    """
    if not os.path.exists(tables_info_path):
        print('Getting tables info from Redshift DB...\n')
        db = get_redshift_db(redshift_params)
        
        table_names = db.get_usable_table_names()
        tables_info = db.get_table_info(table_names=table_names)
        with open(tables_info_path, 'w') as fp:
            fp.write(tables_info)
    else:
        print('Tables Info already exists! Loading...\n')
        with open(tables_info_path, 'r') as fp:
            tables_info = fp.readlines()
        tables_info = ''.join(tables_info)

    return tables_info


def get_column_descriptions(col_desc_path, save_xml=True):
    """Get column descriptions in xml format."""
    xml_path = col_desc_path.replace('.csv', '.xml')

    if os.path.exists(xml_path):
        with open(xml_path, 'r') as fp:
            print('Loading existing XML file...\n')
            desc_xml = fp.readlines()
        desc_xml = ''.join(desc_xml)
        return desc_xml

    print('Loading and creating XML file...\n')
    df = pd.read_csv(col_desc_path)
    expected_cols = ["column_name", "column_description", "table_name"]
    if set(expected_cols) != set(df.columns):
        raise ValueError(f'Column names are different! Columns should be: {expected_cols}')

    desc_xml = df.to_xml(index=False)

    #remove the first line
    desc_xml = desc_xml.split('\n', 1)[1]

    if save_xml:
        with open(xml_path, 'w') as fp:
            fp.write(desc_xml)

    return desc_xml


def print_gt_and_pred_sql(row, question_column, gt_column, pred_column, summary_column):
    """Print both the ground-truth and predicted SQL queries."""

    gt_sql = row[gt_column]
    if "sqlite" in gt_column:
        gt_sql = gt_sql.replace("rwdex_raw_synpuf.", "")

    print(f"QA ID: {row['qa_id']}")
    print("-" * 30)

    display(HTML(f"<font color=blue>QUESTION: {row[question_column]}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=green>SQL(GT): {gt_sql}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=gray>SQL(PRED): {row[pred_column]}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=gray>QUESTION SUMMARY: {row[summary_column]}</font>"))
    print("-" * 30)
    

def build_few_shot_examples(golden_examples, question, retriever):
    """Gets few shot examples for a given question."""
    similar_questions = [
        content.page_content for content in retriever.get_relevant_documents(question)
    ]
    
    similar_questions = sorted(similar_questions, key=len)
    few_shot_sql = [golden_examples[question] for question in similar_questions]

    output = ""

    for q, s in zip(similar_questions, few_shot_sql):
        output += f"<example-question>{q}</example-question>"
        output += f"\n<example-sql>\n{s}\n</example-sql>\n\n"

    return output


def get_vertordb_retriever(llm, vectordb_dir, num_few_shot_examples, golden_questions=None):
    """Gets FAISS VectorDB retriever. VectorDB is created if not existing."""
    
    # questions = list(few_shot_examples.keys())

    try:
        # Load Vector DB and Create a retriever
        vector_db = FAISS.load_local(num_few_shot_examples, llm)
    except:
        # Create embeddings for the sample questions and save
        if golden_questions is None:
            raise ValueError('Empty golden input questions. Add a list of questions to create vectorDB.')

        vector_db = FAISS.from_texts(golden_questions, llm)
        vector_db.save_local(vectordb_dir)

    retriever = vector_db.as_retriever(search_kwargs={"k": num_few_shot_examples})
    return retriever
