"""
Copyright 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.

This is AWS Content subject to the terms of the Customer Agreement
----------------------------------------------------------------------
File content:
    The file creates tools to be used by the LLMs.
"""

import json
import os

import text2sql.conf.config as cfg

# Create functions to be called by LLM
def get_gender_code(gender):
    """Get code for a given gender/sex. E.g., male and female."""
    with open(cfg.CODE_MAPPING_PATHS['gender'], 'r') as fp:
        mappings = json.load(fp)

    if isinstance(gender, str):
        gender = gender.lower()
        code = mappings.get(gender, None)
        return code
    return None


def get_race_code(race):
    """Get code for a given race/ethnicity."""
    with open(cfg.CODE_MAPPING_PATHS['race'], 'r') as fp:
        mappings = json.load(fp)

    if isinstance(race, str):
        race = race.lower()
        if race not in mappings.keys():
            race = 'others'
        code = mappings.get(race, None)
        return code
    return None


def get_state_code(state):
    """Get code for a given United States state."""
    with open(cfg.CODE_MAPPING_PATHS['state'], 'r') as fp:
        mappings = json.load(fp)

    if isinstance(state, str):
        state = state.upper()
        if state not in mappings.keys():
            state = 'others'
        code = mappings.get(state, None)
        return code
    return None


## Add description of each function.
get_gender_code_description = """
<tool_description>
<tool_name>get_gender_code</tool_name>
<description>Returns code for a given gender/sex.</description>
<parameters>
<parameter>
<name>gender</name>
<type>string</type>
<description>The gender/sex value. This is given as a string.</description>
</parameter>
</parameters>
</tool_description>
"""


get_race_code_description = """
<tool_description>
<tool_name>get_race_code</tool_name>
<description>Returns code for a given race/ethnicity.</description>
<parameter>
<name>race</name>
<type>string</type>
<description>The race/ethnicity value. This is given as a string.</description>
</parameter>
</parameters>
</tool_description>
"""


get_state_code_description = """
<tool_description>
<tool_name>get_state_code</tool_name>
<description>Returns code for a given United States state.</description>
<parameters>
<parameter>
<name>state</name>
<type>string</type>
<description>The state value. This is given as a string.</description>
</parameter>
</parameters>
</tool_description>
"""

#Get list of all tools
list_of_tools_specs = [
        get_gender_code_description,
        get_race_code_description,
        get_state_code_description
]