sql_generation_prompt_template_basic = """


Human: Given an input question, create a syntactically correct query to run. Use the following format:

Question: <question>"Question here"</question>
SQLQuery: <generated_sql>"SQL Query to run"</generated_sql>

Question from user:

<question>
{USER_QUESTION}
</question>


Assistant:
"""

sql_generation_prompt_template = """


Human: You are an experienced data scientist for Merck. You are working with medical records and databases. Their columns names and descriptions can be found in the <table_info></table_info> tags.

<table_info>
{TABLE_INFO}
</table_info>

Given an input question, create a syntactically correct query to run. Use the following format:

Question: <question>"Question here"</question>
SQLQuery: <generated_sql>"SQL Query to run"</generated_sql>

Some examples of SQL queries that correspond to questions are:

<few_shot_examples>
{FEW_SHOT_EXAMPLES}
</few_shot_examples>

Question from user:

<question>
{USER_QUESTION}
</question>


Assistant:
"""
