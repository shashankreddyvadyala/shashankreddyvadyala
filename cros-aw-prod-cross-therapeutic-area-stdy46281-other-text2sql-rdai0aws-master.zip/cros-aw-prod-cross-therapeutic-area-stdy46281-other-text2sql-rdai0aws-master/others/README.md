# aws-merck-text2sql-genai
This repo contains all the source code related to AWS/Merck Text2SQL GenAI Project.

### Initialize SQLite Tables from SynPUF CSVs
```
export PYTHONPATH=.
python src/db_init.py
```

or run `PYTHONPATH=. python src/db_init.py`

`carriers_claims` table is not populated by default but can be initiated by adding a flag

`python src/db_init.py --carrier` 

WARNING: It takes long time to generate the `carriers_claims` table, also we probably won't need it at the moment. 


### Spider Hardness Eval
Make sure you clone the [spider repo](https://github.com/taoyds/spider) first (outside this our own repo)
