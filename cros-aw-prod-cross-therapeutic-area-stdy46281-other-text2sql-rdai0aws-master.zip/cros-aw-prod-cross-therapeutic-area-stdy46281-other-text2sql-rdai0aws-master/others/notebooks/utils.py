import os
import boto3
import re
import pandas as pd
from IPython.display import display, HTML

from langchain.llms.bedrock import Bedrock
from langchain.utilities import SQLDatabase

import config as cfg
from function_calls import create_prompt, run_loop


def get_bedrock_llm(model_id, model_config, verbose=False):
    bedrock_runtime = boto3.client("bedrock-runtime")
    llm = Bedrock(
        client=bedrock_runtime,
        model_id=model_id,
        verbose=verbose,
        model_kwargs=model_config,
    )
    return llm


def extract_xml(tags, text):
    """Extract content enclosed in XML tags and remove newline symbols within the tag."""
    # First, extract content between the tags
    for tag in tags:
        xml_pattern = f"(?:<{tag}.*?>)(.*?)(?:<\\/{tag}>)"
        extracted_content = re.findall(xml_pattern, text, re.DOTALL)

        if extracted_content:
            # Then, remove newline symbols from the extracted content
            return extracted_content[0].strip()

    return None


def get_llm_output(row0, llm, prompt0, inputs0, question_col, gt_sql_executed_col):
    """Gets the generated SQL and question summary based on the input question and whether the GT SQL is executable."""
    row = row0.copy()
    inputs = inputs0.copy()

    question = row[question_col]
    inputs["question"] = question
    print('Input question:', inputs['question'])

    sql = "GT SQL Non-Executable"
    summary = ""
    if row[gt_sql_executed_col]:
        prompt = create_prompt(prompt0, inputs)
        response = run_loop(llm, prompt)
        sql = extract_xml(tags=["sql"], text=response)
        summary = extract_xml(tags=["summary"], text=response)

    row[f"sql_predicted"] = sql
    row[f"question_summary"] = summary
    return row


def get_db_tables_info():
    """
    Gets the table schema with create table statements and sample rows from each table.
    """
    if not os.path.exists(cfg.DB_TABLES_INFO_PATH):
        print('Getting tables info from Redshift DB...')
        redshift_endpoint = f"redshift+psycopg2://{cfg.REDSHIFT_PARAMS['USERNAME']}:{cfg.REDSHIFT_PARAMS['PASSWORD']}@{cfg.REDSHIFT_PARAMS['HOST']}:{cfg.REDSHIFT_PARAMS['PORT']}/{cfg.REDSHIFT_PARAMS['DATABASE']}"
        db = SQLDatabase.from_uri(redshift_endpoint,  schema=f'{cfg.DB_SCHEMA_NAME}')
        
        table_names = db.get_usable_table_names()
        tables_info = db.get_table_info(table_names=table_names)
        with open(cfg.DB_TABLES_INFO_PATH, 'w') as fp:
            fp.write(tables_info)
    else:
        print('Tables Info already exists! Loading.')
        with open(cfg.DB_TABLES_INFO_PATH, 'r') as fp:
            tables_info = fp.readlines()
        tables_info = ''.join(tables_info)

    return tables_info


def get_column_descriptions():
    """Get column descriptions in xml format."""
    df = pd.read_csv(cfg.COLUMNS_DESC_PATH)
    expected_cols = ["column_name", "column_description", "table_name"]
    if set(expected_cols) != set(df.columns):
        raise ValueError(f'Column names are different! Columns should be: {expected_cols}')
        
    desc_xml = df.to_xml(index=False)
    
    #remove the first line
    desc_xml = desc_xml.split('\n', 1)[1]
    return desc_xml


def print_gt_and_pred_sql(row, question_column, gt_column, pred_column, summary_column):
    """Print both the ground-truth and predicted SQL queries."""

    gt_sql = row[gt_column]
    if "sqlite" in gt_column:
        gt_sql = gt_sql.replace("rwdex_raw_synpuf.", "")

    print(f"QA ID: {row['qa_id']}")
    print("-" * 30)

    display(HTML(f"<font color=blue>QUESTION: {row[question_column]}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=green>SQL(GT): {gt_sql}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=gray>SQL(PRED): {row[pred_column]}</font>"))
    print("-" * 30)

    display(HTML(f"<font color=gray>QUESTION SUMMARY: {row[summary_column]}</font>"))
    print("-" * 30)
    

def build_few_shot_examples(golden_examples, question, retriever):
    similar_questions = [
        content.page_content for content in retriever.get_relevant_documents(question)
    ]
    few_shot_sql = [golden_examples[question] for question in similar_questions]

    output = ""

    for q, s in zip(similar_questions, few_shot_sql):
        output += f"<question>{q}</question>"
        output += f"\n<sql>\n{s}\n</sql>\n\n"

    return output
