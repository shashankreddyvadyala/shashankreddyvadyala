from prompts import *

QA_DATA_PATH = "s3://aws-gaiic-merck-text2sql/data/synpuf_query_combined_20231121.csv"
COLUMNS_DESC_PATH = '../data/columns_description.csv'
DB_TABLES_INFO_PATH = '../data/db_tables_info.txt'

GENDER_CODES_PATH = '../data/synpuf_codes/gender.json'
RACE_CODES_PATH = '../data/synpuf_codes/race.json'
STATE_CODES_PATH = '../data/synpuf_codes/state.json'

FAISS_INDEX_DIR = "../data/faiss_index/"
FAISS_DICT_EXAMPLES_PATH = "../data/faiss_index/examples.json"
NUM_FEW_SHOT_EXAMPLES = 0

PROMPT = PROMPT_V8

OUTPUT_PATH = f'../outputs/llms/sql_outputs.csv'

EMBED_MODEL_ID = "amazon.titan-embed-g1-text-02" # Embedding model for few-shot learning

SQL_MODEL_ID = 'anthropic.claude-v2:1'#'anthropic.claude-v2:1' #Model for SQL generation
SQL_MODEL_CONFIG = {
    "max_tokens_to_sample": 512,
    "temperature": 0,
    "top_p": 1,
    "top_k": 50,
    "stop_sequences": ["\n\nHuman:", "</function_calls>"],
}

#Redshift params
REDSHIFT_PARAMS = {
    "HOST": "redshift-synpuf-db-cluster-1.ckbiikj73zqo.us-east-1.redshift.amazonaws.com",
    "PORT": 5439,
    "DATABASE": 'dev',
    "USERNAME": "awsuser",
    "PASSWORD": "Merck123"
}

DB_SCHEMA_NAME = 'rwdex_raw_synpuf'
