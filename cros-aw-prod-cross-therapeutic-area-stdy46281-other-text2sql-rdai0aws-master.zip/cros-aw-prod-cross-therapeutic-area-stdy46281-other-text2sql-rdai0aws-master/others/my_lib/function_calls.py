from defusedxml import ElementTree
from collections import defaultdict
import os
from typing import Any
import tools
import boto3
import json

# Function to add tools to prompt
def add_tools():
    tools_string = ""
    for tool_spec in tools.list_of_tools_specs:
        tools_string += tool_spec
    return tools_string


# Prompt for tool usage
def create_prompt(prompt_template, inputs):
    """Create prompt with tools based on the given prompt template and inputs."""

    tools_string = add_tools()
    prompt_template = prompt_template.format(tools_string=tools_string,
                                             **inputs)
    return prompt_template


# Function to call the actual function being requested by the LLM
def call_function(tool_name, parameters):
    func = getattr(tools, tool_name)
    output = func(**parameters)
    return output

# Function to format the result of the function call
def format_result(tool_name, output):
    return f"""
<function_results>
<result>
<tool_name>{tool_name}</tool_name>
<stdout>
{output}
</stdout>
</result>
</function_results>
"""

# Function to convert parsed XML Etree to python dict
def etree_to_dict(t) -> dict[str, Any]:
    d = {t.tag: {}}
    children = list(t)
    if children:
        dd = defaultdict(list)
        for dc in map(etree_to_dict, children):
            for k, v in dc.items():
                dd[k].append(v)
        d = {t.tag: {k: v[0] if len(v) == 1 else v for k, v in dd.items()}}
    if t.attrib:
        d[t.tag].update(("@" + k, v) for k, v in t.attrib.items())
    if t.text and t.text.strip():
        if children or t.attrib:
            d[t.tag]["#text"] = t.text
        else:
            d[t.tag] = t.text
    return d


def run_loop(llm, prompt, retry_limit=10):
    retry = 0
    
    # Start function calling loop
    response = ""
    while retry < retry_limit:
        # Get a completion from Claude
        response = llm(prompt)
        # print('===Response===')
        # print(response)
        
        #Append the completion to the end of the prompt
        prompt += response

        if len(response) - response.find('</invoke>') == 10:
            # IF Claude made a function call
            start_index = response.find('<function_calls>')
            if start_index != -1:
                # Extract the XML Claude outputted (invoking the function)
                extracted_text = response[start_index+16:]
                
                # print('===Extracted Text===')
                # print(extracted_text)
                
                # Parse the XML find the tool name and the parameters that we need to pass to the tool
                xml = ElementTree.fromstring(extracted_text)
                tool_name = xml.find("tool_name")
                if tool_name is None:
                    print("Unable to parse function call, invalid XML or missing 'tool_name' tag")
                    break
                tool_name = tool_name.text.strip()
                parameters = xml.find("parameters")
                if parameters is None:
                    print("Unable to parse function call, invalid XML or missing 'parameters' tag")
                    break
                param_dict = etree_to_dict(parameters)
                parameters = param_dict["parameters"]
                
                # Call the tool we defined in tools.py
                output = call_function(tool_name, parameters)
                
                # Add the stop sequence back to the prompt
                prompt += "</function_calls>"
                
                # Add the result from calling the tool back to the prompt
                function_result = format_result(tool_name, output)
                prompt += function_result
                
                # print('===function result===')
                # print(function_result)
                
        else:
            # If Claude did not make a function call
            # Outputted answer
            break
        retry += 1
        
    # print('===Final Prompt===')
    # print(prompt)
        
    return response