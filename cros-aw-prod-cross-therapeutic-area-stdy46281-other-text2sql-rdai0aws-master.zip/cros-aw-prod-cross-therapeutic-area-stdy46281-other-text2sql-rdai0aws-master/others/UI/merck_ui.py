#
# standard Python libraries
#
import json
import time
import os
import re
import shutil
import base64
import uuid


#
# Apache v2 license - pre-approved
#
import boto3
import streamlit as st
# import streamlit.components.v1 as components

#
# BSD 3-Clause - pre-approved
#
import pandas as pd
import numpy as np
import nbformat

#
# MIT license - pre-approved
#
from streamlit_ace import st_ace, KEYBINDINGS, LANGUAGES, THEMES
from streamlit_elements import elements, mui, html
from streamlit_elements import lazy
from streamlit_elements import sync
from streamlit_elements import editor

import langchain

from langchain.llms import Bedrock
from langchain.memory import ConversationBufferMemory
from langchain.callbacks.base import BaseCallbackHandler
from langchain.utilities import SQLDatabase
from langchain.embeddings import BedrockEmbeddings
from langchain.vectorstores import FAISS

import plotly.express as px

#
# Local 
#
import os
import sys
PATH = "/home/ec2-user/SageMaker/merck-text2sql-genai-poc/"
sys.path.append(PATH)
sys.path.append(PATH+'my_lib')
#print(sys.path)
#from prompts.prompts_tools import *
from config import *
from utils import *
from function_calls import *

#
# Other
#
import sqlite3

from tqdm import tqdm
tqdm.pandas()

from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, Frame, Image




#
# configure the back end
#



with open(COLUMNS_DESC_PATH,'r') as f:
    col_descriptions = f.readlines()[1:]
col_descriptions = ''.join(col_descriptions)

#Redshift params
REDSHIFT_HOST = REDSHIFT_PARAMS['HOST']
REDSHIFT_PORT = REDSHIFT_PARAMS['PORT']
REDSHIFT_DATABASE = REDSHIFT_PARAMS['DATABASE']
USERNAME =  REDSHIFT_PARAMS['USERNAME']
PASSWORD = REDSHIFT_PARAMS['PASSWORD']

REDSHIFT_ENDPOINT = f"redshift+psycopg2://{USERNAME}:{PASSWORD}@{REDSHIFT_HOST}:{REDSHIFT_PORT}/{REDSHIFT_DATABASE}"

db = SQLDatabase.from_uri(REDSHIFT_ENDPOINT,  schema=f'{DB_SCHEMA_NAME}')

client = boto3.client('bedrock-runtime')
my_session = boto3.session.Session()
region = my_session.region_name
llm_embeddings = BedrockEmbeddings(client=client, model_id=EMBED_MODEL_ID)


def get_db_tables_info():
    """
    Gets the table schema with create table statements and sample rows from each table.
    """
    if not os.path.exists(DB_TABLES_INFO_PATH):
        print('Getting tables info from Redshift DB...')
        table_names = db.get_usable_table_names()
        tables_info = db.get_table_info(table_names=table_names)
        with open(DB_TABLES_INFO_PATH, 'w') as fp:
            fp.write(tables_info)
    else:
        print('Tables Info already exists! Loading.')
        with open(DB_TABLES_INFO_PATH, 'r') as fp:
            tables_info = fp.readlines()
        tables_info = ''.join(tables_info)

    return tables_info



def create_download_link(val, filename, filetype):
    # creates an html download link 
    b64 = base64.b64encode(val)  
    return f'<a href="data:application/octet-stream;base64,{b64.decode()}" download="{filename}">Download {filetype}</a>'


def config_llm():
    # you can change the LLM model here as well as max tokens, temperature etc.
    MODEL_ID = st.session_state['llm_model']
    llm = Bedrock(region_name=region, model_id=MODEL_ID,client=client)
    llm.model_kwargs = SQL_MODEL_CONFIG
    return llm

def get_few_shots(question):
    few_shot_examples = ""
    if st.session_state["n_few_shots"]>0:
        # Load golden examples for few shot learning
        with open(FAISS_DICT_EXAMPLES_PATH, "r") as fp:
            # pickle.dump(sample_dict, file)
            golden_examples = json.load(fp)


        # Load Vector DB and Create a retriever
        vector_db = FAISS.load_local(FAISS_INDEX_DIR, llm_embeddings)
        retriever = vector_db.as_retriever(search_kwargs={"k": st.session_state["n_few_shots"]})

        few_shot_examples = build_few_shot_examples(golden_examples, question, retriever)
        return few_shot_examples
    
def add_to_vector_db(code):
    query = code.split('\n')[0].strip('-').strip(' ')
    sql_code = ('\n').join(code.split('\n')[1:]).strip(' ')
    print(f"q: {query}")
    print(f"code: {sql_code}")
    
def feedback_code(code,feedback):
    # feedback is 1 (good) or 0 (bad)
    query = code.split('\n')[0].strip('-').strip(' ')
    sql_code = ('\n').join(code.split('\n')[1:]).strip(' ')
    feedback_dict = {'query':query, 'sql_code':sql_code, 'rating': feedback}
    feedback_json = json.dumps(feedback_dict) # note i gave it a different name
    print(feedback_json)
    with open(FEEDBACK_FILE, 'a') as file:
        json.dump(feedback_json, file, ensure_ascii=False)
        file.write('/n')


#
# LLM memory management
#

def process_mem(step_mem,success=True):
    # this takes the code memory buffer at the end of the chain and outputs concatenated code snippets that don't get errors
    n = len(step_mem) //2
    code = ''
    for i,mess in enumerate(step_mem[:-1]):
        if 'Error' in step_mem[i+1][1]:
            pass
        else:
            code += step_mem[i][1]
            code += '\n'
    return code


def get_code_history():
    # Aggregates inputs and code from the memoory to be added to the prompt 
    mess_list = st.session_state["code_mem"]
    hist = ''
    count = 0
    for mess in mess_list:
        if mess[0]=='user':
            hist+=f"Query {count+1} : {mess[1]} \n"
            count+=1
        else:
            hist+= f"Code : {mess[1]}"
            hist+='---- \n'
    return hist


def remove_step(i,verbose=True):
    # removes step i from LLM memory
    st.session_state["code_mem"].pop(2*(i-1))
    st.session_state["code_mem"].pop(2*(i-1))
    
        
def replace_step(i,code):
    # replaces the code in step i in LLM memory with new code 
    st.session_state["code_mem"][2*i-1][1] = code
    #print(get_code_history())

    
#
# Streamlit / LLM utils
#

def parse_string(string,tag,get_all=False):
    pattern = fr'<{tag}>(.*?)</{tag}>'
    # Find all matches in the string
    matches = re.findall(pattern, string,re.DOTALL)
    # return the first match
    if get_all:
        return matches
    else:
        try:
            return matches[0]
        except:
            return None
        
def get_params(parameters):
    param_dict = dict()
    pattern = r'<(\w+)>(.*?)</\1>'
    matches = re.findall(pattern, parameters)
    for match in matches:
        param_dict[match[0]]=match[1]
    return param_dict



def remove_last_step_streamlit():
    # Removes the last step from LLM memory and deletes all related streamlit session state variables
    n = st.session_state["num_tabs"]
    remove_step(n-1) # removes step from llms memory
    # remove all variables linked to step i from streamlit's session state
    for key in st.session_state.keys():
        if f"_{st.session_state['num_tabs']}" in key or f"_{st.session_state['num_tabs']-1}" in key:
            del st.session_state[key]
    st.session_state["num_tabs"]-=1
    st.rerun()
    

def add_comment():
    #adds comments to the analysis report 
    step_dict = {'comment':st.session_state.analyst_comment}
    st.session_state.analyst_comment = ''
    st.session_state["expander"].append(step_dict)
    
    
###
#CALLBACKS
###

def step_start_callback(task):
    # writes LLM input to current tab
    columns[current_tab]['column1'].markdown(":blue[User Input: " + task + ']\n\n')

    # saves LLM input to session state
    if f"step_{current_tab}" not in st.session_state:
        st.session_state[f"step_{current_tab}"] = []
    st.session_state[f"step_{current_tab}"].append(":blue[User Input: " + task + ']\n\n')
    
    st.session_state[f"step_{current_tab}_code"] = []
    st.session_state[f"editor_{current_tab}_code"] = []
    st.session_state[f"step_{current_tab}_output"] = []


     
def step_end_callback(code,output):
    # process code inputs and outputs from the chain and saves them in step and editor session states
    if f"step_{current_tab}_code" not in st.session_state:
        st.session_state[f"step_{current_tab}_code"] = code
    else:
        st.session_state[f"step_{current_tab}_code"] += code
        
    if f"editor_{current_tab}_code" not in st.session_state:
        st.session_state[f"editor_{current_tab}_code"] = code
    else:
        st.session_state[f"editor_{current_tab}_code"] += code

    if f"step_{current_tab}_output" not in st.session_state:
        st.session_state[f"step_{current_tab}_output"] = code
    else:
        st.session_state[f"step_{current_tab}_output"] += code
    
   

         
def llm_end_callback(self, response, **kwargs):
    return None


def tool_end_callback():
    return None
    
    

def call_agent(task):
    # this functions calls the LLM with input "task" and manages the LLM memory
    step_mem = []
    ### THS IS WHERE THE AGENT RUNS
    step_start_callback(task)
    few_shot_examples = get_few_shots(task)
    inputs = {
    "question": task,
    "db_schema_name": st.session_state[f"db_schema"],
    "table_info": st.session_state["table_info"],
    "columns_description": st.session_state[f"col_description"]
    }
    if st.session_state["n_few_shots"]>0:
        few_shot_examples = get_few_shots(task)
        inputs["query_examples"] = f"{few_shot_examples}"
    else:
        inputs["query_examples"] = ""
    if "code_history" in st.session_state:
        history = get_code_history()
        inputs["history"] = f"\nHere is the code history from your interactions with the user:\n<history>\n{history}\n</history>\n"
    else:
        inputs["history"] = st.session_state["code_history"] = ''
    prompt = create_prompt(st.session_state["prompt"], inputs)
    stop_words = ["<sql_output>","Human:"]
    count = 0
    while count < 10:
        print('BEGIN PROMPT')
        print(prompt)
        print('END PROMPT')
        llm_response = llm.predict(prompt,stop = stop_words).strip()
        print(llm_response)
        prompt += llm_response+"</function_calls>" # add stopword back to LLM response
        if '</invoke>' in llm_response:
            count+=1
            tool_calls = parse_string(llm_response,"invoke",get_all=True)
            for tool_call in tool_calls:
                tool_name = parse_string(tool_call,"tool_name")
                parameters = parse_string(tool_call,"parameters")
                parameters_dict = get_params(parameters)        
                columns[current_tab]['column1'].markdown(f"LLM calling {tool_name} tool with parameters {parameters_dict}.\n\n")
                st.session_state[f"step_{current_tab}"].append(f"LLM calling {tool_name} tool with parameters {parameters_dict}.\n\n")
                
                # Call the tool we defined in tools.py
                try:
                    output = call_function(tool_name, parameters_dict)
                    columns[current_tab]['column1'].markdown(f"*{tool_name} output: {output}.*\n\n")
                    st.session_state[f"step_{current_tab}"].append(f"*{tool_name} output: {output}.*\n\n")
                except exception as e:
                    print(f"Wrong function call : {e}")
                # Add the result from calling the tool back to the prompt
                function_result = format_result(tool_name, output)
                prompt += function_result
        else:
            break

    sql_code = parse_string(llm_response,"sql")
    if sql_code is None:
        prompt += llm_response
        prompt += "\n\nHuman: Can you rewrite the sql query in sql tags and the summary in summary tags?"
        if count > 0:
            prompt += "Use the codes you got from the tools in the query."
        prompt += "\n\nAssistant: "
        print('BEGIN PROMPT')
        print(prompt)
        print('END PROMPT')
        llm_response = llm.predict(prompt,stop = ["Human:"])
        print(llm_response)
        sql_code = parse_string(llm_response,"sql")
    summary = parse_string(llm_response,"summary")
    print(f"summary: {summary}")
    if summary:
        columns[current_tab]['column1'].markdown("LLM summary: " + summary + '\n\n')
        st.session_state[f"step_{current_tab}"].append("LLM summary: " + summary + '\n\n')
        
        
    columns[current_tab]['column1'].code(sql_code)
    st.session_state[f"step_{current_tab}_code"].append(sql_code)
    step_mem.append(('code_input',sql_code))
    sql_output = "Exec off"
    
    if st.session_state["exec_mode"]=="Auto":
        stop_words = ["<sql_output>","Human:"]
        count_sql_runs = 0
        while count_sql_runs <4:
            print(f"count : {count}")
            try:
                sql_output = db.run(sql_code)
                #columns[current_tab]['column1'].markdown(":green[SQL output: " + sql_output+ ']\n\n')
                #st.session_state[f"step_{current_tab}_output"].append(":green[SQL output: " + sql_output+ ']\n\n')
                columns[current_tab]['column1'].code(sql_output[:200])
                st.session_state[f"step_{current_tab}_output"].append(sql_output[:200])
                step_mem.append(('code_output'," "))
                break
            except Exception as e:
                error = '\n\n<sql_output>\n'+str(e.orig)+'\n</sql_output>\n'
                print(error)
                step_mem.append(('code_output',str(e.orig)))
                columns[current_tab]['column1'].markdown(":red[Error: " + str(e.orig)+ ']\n\n')
                st.session_state[f"step_{current_tab}_output"].append(":red[Error: " + str(e.orig)+ ']\n\n')
                prompt += llm_response+error
                print('BEGIN PROMPT')
                print(prompt)
                print('END PROMPT')
                llm_response = llm.predict(prompt,stop = stop_words)
                print(llm_response)
                print('END REPLY')
                summary = parse_string(llm_response,"summary")
                print(f"summary: {summary}")
                if summary:
                    columns[current_tab]['column1'].markdown("LLM summary: " + summary + '\n\n')
                    st.session_state[f"step_{current_tab}"].append("LLM summary: " + summary + '\n\n')
                sql_code = parse_string(llm_response,"sql")
                columns[current_tab]['column1'].code(sql_code)
                st.session_state[f"step_{current_tab}_code"].append(sql_code)
                step_mem.append(('code_input',sql_code))
                count += 1
        
    #columns[current_tab]['column1'].markdown(":green[SQL code: " + sql_code + ']\n\n')
    #st.session_state[f"step_{current_tab}_code"].append(":green[SQL code: " + sql_code + ']\n\n')
    success=True
    
    #columns[current_tab]['column1'].markdown(":green[SQL output: " + sql_output+ ']\n\n')
    #st.session_state[f"step_{current_tab}_output"].append(":green[SQL output: " + sql_output+ ']\n\n')
    columns[current_tab]['column1'].code(sql_output[:200])
    st.session_state[f"step_{current_tab}_output"].append(sql_output[:200])
    step_mem.append(('code_output',""))   
    st.session_state[f"editor_{current_tab}_code"]= f"-- {task} \n"+sql_code.strip('\n')
    st.session_state[f"editor_0_code"]= f"-- {task} \n"+sql_code.strip('\n')
    code = process_mem(step_mem, success)
    st.session_state["code_mem"].append(('user',task))
    st.session_state["code_mem"].append(('ai',code))
    st.write('')
    return code



#
# configure the front end
#
def config_streamlit_app():

    
    st.set_page_config(
        page_title="Merck text-to-SQL",
        page_icon="🧊",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    st.markdown("""
            <style>
                   .block-container {
                        padding-top: 1rem;
                        padding-bottom: 0rem;
                        line-height: 1.1;
                    }
            </style>
            """, 
            unsafe_allow_html=True
    )

def config_sidebar():
    
    with st.sidebar:
        
        st.header("Databases")
        # Datasets are pulled from file names in demo_csv files
        #options = os.listdir('./demo_csv') 
        #try:
        #    options.remove(".ipynb_checkpoints")
        #except:
        #    pass
        db_options = ['synpuf','db2']
        db = st.selectbox("Select a database", db_options)
    
        if st.button('Select DB',"load_db"):
            st.session_state['DB'] = db
            st.rerun()
            
        st.header("Language Model")
        llm_options = ['anthropic.claude-v2:1','anthropic.claude-instant-v1']
        llm_model = st.selectbox("Select a language model", llm_options)
        if st.button('Select LLM',"select_llm"):
            st.session_state['llm_model'] = llm_model
            st.rerun()
            
        st.header("Number of few shot examples")
        n_few_shots = st.select_slider('Select the number of few shot examples to be included in the prompt.', options= list(range(6)),value=NUM_FEW_SHOT_EXAMPLES)
        st.session_state["n_few_shots"] = n_few_shots
            
        st.header("Execution Mode")
        st.radio(label="Setting execution mode to On lets you run the queries from the code editor.", options=["On","Off"], index=1, key="exec_mode", horizontal=True,label_visibility="visible")
        #st.radio(label="Setting execution mode to Auto lets the LLM run the SQL query it generates.This gives the LLM the ability to correct the SQL query if it doesn't run on the first try.", options=["On","Off","Auto"], index=1, key="exec_mode", horizontal=True,label_visibility="visible")
 


def user_command():
    # This function is triggered when the user inputs an instruction
    # It calls the LLM and saves the results in session state variable 
    global current_tab
    current_tab = st.session_state["num_tabs"]

    # clear the user command from the UI
    command = st.session_state.command
    st.session_state.command = ''
    
    # call LLM
    response = call_agent(command)
        
    st.session_state["code_history"] = get_code_history()
    
    #st.session_state["step_0"]=f"See detailed LLM response in tab 'Step {current_tab}'"
    st.session_state["step_0"]=""

    st.session_state["num_tabs"] += 1

def clear_all():
    for key in st.session_state.keys():
        if key in["DB","db_schema","select_llm","table_info","n_few_shots","col_description","llm_model","guid","prompt","exec_mode"]:
            pass
        else:
            del st.session_state[key]
    st.rerun()

    

def config_main_page():
    global column1, column2, tabs, columns

    st.header("Merck text-to-SQL Assistant")
    
    #st.write(get_code_history())
    print(get_code_history())
                 
    #
    # Tabs (each tab corresponds to a Step / LLM call)
    #
    
    if "num_tabs" not in st.session_state:
        st.session_state["num_tabs"] = 1

    tab_names = ["Data"]
    for i in range(1, st.session_state["num_tabs"]+1):
        tab_names.append(f"Query {i}")
    
    tabs = st.tabs(tab_names)
    columns = []  # column components within each tab
 

    for tab in range(0, st.session_state["num_tabs"]+1):

        column1, column2 = tabs[tab].columns([1, 1], gap="medium")

        columns.append({})
        columns[tab]['column1'] = column1 # Analysis column
        columns[tab]['column2'] = column2 # Code editor and code ouput column
        
        with column1:
            
            if tab == 0:
                if 'DB' not in st.session_state:
                    st.markdown("Select a database using the dropdown on the left.")
                else:
                    st.markdown(f"**{st.session_state['DB']} database**")
                    with st.expander("Schema"):
                        st.markdown(st.session_state["db_schema"])
                    with st.expander("Columns descriptions"):
                        st.markdown(st.session_state["col_description"])
                    with st.expander("Table info"):
                        st.code(st.session_state["table_info"], language='sql')
                    st.markdown(st.session_state[f"step_0"])
                    
                if st.button("Clear all history"):
                    clear_all()
            else:
                
                #
                # Analysis
                #

                st.subheader("Analysis" )

                # Delete last step -- can't delete data step
                if tab == st.session_state["num_tabs"]-1 and tab>0:
                    col_an_b1, col_an_b2 = st.columns(2)
                    if col_an_b2.button(f"Delete Query", key=f"del_step_{tab}", help=None):
                        remove_last_step_streamlit()
                else:
                    col_an_b1= st.columns(1)[0]

                #Save analysis 
                if col_an_b1.button(f"Save Analysis", key=f"save_step_{tab}", help=None):

                    step_dict = dict()
                    if f"step_{tab}" in st.session_state:
                        step_dict["step"] = []
                        for item in st.session_state[f"step_{tab}"]:
                            step_dict["step"].append(item)

                    if f"step_{tab}_code" in st.session_state:
                        step_dict["step_code"] = st.session_state[f"step_{tab}_code"]

                    if f"step_{tab}_output" in st.session_state:
                        try:
                            if st.session_state[f"step_{tab}_output"]!="":
                                step_dict[f"step_code_output"]=st.session_state[f"step_{tab}_output"]
                        except:
                                step_dict[f"step_code_output"]=st.session_state[f"step_{tab}_output"]


                    st.session_state["expander"].append(step_dict)

                    st.rerun()

                # Display analysis in tab

                if f"step_{tab}" in st.session_state:
                    for item in st.session_state[f"step_{tab}"]:
                        st.markdown(item)

                if f"step_{tab}_code" in st.session_state and f"step_{tab}_output" in st.session_state:
                    for code_input,code_output in zip(st.session_state[f"step_{tab}_code"],st.session_state[f"step_{tab}_output"]):
                        st.markdown("LLM generated SQL query") 
                        st.code(code_input,language="sql")
                        if code_output != "Exec off":
                            st.markdown("SQL output")
                            st.code(code_output,language="sql")


                   
                        
        with column2:
            
            #
            # CODE EDITOR
            #
            
            if tab == 0:
                st.subheader(f"Code Editor")
                current_tab = st.session_state["num_tabs"] - 1
                if current_tab>0:
                    st.markdown(f"See detailed LLM response in tab 'Query {current_tab}'")
            else:
                st.subheader(f"Code Editor (query {tab})")
            
            col_ed_b1, col_ed_b2, col_ed_b3 = st.columns(3)
            #col_ed_b1, col_ed_b2 = st.columns(2)

            
            # Save code
            if col_ed_b1.button(f"Save code to .txt file", key=f"save_code_txt_{tab}", help=None):
                if "txt_file" not in st.session_state:
                    file_name = f'sql_code_{guid}.txt'
                    # Open the file in write mode to create an empty file
                    with open(file_name, 'w') as file:
                        pass
                    st.session_state['txt_file'] = file_name
                with open(st.session_state["txt_file"], 'a') as file:
                    file.write(st.session_state[f"editor_{tab}_code"]+'\n')

                f = open(st.session_state["txt_file"], "r")
                txt = f.read()
                html = create_download_link(txt.encode("latin-1"), f"sql_code_final_{guid}.txt", "sql_code")
                st.markdown(html, unsafe_allow_html=True)
                
            if col_ed_b2.button(f"👍", key=f"thumbs_up_code_{tab}", help=None):
                feedback_code(st.session_state[f"editor_{tab}_code"],1)
                
            if col_ed_b3.button(f"👎", key=f"thumbs_down_code_{tab}", help=None):
                feedback_code(st.session_state[f"editor_{tab}_code"],0)
            
                
            #if col_ed_b2.button(f"Save code to code DB", key=f"save_code_db_{tab}", help=None):
            #    add_to_vector_db(st.session_state[f"editor_{tab}_code"])

            
            ## Save to Report
            #if col_ed_b2.button(f"Save to Report", key=f"save_code_report_{tab}", help=None):
            #    step_dict = dict()
            #    step_dict["editor_code"] = st.session_state[f"editor_{tab}_code"]
            #    st.session_state["expander"].append(step_dict)
            #    st.rerun()
            
            # Replace code in memory for that step by current code in editor -- need to handle LLM memory + session state for display
            #if tab>0:
            #    if col_ed_b3.button(f"Replace in Step {tab}", key=f"replace_code_{tab}", help=None):
            #        replace_step(tab,st.session_state[f"editor_{tab}_code"])
            #        st.session_state[f"step_{tab}_code"] = st.session_state[f"editor_{tab}_code"]
            #        st.session_state[f"step_{tab}_output"] = st.session_state[f"editor_{tab}_output"]
            #        st.rerun()
            #
            #elif tab==0 and st.session_state["num_tabs"]>1 :
            #    curr_tab = st.session_state["num_tabs"] - 1
            #    if col_ed_b3.button(f"Replace in Step {curr_tab}", key=f"replace_code_{tab}", help=None):
            #        replace_step(curr_tab,st.session_state[f"editor_{curr_tab}_code"])
            #        st.session_state[f"step_{curr_tab}_code"] = st.session_state[f"editor_{curr_tab}_code"]
            #        st.session_state[f"step_{curr_tab}_output"] = st.session_state[f"editor_{curr_tab}_output"]
            #        st.rerun()
                

                
            content = dict()
            
            if f"editor_{tab}_code" not in st.session_state:
                st.session_state[f"editor_{tab}_code"] = ""
                
            # This is a hack to force the code from the step to be displayed by the editor -- TODO 
            if f"editor_{tab}_status" not in st.session_state:
                st.session_state[f"editor_{tab}_status"] = 0
                
            if st.session_state[f"editor_{tab}_status"] == 0 and f"step_{tab}" in st.session_state:
                st.session_state[f"editor_{tab}_status"] = 1
            
            # ACE editor, can change theme and parameters
            content[tab] = st_ace(
                value = st.session_state[f"editor_{tab}_code"],
                key = f"editor_{tab}",
                #key = f"editor_{tab}_{st.session_state[f'code_{tab}_status']}",
                language = "sql",
                theme = "tomorrow_night_eighties",
                wrap = True,
                auto_update=True
            )
            st.session_state[f"editor_{tab}_code"] = content[tab]
            #st.write("Code "+ st.session_state[f"editor_{tab}_code"])
            
            col_code_b1, col_code_b2 = st.columns(2, gap='large')
            
            # Run code and save both input and output to session state
            if st.session_state["exec_mode"] != "Off":
                if col_code_b1.button(f"Run code", key=f"run_code_{tab}", help=None):
                    st.session_state[f"editor_{tab}_output"] = db.run(st.session_state[f"editor_{tab}_code"])   
            
            # useful to refresh code when editor acts erratically (actually refreshes whole page)
            if col_code_b2.button(f"Refresh page", key=f"refresh_code_{tab}", help=None):
                st.session_state[f"editor_{tab}_code"] = content[tab]
                st.rerun()
                
                
            #
            # CODE OUTPUT
            #

            # only display code outputs section if there's something in the code editor
            if content[tab] and st.session_state["exec_mode"] != "Off":   
                st.subheader("Code Output")
                
                # Saving output
                if st.button(f"Save Output", key=f"save_output_{tab}", help=None):
                    step_dict = dict()
                    # only save ouput code if it's not empty
                    try:
                        if st.session_state[f"editor_{tab}_output"]!="":
                            step_dict['output_code'] = st.session_state[f"editor_{tab}_output"]
                    #exception thrown when ouput is not a string, means it's not empty so we save it
                    except:
                            step_dict['output_code'] = st.session_state[f"editor_{tab}_output"]
  
                        
                    st.session_state["expander"].append(step_dict)
                    st.rerun()
                
                
                 
                if f"editor_{tab}_output" in st.session_state:
                    try:
                        if st.session_state[f"editor_{tab}_output"]!="":
                            st.code(st.session_state[f"editor_{tab}_output"], language="sql", line_numbers=False)
                    except:
                        st.code(st.session_state[f"editor_{tab}_output"], language="sql", line_numbers=False)

                
                        

    #
    # User input
    #
    
    st.subheader("Command")
    st.text_input("Enter your instructions here and press Enter.", value="", key="command", on_change=user_command)

    #
    # Report Expander
    #
    
    # expander to view report output, contains buttons to download report to PDF and clear report content
    with st.expander("**View Report Output**"):
        if "expander" not in st.session_state:
            st.session_state["expander"] = []
        if len(st.session_state["expander"])==0:
            st.markdown("")
        else:
            col_b1, col_b2 = st.columns([1, 1], gap="small")
            
            # button to download report, if triggered, need to write all that's saved in the report to PDF
            if col_b1.button(f"Download Report", key=f"dl_report", help=None):
                print("downloading")
                
                styles = getSampleStyleSheet()
                text_style = styles['Normal']
                comment_style = styles['h4']
                code_style = styles['Code']

                story = []

                for i,mystep in enumerate(st.session_state["expander"]):

                    if "step" in mystep:
                        for item in mystep[f"step"]:
                            match = re.search(r"\[(.*)\]", item)
                            if match:
                                clean_item = match.group(1)
                                story.append(Paragraph(clean_item,text_style))
                            else:
                                story.append(Paragraph(item,text_style))

                    if "step_code" in mystep:
                        story.append(Paragraph(mystep[f"step_code"][-1],code_style)) 

                        
                    if "step_code_output" in mystep:
                        story.append(Paragraph(str(mystep[f"step_code_output"][-1]), code_style))


                    if "editor_code" in mystep:
                        story.append(Paragraph(mystep[f"editor_code"], code_style))

                    if "output_code" in mystep:
                        story.append(Paragraph((mystep[f"output_code"])), code_style)

                        
                    if "comment" in mystep:
                        story.append(Paragraph("Analyst Comment: "+mystep[f"comment"], comment_style))

                c  = Canvas(f'{guid}_report.pdf')
                f = Frame(inch, inch, 6*inch, 9*inch)
                f.addFromList(story,c)
                c.save()
                
                f = open(f'{guid}_report.pdf', "rb")
                txt = f.read()
                html = create_download_link(txt, "analysis_report.pdf", "report")
                st.markdown(html, unsafe_allow_html=True)

            if col_b2.button(f"Clear Report", key=f"clear_report", help=None):
                st.session_state["expander"] = []

            # display everything that's in the report
            for i,mystep in enumerate(st.session_state["expander"]):
                if "step" in mystep:
                    for item in mystep[f"step"]:
                        st.markdown(item)

                if "step_code" in mystep:
                    st.markdown("LLM generated SQL query") 
                    st.code(mystep[f"step_code"][-1], language="sql")
                    #st.markdown(mystep[f"step_code"][-1])

                if "step_code_output" in mystep:
                    st.markdown("SQL output") 
                    st.code(mystep[f"step_code_output"][-1], language="sql")
                    #st.markdown(mystep[f"step_code_output"][-1])

                if "editor_code" in mystep:
                    #st.code(mystep[f"editor_code"], language="sql")
                    st.markdown(mystep[f"editor_code"])


                if "output_code" in mystep:
                    #st.code(mystep[f"output_code"], language="sql")
                    st.markdown(mystep[f"output_code"])

                if "comment" in mystep:
                    st.markdown("**Analyst Comment: "+mystep[f"comment"]+"**")
                    
            # command to add a comment to the report
            st.text_input("**Add Comment**", value="", key="analyst_comment", on_change=add_comment)
    
    #
    # Prompt Expander
    #
    
    if "prompt" in st.session_state:
        with st.expander("**View Prompt**"):
            prompt_text = st.text_area("Prompt", value=st.session_state["prompt"],height=1000)
            if st.button('Update Prompt','update_prompt'):
                st.session_state["prompt"] = prompt_text


if 'llm_model' not in st.session_state:
    st.session_state['llm_model'] = 'anthropic.claude-v2'
llm = config_llm()

pd.options.display.max_columns = None

# get a unique ID for naming local files
if not 'guid' in st.session_state:
    guid = uuid.uuid4()
    st.session_state['guid'] = guid
else:
    guid = st.session_state['guid']

        
if "prompt" not in st.session_state:
    st.session_state["prompt"] = PROMPT
    
if "n_few_shots" not in st.session_state:
    st.session_state["n_few_shots"] = NUM_FEW_SHOT_EXAMPLES 

# initializing LLM Memory
if not "code_mem" in st.session_state:
    st.session_state["code_mem"] = []

#creating the empty txt file
    
if f"step_0" not in st.session_state:
    import pandas as pd
    df = pd.read_xml(PATH+"data/columns_description.xml")
    col_descriptions = df.to_markdown() 
    del df
    #st.session_state[f"step_0"] = [f"Schema:\n {DB_SCHEMA_NAME}"]
    st.session_state[f"step_0"] = ""
    st.session_state[f"col_description"] = col_descriptions
    st.session_state[f"table_info"] = get_db_tables_info()
    st.session_state[f"db_schema"] = DB_SCHEMA_NAME

    

# Display UI
#

config_streamlit_app()

config_sidebar()

config_main_page()

#print state keys for debugging
#for key in st.session_state.keys():
#    st.write(f"{key}:{st.session_state[key]}")
#
#for key in st.session_state.keys():
#   st.write(f"{key}")
#

