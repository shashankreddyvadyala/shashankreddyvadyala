from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain.llms.bedrock import Bedrock
import re

MODEL_MAPPING = {
    "Titan": "amazon.titan-tg1-large",
    "Claude": "anthropic.claude-v1",
    "Claude2": "anthropic.claude-v2",
    "Jurassic": "ai21.j2-jumbo-instruct",
    "Jurassic_ht": "ai21.j2-jumbo-instruct"    
}

GENERATOR_CONFIG = {
    "Titan": {
        "maxTokenCount": 512,
        "temperature": 0,
        "topP": 1,
    },
    "Claude": {
        "max_tokens_to_sample": 4096,
        "temperature": 0,
        "top_p": 1,
        "top_k": 50,
    },
    "Claude2": {
        "max_tokens_to_sample": 4096,
        "temperature": 0,
        "top_p": 1,
        "top_k": 50,
    },
    "Jurassic": {
        "maxTokens": 512,
        "numResults": 1,
        "temperature": 0,
        "topKReturn": 0,
        "topP": 1,
    },
}

def extract_xml(tags, text):
    """Extract content enclosed in XML tags and remove newline symbols within the tag."""
    # First, extract content between the tags
    for tag in tags:
        xml_pattern = f"(?:<{tag}.*?>)(.*?)(?:<\\/{tag}>)"
        extracted_content = re.findall(xml_pattern, text, re.DOTALL)
        
        if extracted_content:
            # Then, remove newline symbols from the extracted content
            return extracted_content[0].replace('\n', '')

    return None
 