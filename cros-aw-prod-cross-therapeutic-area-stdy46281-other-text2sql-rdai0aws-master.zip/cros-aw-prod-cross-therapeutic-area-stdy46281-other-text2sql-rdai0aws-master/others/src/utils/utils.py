import time
import sqlparse


def timeit(method):
    """Decorator for timing functions"""

    def timed(*args, **kwargs):
        if "key" in kwargs:
            print(f"loading {kwargs['key']}...", end="")
        else:
            print(f"running {method.__name__}...", end="")
        start = time.monotonic()
        result = method(*args, **kwargs)
        end = time.monotonic()
        print(f"finished in {end - start:.4}s")
        return result

    return timed


def sql_pprint(q):
    print(sqlparse.format(q, reindent=True, keyword_case="upper"))
