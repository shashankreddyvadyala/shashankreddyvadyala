import sys
import sqlite3
import pandas as pd
import click


from src.utils.synpuf_utils import DTYPES
from src.utils.utils import timeit


def get_num_str_dtypes(dtypes):
    merged = {}
    for col in dtypes["str_columns"]:
        merged[col] = "str"
    for col in dtypes["num_columns"]:
        merged[col] = "float"
    return merged


@timeit
def load_inpatient(csv_path, db_path):
    df_inpatient = pd.read_csv(
        csv_path,
        dtype=get_num_str_dtypes(DTYPES["inpatient"]),
        parse_dates=DTYPES["inpatient"]["date_columns"],
    )

    with sqlite3.connect(db_path) as conn:
        df_inpatient.to_sql("inpatient_claims", conn, if_exists="replace", index=False)


@timeit
def load_outpatient(csv_path, db_path):
    df_outpatient = pd.read_csv(
        csv_path,
        dtype=get_num_str_dtypes(DTYPES["outpatient"]),
        parse_dates=DTYPES["outpatient"]["date_columns"],
    )

    with sqlite3.connect(db_path) as conn:
        df_outpatient.to_sql(
            "outpatient_claims", conn, if_exists="replace", index=False
        )


@timeit
def load_beneficiary(csv_paths, db_path):
    for csv in csv_paths:
        df_beneficiary = pd.read_csv(
            csv,
            dtype=get_num_str_dtypes(DTYPES["beneficiary"]),
            parse_dates=DTYPES["beneficiary"]["date_columns"],
        )
        with sqlite3.connect(db_path) as conn:
            df_beneficiary.to_sql(
                "beneficiary_summary", conn, if_exists="append", index=False
            )


@timeit
def load_pde(csv_path, db_path):
    df_pde = pd.read_csv(
        csv_path,
        dtype=get_num_str_dtypes(DTYPES["pde"]),
        parse_dates=DTYPES["pde"]["date_columns"],
    )

    with sqlite3.connect(db_path) as conn:
        df_pde.to_sql(
            "prescription_drug_events", conn, if_exists="replace", index=False
        )


@timeit
def load_carrier(csv_paths, db_path):
    for csv in csv_paths:
        df_beneficiary = pd.read_csv(
            csv,
            dtype=get_num_str_dtypes(DTYPES["beneficiary"]),
            parse_dates=DTYPES["beneficiary"]["date_columns"],
        )
        with sqlite3.connect(db_path) as conn:
            df_beneficiary.to_sql(
                "beneficiary_summary", conn, if_exists="append", index=False
            )


@click.command()
@click.option("--db_path", default="./database/synpuf.db", help="Number of greetings.")
@click.option(
    "--carrier", is_flag=True, default=False, help="create carrier claims table"
)
def main(db_path, carrier):
    # TODO move hardcoded paths to config file
    inpatient_csv = "./data/sample_1/DE1_0_2008_to_2010_Inpatient_Claims_Sample_1.csv"
    outpatient_csv = "./data/sample_1/DE1_0_2008_to_2010_Outpatient_Claims_Sample_1.csv"
    pde_csv = "./data/sample_1/DE1_0_2008_to_2010_Prescription_Drug_Events_Sample_1.csv"

    beneficiary_csv = [
        "./data/sample_1/DE1_0_2008_Beneficiary_Summary_File_Sample_1.csv",
        "./data/sample_1/DE1_0_2009_Beneficiary_Summary_File_Sample_1.csv",
        "./data/sample_1/DE1_0_2010_Beneficiary_Summary_File_Sample_1.csv",
    ]

    carrier_csv = [
        "./data/sample_1/DE1_0_2008_to_2010_Carrier_Claims_Sample_1A.csv",
        "./data/sample_1/DE1_0_2008_to_2010_Carrier_Claims_Sample_1B.csv",
    ]

    load_inpatient(inpatient_csv, db_path)

    load_outpatient(outpatient_csv, db_path)

    load_beneficiary(beneficiary_csv, db_path)

    load_pde(pde_csv, db_path)

    if carrier:
        load_carrier(carrier_csv, db_path)

    # show all the tables
    q = """
        SELECT 
            name
        FROM 
            sqlite_schema
        WHERE 
            type ='table' AND 
            name NOT LIKE 'sqlite_%';
    """
    with sqlite3.connect(db_path) as conn:
        res = conn.execute(q)
    print(res.fetchall())


if __name__ == "__main__":
    main()
