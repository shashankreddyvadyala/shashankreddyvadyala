#!/usr/bin/env python
# coding: utf-8

import logging
import json
from datetime import datetime
from pathlib import Path


class LogConfig:
    '''A simple extension of the in-built logging framework that is used
    to log messages from the scripts. It sets up 2 loggers, one to a file
    and the other to the terminal/console.
    '''

    def __ini__(self):
        self.l = None

    def setup_logger(self, logger_name, log_file, level=logging.INFO):
        '''The main method that does the heavy-lifting, i.e., setting up
        the loggers and their attributes.
        '''
        with open("config/common.json", "r") as jsonfile:
            data = json.load(jsonfile)

        self.l = logging.getLogger(logger_name)
        formatter = logging.Formatter(
            fmt='%(asctime)s %(levelname)s %(module)s %(funcName)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S')
        dt = datetime.now().strftime('%Y-%m-%d').split('-')
        lpath = f"{data['logpath']}{dt[0]}/{dt[1]}/{dt[2]}/"
        lp = Path(lpath)
        if not lp.exists():
            lp.mkdir(parents=True)
        fileHandler = logging.FileHandler(lpath + log_file, mode='a')
        fileHandler.setFormatter(formatter)
        streamHandler = logging.StreamHandler()
        streamHandler.setFormatter(formatter)

        self.l.setLevel(level)
        self.l.addHandler(fileHandler)
        self.l.addHandler(streamHandler)
        return self.l

    def create_success_log(self, param):
        '''A wrapper that sets up the success log
        '''
        dt = datetime.now().strftime('%Y%m%d-%H%M')
        success_log = self.setup_logger(
            'success_log_' + dt, f'{param}_success_{dt}.log')
        return success_log

    def create_failure_log(self, param):
        '''A wrapper that sets up the failure log
        '''
        dt = datetime.now().strftime('%Y%m%d-%H%M')
        failure_log = self.setup_logger(
            'failure_log_' + dt, f'{param}_failure_{dt}.log')
        return failure_log
