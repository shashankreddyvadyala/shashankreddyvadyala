import pandas as pd
import json
from pyspark.sql import SparkSession
from pyhive import hive


hive_conn = None


def get_hive_conn():
    '''Function to connect to hive and get the connection
    '''
    with open("config/common.json", "r") as jsonfile:
        data = json.load(jsonfile)

    host = data['hive_connection']['host']
    username = data['hive_connection']['username']
    password = data['hive_connection']['password']
    port = data['hive_connection']['port']
    auth = data['hive_connection']['auth']
    conn = hive.connect(host=host, username=username, password=password, 
                        port=port, auth=auth)
    return conn


def hive_query_data(sql_query, logger):
    '''Function to use the hive connection to run queries and fetch data
    '''
    global hive_conn

    if hive_conn is None:
        hive_conn = get_hive_conn()

    logger.info('Hive Connection was successful')
    df = pd.read_sql(sql_query, hive_conn)
    logger.info(f'Completed running hive query - {str(len(df))}')
    return df


def load_data(df, table, logger):
    '''Function that loads data in a Pandas dataframe into
    the specified Hive table in "append"mode, i.e., adds the data
    to the existing table
    '''
    spark = SparkSession.builder \
        .master("local") \
        .appName("Hive Table Load") \
        .config("spark.sql.warehouse.dir", '/user/hive/warehouse') \
        .enableHiveSupport() \
        .getOrCreate()

    # convert the incoming Pandas DataFrame to PySpark DF
    pysdf = spark.createDataFrame(df)
    #pysdf.printSchema()
    logger.info(str(pysdf.schema))
    logger.info(pysdf.show(1))
    #pysdf.write.mode('append').insertInto(table)
    pysdf.write.mode('append').saveAsTable(table)
    logger.info(f'completed data load to {table}')
