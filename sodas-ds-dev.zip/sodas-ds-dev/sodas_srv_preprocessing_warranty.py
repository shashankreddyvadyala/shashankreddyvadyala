import pandas as pd
import json
import datetime
import sys
from pathlib import Path
from pyhive import hive
from utils import sodas_logger
from utils import hive_data_load


# loading Script logging file
config = sodas_logger.LogConfig()
log_success = config.create_success_log(param='Warranty')
log_failure = config.create_failure_log(param='Warranty')
date = datetime.datetime.now().strftime("%Y%m%d_%H%M")


def runtime(t):
    return f"{(datetime.datetime.now() - t).total_seconds():0.3f} seconds"


def config_file():
    """Function to load the config file"""
    try:
        with open("config/preprocessing.json", 'r') as f:
            config = json.load(f)

        return config
    except Exception as e:
        log_failure.error(
            'Exception occurred while dropping the columns. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def hive_conn():
    """Function to connect with hive """
    try:
        data = config_file()
        conn = hive.connect(host=data['host'], port=data['port'], 
                            username=data['username'],
                            password=data['password'], auth=data['auth'])
        log_success.info("Hive connection successfully")
        return conn
    except Exception as e:
        log_failure.error(
            'Exception occurred hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def datacheck(*datasets):
    """Function for Data count check """
    try:

        for dataset in datasets:

            if len(dataset) > 0:
                log_success.info("Data check done successfully")
            else:
                log_success.info("Data is not available to proceed")
                return sys.exit("Data is not available to proceed")
    except Exception as e:
        log_failure.error(
            'Exception occurred while hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def duplicate_drop(df):
    """Function to drop the duplicates value in whole dataframe"""
    try:
        df.drop_duplicates(inplace=True)

        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while dropping the duplicate values. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def warranty_data_type_edit(df):
    """
    Function to change the drop the null v_vehicle_id and claim_received_date. 
    Also changing the datatype of claim_received_date to datetime
    """
    try:
        df.dropna(subset=['v_vehicle_id',
                  'claim_received_date'], axis=0, inplace=True)
        log_success.info(
            "na value for v_vehicle_id and claim_received_date in warranty_merged dropped successfully")
        df['claim_received_date'] = pd.to_datetime(
            df['claim_received_date'], errors='coerce')
        log_success.info(
            "warranty data type for claim received date edit successfully")
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while warranty_data_type_edit. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def v_model_na_drop(df):
    """ Function to drop the na valuse available in v_model table in series_short_desc column """
    try:
        df.dropna(subset=['series_short_desc'], axis=0, inplace=True)
        log_success.info(
            "na value for series short description in v_model dropped successfully")
        log_success.info(
            "Shape of v_model after dropping null value successfully {}".format(df.shape))
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while v_model_na_drop. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def vehiclefilter(vehicle):
    """
    Function to drop duplicates and null value available in v_vehicle table based 
    in the columns vin,v_model_id,brand_cd,model_year
    """
    try:
        vehicle.drop_duplicates(inplace=True)
        # showing the value counts of all 3 columns null values and removing those rows
        log_success.info('null value counts of vin, v_model_id, brand_cd and model_year: {}'.format(
            vehicle[['vin', 'v_model_id', 'brand_cd', 'model_year']].isna().sum()))
        vehicle.dropna(subset=['vin', 'v_model_id',
                       'brand_cd', 'model_year'], axis=0, inplace=True)
        log_success.info(
            "Dropped Null values for column vin,v_model_id,brand_cd,model_year successfully")
        return vehicle
    except Exception as e:
        log_failure.error(
            'Exception occurred while dropping the null value columns for vehicle dataset. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def vstatusfilter(status):
    """
    Function to change the data type of production_date to datetime.
    Also filtering the rows based on the condition retail_sale_flg is equal to y
    """
    try:
        status['production_date'] = pd.to_datetime(
            status['production_date'], errors='coerce')
        # choosing rows with retail_sale_flg is equal to y
        status = status[status['retail_sale_flg'] == 'Y']
        log_success.info(
            "Shape of v_status where status = 'Y' :{}".format(status.shape))
        return status
    except Exception as e:
        log_failure.error(
            'Exception occurred while filtering the status column of v_status. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def asfilter_NCD(df):
    """
    Function for filtering the rows of AS400 table based on the consdition warr_cd_type equals NCD
    It is used to join the all merged table to add the column nature_cd_descr availble in AS400 table
    """
    try:
        as400_NCD = df[df['warr_cd_type'] == 'NCD']
        log_success.info(
            "filtered the rows base on warr_cd_type is equal to NCD in AS400 table {}".format(as400_NCD.shape))
        as400_NCD.rename(columns={
                         'warr_cd': 'nature_cd', 'warr_cd_hma_desc': 'nature_cd_desc'}, inplace=True)
        log_success.info(
            "Rename the columns according to the data model ".format(as400_NCD.columns))
        as400_NCD.drop('warr_cd_type', axis=1, inplace=True)
        log_success.info(
            "Dropping the columns which is not required".format(as400_NCD.columns))
        return as400_NCD
    except Exception as e:
        log_failure.error(
            'Exception occurred while filtering warr_cd_type is equal to NCD in the asfilter_NCD. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def asfilter_CCD(df):
    """
    Function for filtering the rows of AS400 table based on the consdition warr_cd_type equals CCD
    It is used to join the all merged table to add the column cause_cd_descr availble in AS400 table
    """
    try:
        as400_CCD = df[df['warr_cd_type'] == 'CCD']
        log_success.info(
            "filtered the rows base on warr_cd_type is equal to CCD in AS400 table {}".format(as400_CCD.shape))
        as400_CCD.rename(columns={'warr_cd': 'cause_cd',
                         'warr_cd_hma_desc': 'cause_cd_desc'}, inplace=True)
        log_success.info(
            "Rename the columns according to the data model ".format(as400_CCD.columns))
        as400_CCD.drop('warr_cd_type', axis=1, inplace=True)
        log_success.info(
            "Dropping the columns which is not required".format(as400_CCD.columns))
        return as400_CCD
    except Exception as e:
        log_failure.error(
            'Exception occurred while filtering warr_cd_type is equal to NCD in the asfilter_NCD. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def na_replace(df):
    """
    Function to replace the na value with blanks for the columns customer_complaint_desc,cause_desc,
    correction_desc,technician_comment,nature_cd_desc,cause_cd_desc
    """
    try:
        df[['customer_complaint_desc', 'cause_desc', 'correction_desc', 'technician_comment',
            'nature_cd_desc', 'cause_cd_desc']] = df[['customer_complaint_desc', 'cause_desc',
                                                      'correction_desc', 'technician_comment',
                                                      'nature_cd_desc', 'cause_cd_desc']].fillna('')

        log_success.info(
            "NaN replaced with blanks for the description columns {}".format(df.shape))
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while filtering the status column of v_status. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def dedup(allmerged):
    """
    Function for de-duplication based on claim_num,v_vehicle_id,claim_received_date
    Input = Dataframe with duplicated values
    Output = Dataframe with removed duplicates
    """
    try:
        outcome = allmerged.groupby(['claim_num', 'v_vehicle_id', 'claim_received_date']).agg({'o_event_transaction_id': 'last',
                                                                                              'claim_id': 'last',
                                                                                               'vin': 'last',
                                                                                               'd_dealer_id': 'last',
                                                                                               'dealer_cd': 'last',
                                                                                               'v_model_id': 'last',
                                                                                               'model_year': 'last',
                                                                                               'model_short_name': 'last',
                                                                                               'series_name': 'last',
                                                                                               'door_name': 'last',
                                                                                               'trim_name': 'last',
                                                                                               'transmission_name': 'last',
                                                                                               'drivetrain_name': 'last',
                                                                                               'engine_type_name': 'last',
                                                                                               'engine_num': 'last',
                                                                                               'series_desc': 'last',
                                                                                               'series_short_desc': 'last',
                                                                                               'trim_desc': 'last',
                                                                                               'trans_desc': 'last',
                                                                                               'model_short_desc': 'last',
                                                                                               'vehicle_type_desc': 'last',
                                                                                               'production_date': 'last',
                                                                                               'retail_sale_flg': 'last',
                                                                                               'previous_retail_sale_flg': 'last',
                                                                                               'rdr_date': 'last',
                                                                                               'work_order_year': 'last',
                                                                                               'repair_order_num': 'last',
                                                                                               'claim_version_num': 'last',
                                                                                               'repair_order_open_date': 'last',
                                                                                               'repair_order_close_date': 'last',
                                                                                               'claim_type_cd': 'last',
                                                                                               'customer_complaint_desc': ','.join,
                                                                                               'cause_desc': ','.join,
                                                                                               'correction_desc': ','.join,
                                                                                               'technician_comment': ','.join,
                                                                                               'engine_litre_spec_name': 'last',
                                                                                               'model_series_cd': 'last',
                                                                                               'brand_cd': 'last',
                                                                                               'emission_cd': 'last',
                                                                                               'cause_cd': 'last',
                                                                                               'nature_cd': 'last',
                                                                                               'cause_cd_desc': ','.join,
                                                                                               'nature_cd_desc': ','.join}).reset_index()

        log_success.info("Shape after Deduplication :{}".format(outcome.shape))
        return outcome

    except Exception as e:
        log_failure.error(
            'Exception occurred while deduplication. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def description(df):
    """
    Function to add the description comment column
    It is the concatenation of customer_complaint_desc, cause_desc, correction_desc and 
    technician_comment.
    """
    try:
        cols = ['customer_complaint_desc', 'cause_desc', 'correction_desc']
        df['description'] = df[cols].apply(
            lambda row: '|'.join(row.values.astype(str)), axis=1)

        def join_text(description, technician_comment):
            if description.split('|')[2] != technician_comment:
                description = description + '|' + str(technician_comment)
                description = description.replace("|nan", ".")
            return description
        text_list = []
        for i in range(len(df)):
            text_list.append(
                join_text(df['description'][i], df['technician_comment'][i]))
        df['description'] = text_list
        log_success.info(
            " Description comment column is added for merged warranty dataset successfully")
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while addition of description column. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def finaldata(dedata):
    """
    Function for creating the final dataframe
    """
    try:
        issue_id = []
        for i in range(1, len(dedata)+1):
            issue_id.append(date + '_' + str(i))

        tmstmp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        dedata['warr_veh_id'] = issue_id
        dedata.insert(2, 'processed_date', tmstmp)
        dedata['rec_create_date'] = tmstmp
        dedata['rec_create_by'] = 'Warranty_Preprocess_Batch'
        dedata['rec_update_by'] = 'Warranty_Preprocess_Batch'
        dedata['rec_update_date'] = tmstmp
        dedata = description(dedata)

        fltr_lst = ['warr_veh_id', 'o_event_transaction_id', 
                    'processed_date', 'claim_id', 'v_vehicle_id', 'brand_cd', 
                    'd_dealer_id', 'dealer_cd', 'claim_num', 'work_order_year',
                    'repair_order_num', 'claim_version_num', 'vin', 
                    'claim_received_date', 'repair_order_open_date', 
                    'repair_order_close_date', 'claim_type_cd',  
                    'customer_complaint_desc', 'cause_desc', 'correction_desc', 
                    'technician_comment', 'description', 'v_model_id', 'model_year', 
                    'door_name', 'trim_name', 'transmission_name', 'drivetrain_name', 
                    'engine_type_name', 'emission_cd', 'engine_litre_spec_name', 
                    'series_short_desc', 'model_series_cd', 'series_name', 
                    'trim_desc', 'trans_desc', 'vehicle_type_desc', 'production_date', 
                    'rdr_date', 'cause_cd', 'nature_cd', 'cause_cd_desc', 
                    'nature_cd_desc', 'rec_create_date', 'rec_create_by','rec_update_by', 
		    'rec_update_date']
        finalout2 = dedata.filter(fltr_lst)

        finalout2.columns = finalout2.columns.str.lower()
        log_success.info(" Shape of final table {}".format(finalout2.shape))
        return finalout2

    except Exception as e:
        log_failure.error(
            'Exception occurred while final table structure creation. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def issue_merge(df):
    """Function to push the data in issue merge"""
    try:
        df['SOURCE'] = 'Warranty'
        
        log_success.info('New columns added successfully in table')
        df.rename(columns = {'o_event_transaction_id':'TRANSACTION_ID', 
                             'claim_id':'ISSUE_ID',
                             'claim_received_date':'ISSUE_DATE',
                             'description':'ISSUE_DESCRIPTION',
                             'series_short_desc':'MODEL',
                             'model_year':'MODEL_YEAR',
                             'rdr_date':'RDR_DATE',
                             'production_date':'PRODUCTION_DATE'}, inplace = True)
        log_success.info('Column renamed successfully for warranty table')
        
        issue_id = []
        for i in range(1,len(df)+1):
            issue_id.append(date + '_' + str(i))
        
        tmstmp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        df['ISSUES_MRGD_ID'] = issue_id
        df['PROCESSED_DATE'] = tmstmp
	df['rec_create_date'] = tmstmp
        df['rec_create_by'] = 'Warranty_Preprocess_Batch'
        df['rec_update_by'] = 'Warranty_Preprocess_Batch'
        df['rec_update_date'] = tmstmp
        
        df['MAKE'] = ''
        df['compdesc'] = ''
        
        fltr_lst =  ['ISSUES_MRGD_ID', 'TRANSACTION_ID', 'ISSUE_ID', 'SOURCE',
                     'PROCESSED_DATE', 'vin', 'ISSUE_DATE', 'ISSUE_DESCRIPTION', 
                     'MAKE', 'MODEL', 'MODEL_YEAR', 'PRODUCTION_DATE', 'RDR_DATE', 
                     'engine_litre_spec_name', 'compdesc', 'rec_create_date', 
                     'rec_create_by', 'rec_update_by', 'rec_update_date']
        output = df.filter(fltr_lst, axis=1)
        output.columns = output.columns.str.lower()
        log_success.info('Final structure of issue merge is created according to the data model')
        return output
    except Exception as e:
        log_failure.error('Exception occurred while creating issue merge table. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def output_file(df1, df2):
    """Function to save the output file"""
    try:
        data = config_file()
        dt = datetime.datetime.now().strftime('%Y-%m-%d').split('-')
        opath = data['destination']['outpath'] + f"{dt[0]}/{dt[1]}/{dt[2]}/"
        lp = Path(opath)
        if not lp.exists():
            lp.mkdir(parents=True)
        outfile1 = opath + data['destination']['Warranty'] + '_' + \
                   datetime.datetime.now().strftime('%Y%m%d_%H%M') + '.prq'
        df1.to_parquet(outfile1)
        hive_data_load.load_data(df1, data['destination']['Warranty'], log_success)

        outfile2 = opath + data['destination']['Issue_merged'] + '_' + \
                   datetime.datetime.now().strftime('%Y%m%d_%H%M') + '.prq'
        df2.info()
        df2.to_parquet(outfile2)
        hive_data_load.load_data(df2, data['destination']['Issue_merged'], log_success)
        log_success.info('Output file is saved in parquet format')

    except Exception as e:
        log_failure.error(
            'Exception occurred while output file creation. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def main():
    """ main function """
    time = datetime.datetime.now()
    config = config_file()
    log_success.info("Read config file successfully")

    conn = hive_conn()

    # Reading all warranty and supporting tables
    warr_claim = pd.read_sql(config['source']['warrc'], conn)
    log_success.info('Shape of Warranty_claim :{}'.format(warr_claim.shape))

    warr_3c_comm = pd.read_sql(config['source']['warr3c'], conn)
    log_success.info(
        'Shape of Warranty_3c_comm :{}'.format(warr_3c_comm.shape))

    warr_c_comment = pd.read_sql(config['source']['warrcc'], conn)
    log_success.info(
        'Shape of Warranty_C_comment :{}'.format(warr_c_comment.shape))

    v_model = pd.read_sql(config['source']['vmodel'], conn)
    log_success.info('Shape of vmodel:{}'.format(v_model.shape))

    v_vehicle = pd.read_sql(config['source']['vvehicle'], conn)
    log_success.info('Shape of v_vehicle: {}'.format(v_vehicle.shape))

    v_status = pd.read_sql(config['source']['vstatus'], conn)
    log_success.info('Shape of v_status : {}'.format(v_status.shape))

    rdr_date = pd.read_sql(config['source']['rdrdate'], conn)
    log_success.info('Shape of rdr_date :{}'.format(rdr_date.shape))

    as400 = pd.read_sql(config['source']['as400'], conn)
    log_success.info('Shape of as400 :{}'.format(as400.shape))

    log_success.info(
        "Data count checking for warr_claim,warr_3c_comm,v_model,v_vehicle,v_status,rdr_date and as400")

    datacheck(warr_claim, warr_3c_comm, v_model,
              v_vehicle, v_status, rdr_date, as400)

    # Merging(inner join) warr_claim and warr_3c_comm on o_event_transaction_id
    warr_claim_merged = pd.merge(warr_claim, warr_3c_comm, on=[
                                 'o_event_transaction_id'], how='inner')
    log_success.info("merged shape of warr_claim, warr_3c_claim :{}".format(
        warr_claim_merged.shape))
    warr_claim_merged = duplicate_drop(warr_claim_merged)
    log_success.info(
        "Duplicates values for warr_claim_merged drop successfully")
    log_success.info("Shape of warr_claim_merged after dropping duplicates {}".format(
        warr_claim_merged.shape))

    log_success.info("Data count checking for warr_claim_merged")
    datacheck(warr_claim_merged)

    # Merging(left join) warr_claim_merged and warr_c_comment on o_event_transaction_id and claim_id
    if len(warr_c_comment) > 0:
        warr_claim_comment_merged = pd.merge(warr_claim_merged, warr_c_comment, on=[
                                             'o_event_transaction_id', 'claim_id'], how='left')
        log_success.info("merged shape of warr_claim, warr_3c_claim and warr_c_comment :{}".format(
            warr_claim_comment_merged.shape))
        warr_claim_comment_merged = duplicate_drop(warr_claim_comment_merged)
        log_success.info(
            "Duplicates values for warr_claim_comment_merged drop successfully")
        log_success.info("Shape of warr_claim_comment_merged after dropping duplicates {}".format(
            warr_claim_comment_merged.shape))
    else:
        log_success.info("No data available to join with warr_c_comment")
        warr_claim_merged['technician_comment'] = None
        warr_claim_comment_merged = warr_claim_merged

    log_success.info("Data count checking for warr_claim_comment_merged")
    datacheck(warr_claim_comment_merged)

    warr_claim_comment_merged = warranty_data_type_edit(
        warr_claim_comment_merged)

    # Dropping the null value of series_short_desc
    v_model = v_model_na_drop(v_model)

    # Dropping the null values of 'vin', 'v_model_id', 'brand_cd', 'model_year' for v_vehicle table
    v_vehicle = vehiclefilter(v_vehicle)

    # Merging(inner join) v_model and v_vehicle on v_model_id
    model_vehicle = pd.merge(v_model, v_vehicle, on=[
                             'v_model_id'], how='inner')
    log_success.info(
        "merged shape of vmodel and vvehicle :{}".format(model_vehicle.shape))
    model_vehicle = duplicate_drop(model_vehicle)
    log_success.info("Duplicates values for model_vehicle drop successfully")
    log_success.info("Shape of model_vehicle after dropping duplicates {}".format(
        model_vehicle.shape))

    v_status = vstatusfilter(v_status)

    # Merging(inner join) v_status and rdr_date on v_vehicle_id
    v_status_rdr_merged = pd.merge(v_status, rdr_date, on=[
                                   'v_vehicle_id'], how='inner')
    log_success.info("merged shape of vstatus and rdr :{}".format(
        v_status_rdr_merged.shape))
    v_status_rdr_merged = duplicate_drop(v_status_rdr_merged)
    log_success.info(
        "Duplicates values for v_status_rdr_merged drop successfully")
    log_success.info("Shape of v_status_rdr_merged after dropping duplicates {}".format(
        v_status_rdr_merged.shape))

    log_success.info(
        "Data count checking for model_vehicle and v_status_rdr_merged")
    datacheck(model_vehicle, v_status_rdr_merged)

    # Merging model_vehicle and v_status_rdr_merged  on v_vehicle_id
    status_model = pd.merge(
        model_vehicle, v_status_rdr_merged, on=['v_vehicle_id'])
    log_success.info("merged shpe of  vmodel , vvehicle, vstatus and rdr: {}".format(
        status_model.shape))
    status_model = duplicate_drop(status_model)
    log_success.info("Duplicates values for status_model drop successfully")
    log_success.info(
        "Shape of status_model after dropping duplicates {}".format(status_model.shape))

    log_success.info(" Data count checking ")
    datacheck(status_model)

    # Merging vehicle merged table and warranty merged table on v_vehicle_id and vin
    all_merged = pd.merge(status_model, warr_claim_comment_merged, on=[
                          'v_vehicle_id', 'vin'], how='inner')
    log_success.info(
        "shape of all the dataset merged: {}".format(all_merged.shape))
    all_merged = duplicate_drop(all_merged)
    log_success.info("Duplicates values for all_merged drop successfully")
    log_success.info(
        "Shape of all_merged after dropping duplicates {}".format(all_merged.shape))

    log_success.info("Data count checking for all_merged")
    datacheck(all_merged)

    as_ccd = asfilter_CCD(as400)

    # Merging(left join) all merged with as400(CCD) on cause_cd to get the cause_cd_descr column
    mer1 = pd.merge(all_merged, as_ccd, on=['cause_cd'], how='left')
    log_success.info(
        "shape of all the dataset merged with as400_CCD: {}".format(mer1.shape))
    mer1 = duplicate_drop(mer1)
    log_success.info("Duplicates values for mer1 drop successfully")
    log_success.info(
        "Shape of mer1 after dropping duplicates {}".format(mer1.shape))
    as_ncd = asfilter_NCD(as400)

    # Merging(left join) all merged with as400(NCD) on nature_cd to get the nature_cd_descr column
    mer2 = pd.merge(mer1, as_ncd, on=['nature_cd'], how='left')
    log_success.info(
        "shape of all the dataset merged with as400_NCD: {}".format(mer2.shape))
    mer2 = duplicate_drop(mer2)
    log_success.info("Duplicates values for mer2 drop successfully")
    log_success.info(
        "Shape of mer2 after dropping duplicates {}".format(mer2.shape))

    mer2 = na_replace(mer2)
    deduped = dedup(mer2)
    finaloutput_search = finaldata(deduped)
    issue_merge_Warranty = issue_merge(deduped)
    output_file(finaloutput_search, issue_merge_Warranty)
    log_success.info(f"Completed Execution in {runtime(time)}")

    return finaloutput_search


if __name__ == "__main__":
    print(
        f'Starting the Pre-processing steps for warrenty - {datetime.datetime.now().isoformat()}')
    main()
