#!/usr/bin/env python
# coding: utf-8

# Classification script
# The program reads data from issues_merged table and makes binary and multilabel predictions
# Developer : Thillaikkoothan Palanichamy
# Input file :sodas_srv_issues_mrgd
# Output file:Search Cluster File.parquet,Expanded File.parquet
# List of .py files called - text_cleaning.py,filter_classifier.py,multilabel_classification_py
#Date : 26/4/2022
# Time taken :


import json
from pyhive import hive
from utils.sodas_logger import LogConfig
from classification.text_cleaning import *
from classification.filter_classifier import *
from classification.multilabel_classification import *


# Specifying the config function that would help in generating success/failure logs
config = LogConfig()
log_success = config.create_success_log(param='Classifier')
log_failure = config.create_failure_log(param='Classifier')


# Config function. Using the log file to create success/failure logs
def configload():
    try:
        with open("config/preprocessing_labelling.json", "r") as jsonfile:
            data = json.load(jsonfile)

        return data
    except Exception as e:
        log_failure.error(
            'Exception occurred while loading the config file. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


# Defining a function that would help in tracking the runtime for the flow
def runtime(t):
    return f"{(datetime.datetime.now() - t).total_seconds():0.3f} seconds"


def hive_conn():
    """Function to connect with Hive - Analytical cluster"""
    try:
        data = configload()

        conn = hive.connect(host=data['host'], port=data['port'],
                            username=data['username'],
                            password=data['password'], auth=data['auth'])
        return conn
    except Exception as e:
        log_failure.error(
            'Exception occurred while hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def drop_col(df):
    """Writing a function that would retain the required columns from the input file. 
    Once the columns have been retained, a success log indicating the same is returned."""
    try:
        df = ret_cols(df)
        log_success.info('Columns retained successfully')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while dropping the columns. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def text_clean(df):
    """The below function is used for text pre-processing:
    Null values are dropped, remaining row values are converted to str
    Contractions are expanded
    The text is then lemmatized and relevant parts of speech are retained
    The stopwords are then removed from the text
    After each step appropriate success/failure logs are created
    """
    try:
        df['text'] = df['text'].dropna()
        log_success.info(
            'Shape of dataframe after dropping null values{}'.format(df.shape))
        df['text_new'] = df['text'].apply(str)
        log_success.info('Converted text column to string')
        df['text_new'] = df['text_new'].apply(lower_contraction)
        log_success.info('Lower cased the text and expanded the contractions')
        df['text_new'] = df['text_new'].apply(lemmatize)
        log_success.info(
            'Lemmatization Done. Relevant parts of speech retained and text is de')
        df['text_new'] = df['text_new'].apply(stopword_removal)
        log_success.info('Stopword removal done')
        log_success.info('Text Column cleaned successfully')
        return df
    except Exception as e:
        log_failure.error(
            'Text Column could not be cleaned : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def binary_pred(df):
    """Identifying direction-speed issues, that would be sent for multilabel predictions"""
    try:
        log_success.info(
            'Pre-trained binary classifier and tf-idf vectorizer have been loaded')
        voq, warr = make_binary_pred(df)
        log_success.info('Binary Prediction done successfully')
        return voq, warr
    except Exception as e:
        log_failure.error(
            'Binary Prediction could not be done : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def multi_pred(df_voq, df_warr):
    """Multilabel prediction function
    For the direction speed rows obtained from the above function, multilabel prediction is done
    The hazard and sub hazard category for each row is predicted. """
    try:
        log_success.info(
            'List of labels along with list of speed and direction issues specified')
        df_full, df_exp = make_multi_pred(df_voq, df_warr)
        log_success.info('Multilabel Prediction done successfully')
        return df_full, df_exp
    except Exception as e:
        log_failure.error(
            'Multilabel Prediction could not be done : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def source_selection(df):
    """Function for carrying out the classification
    Based on data availability in the daily load"""
    if df['source'].any() not in ('WARRANTY'):
        voq_binary = make_pred_voq(df)
        df_full, df_exp = make_multi_voq_new(voq_binary)
        df_exp = df_exp.rename(columns={"text": "issue_description"})
        df_exp['hazard_labelled_id'] = ''
        for i in range(len(df_exp)):
            df_exp['hazard_labelled_id'][i] = i
            df_exp = df_exp[cols_trim]
    elif df['source'].any() not in ('VOQ'):
        warr_binary = make_pred_warr(df)
        df_full, df_exp = make_multi_warr_new(warr_binary)
        df_exp = df_exp.rename(columns={"text": "issue_description"})
        df_exp['hazard_labelled_id'] = ''
        for i in range(len(df_exp)):
            df_exp['hazard_labelled_id'][i] = i
            df_exp = df_exp[cols_trim]
    else:
        voq_binary, warr_binary = binary_pred(df)
        df_full, df_exp = multi_pred(voq_binary, warr_binary)
        df_exp = df_exp.rename(columns={"text": "issue_description"})
    return df_full, df_exp


def output_file(df_full_new, df_exp):
    """The output files are written to parquet files that will be later used 
    in search cluster and alert generation"""
    df_full_new.to_parquet('Search cluster file.parquet')
    df_exp.to_parquet('Expanded file.parquet')


def main():
    cols_search = ['issues_mrgd_id', 'engine_litre_spec_name', 'labelled_date', 
                   'hazard_type_1', 'hazard_subtype_1', 'hazard_type_2', 
                   'hazard_subtype_2', 'hazard_type_3', 'hazard_subtype_3']
    data = configload()
    log_success.info("Config file read successful")
    conn = hive_conn()
    log_success.info("Hive connection successful")
    time = datetime.datetime.now()
    df = pd.read_sql(data['Source']['issues_table'], conn)
    df2 = df.copy()
    df2 = df2.drop(['labelled_date', 'hazard_type_1', 'hazard_subtype_1',
                    'hazard_type_2', 'hazard_subtype_2', 'hazard_type_3',
                    'hazard_subtype_3'], axis=1)
    if len(df) != 0:
        log_success.info('Shape of input file : {} '.format(df.shape))
        df = drop_col(df)
        df = text_clean(df)
        df_full, df_exp = source_selection(df)
        df_full = df_full[cols_search]
        df_full_new = pd.merge(df2, df_full, on='issues_mrgd_id', how='left')
        df_full_new = df_full_new.rename(
            columns={"text": "issue_description", "issues_mrgd_id": "sodas_sd_dataset_id"})
        df_full_new = df_full_new[search_cols]
    
    log_success.info(
        'Number of rows written to output file: {}'.format(df_full_new.shape))
    log_success.info(
        'Number of rows written to expanded file: {}'.format(df_exp.shape))
    log_success.info('Output File written for search cluster and alerting ')
    log_success.info("Completed Execution in {}".format(runtime(time)))
    return df_full_new, df_exp


if __name__ == "__main__":
    log_success.info(
        'Starting the Classification  - {}'.format(datetime.datetime.now().isoformat()))
    df_full_new, df_exp = main()
    output_file(df_full_new, df_exp)
