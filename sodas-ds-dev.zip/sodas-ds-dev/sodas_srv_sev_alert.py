# The script has a block header with the following details:
# Program Name - sodas_srv_sev_alert
# Description - This code generates severity alerts based on defined rules on daily preprocessed VOQ data load.
# Author/Developer Name - Rishi Nigam
# Input file Name/Input Database Name - sodas_srv_nhtsa_voq_processed, sodas_srv_issues_mrgd
# Output file Name/Output Database Name - sodas_srv_severity_alerts
# List of called programs -
# Date of Development- 6th April,2022
# Approximate time to execute the code -

# Importing all necessary libraries
import json
import datetime
import pandas as pd
import numpy as np
import warnings
from pathlib import Path
from utils import hive_data_load
from utils import sodas_logger

warnings.filterwarnings("ignore")

# Initializing log parameters
config = sodas_logger.LogConfig()
log_success = config.create_success_log(param='Sev_alert')
log_failure = config.create_failure_log(param='Sev_alert')

# Initializing configuration file path
config_json = 'config/config_alert_generation.json'

# Loading config file
with open(config_json, "r") as f:
    config_file = json.load(f)

# Assigning variables from config file
# Rule definition for alert generation
death_threshold = config_file['severity']["death_threshold"]
injured_threshold = config_file['severity']['injured_threshold']
cmpl_type_1 = config_file['severity']['cmpl_type_1']
cmpl_type_2 = config_file['severity']['cmpl_type_2']
cmpl_type_3 = config_file['severity']['cmpl_type_3']
cmpl_type_4 = config_file['severity']['cmpl_type_4']

# Output table variables from config file
sev_alert_YY = config_file['severity']['sev_alert_YY']
source_sev = config_file['severity']['source_sev']
cols_needed_op = config_file['severity']['cols_needed_op']
alert_type = config_file['severity']['severity']
alert_status = config_file['severity']['alert_status']
created_by_sev = config_file['severity']['created_by_sev']

# Variables for hive connection
sev_hive_statment = config_file['hive_queries']['sev_hive_statment']
outpath = config_file['common']['outpath']
severity_output = config_file['severity']['severity_output']

# functions used
def pandas_date_conversion(df, column_name):
    '''
    Function to convert column into date time format
    '''
    df[column_name] = pd.to_datetime(df[column_name], errors='coerce')
    return df


def runningtime(t):
    '''
    Function to calculate the run time.
    '''
    now = datetime.datetime.now()
    diff = now - t
    return f"{(diff).total_seconds():0.3f} seconds"


def extract_voq_data(df):
    ''' 
    Function to filter based on VOQ and Current date
    '''
    try:
        df['processed_date'] = df['processed_date'].replace(
            {',': '/'}, regex=True)
        df['issue_date'] = df['issue_date'].replace({',': '/'}, regex=True)
        df = pandas_date_conversion(df, 'processed_date')
        df = pandas_date_conversion(df, 'labelled_date')
        df = pandas_date_conversion(df, 'issue_date')
        Today = pd.to_datetime('today').normalize()
        df = df[(df['processed_date'] == Today) & (df['source'] == source_sev)]
        log_success.info('Filter based on today date and source')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while converting date fromat. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def apply_sev_rule(df):
    '''
    Severity rules -
    deaths > 0
    injured > 0
    cmpl_type = 'RC' | 'RP' | 'CON' | 'DP'
    '''
    try:
        df['deaths'] = df['deaths'].astype(int)
        df['injured'] = df['injured'].astype(int)
        df = df[(df['deaths'] > death_threshold) |
                (df['injured'] >= injured_threshold) |
                ((df['cmpl_type'] == cmpl_type_1) | (df['cmpl_type'] == cmpl_type_2) | (
                    df['cmpl_type'] == cmpl_type_3) | (df['cmpl_type'] == cmpl_type_4))
                ]
        df.reset_index(inplace=True)
        log_success.info('Severity rules are applied successfully')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while applying the severity rules. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def sev_alert_type(df_input_merged):
    '''
    Function to identify severity alert type and severity alert index
    '''
    df_input_merged['severity_alert_type'] = np.where(df_input_merged['deaths'] > 0, 'deaths',
                                                      np.where((df_input_merged['deaths'] == 0) & (df_input_merged['injured'] > 0), 'injured',
                                                               'cmpl_type'))

    df_input_merged['severity_index'] = np.where((df_input_merged['severity_alert_type'] == 'deaths') |
                                                 (df_input_merged['severity_alert_type'] == 'injured'), 5, 4)
    log_success.info(
        'severity_alert_type and severity_index columns have been populated successfully')
    return df_input_merged


def severity_alert_PK(df_result):
    '''
    Function to format the severity alert database column
    '''
    #df_result = df_result.drop('INDEX', axis=1)
    # df_result.reset_index(inplace=True)
    df_result['severity_alert_pk'] = np.arange(1, len(df_result) + 1)
    return df_result


def alert_UK(df_result, column_name_needed="alert_uk"):
    '''
    Function to format the severity alert database column
    '''
    dt = datetime.datetime.now().strftime('%Y-%m-%d').split('-')
    df_result[column_name_needed] = sev_alert_YY + '_' + dt[0] + dt[1] + dt[2] + '_' + \
        df_result['severity_alert_pk'].apply(lambda x: '{0:0>4}'.format(x)).astype(str)
    return df_result


def output_data(df):
    """Function to save the output file"""
    try:
        dt = datetime.datetime.now().strftime('%Y-%m-%d').split('-')
        opath = outpath + f"{dt[0]}/{dt[1]}/{dt[2]}/"
        lp = Path(opath)
        if not lp.exists():
            lp.mkdir(parents=True)
        outfile = opath + severity_output + '_' + \
            datetime.datetime.now().strftime('%Y%m%d_%H%M') + '.prq'
        df.to_parquet(outfile)
        log_success.info('Output file is saved in parquet format')
        hive_data_load.load_data(df, severity_output, log_success)
        log_success.info('Data pushed to Hive table')
    except Exception as e:
        log_failure.error(
            'Exception occurred while changing the data type. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def severity_data_model(df_result):
    '''
    Function to format the generated alerts into output hive table format
    '''
    df_result = sev_alert_type(df_result)
    df_result = severity_alert_PK(df_result)
    df_result = alert_UK(df_result)
    log_success.info(
        'severity_alert_pk and alert_uk columns have been populated successfully')
    # creating HC and sub hc columns
    tmstmp = datetime.datetime.now()
    if df_result.columns.tolist() not in cols_needed_op:
        df_result['rdr_date'] = ''
        df_result['rec_create_date'] = tmstmp
        df_result['rec_create_by'] = created_by_sev
        df_result['rec_update_by'] = created_by_sev
        df_result['rec_update_date'] = tmstmp
        df_result['assigned_to'] = ''
        df_result['source'] = source_sev
        df_result['alert_status'] = alert_status
        df_result['alert_type'] = alert_type
        df_result['hazard_type'] = ''
        df_result['hazard_subtype'] = ''
    df_result = df_result[cols_needed_op]
    return df_result


def create_empty_dataframes(cols_needed_op):
    '''
    Create empty dataframe if no alerts are there
    '''
    try:
        result_df = pd.DataFrame(columns=cols_needed_op)
        return(result_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while writing empty files. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def main():
    try:
        # Reading VOQ processed data and Issue merged data
        df = hive_data_load.hive_query_data(sev_hive_statment, log_success)
        log_success.info(
            'Reading issues_merged and voq_processed data are successful')
        log_success.info('Shape of Processed VOQ Data : {} '.format(df.shape))
        # Applying severity rules on extracted data
        df_result = apply_sev_rule(df)
        if df_result.shape[0] > 0:
            df_result = severity_data_model(
                df_result)  # formating the alerts data
            log_success.info('Formatted the output based on datamodel layout')
            output_data(df_result)
            log_success.info(
                'Shape of final resultant : {} '.format(df_result.shape))
        else:
            #df_result = create_empty_dataframes(cols_needed_op)
            log_success.info(
                "No alerts generated. SODAS_SUM_SEVERITY_ALERT Output File is empty.")
    except Exception as e:
        log_failure.error('Improper files: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


if __name__ == '__main__':
    log_success.info('Starting the calculation of Severity based alerts - {}'.format(
        datetime.datetime.now().isoformat()))
    time = datetime.datetime.now()
    sev_final = main()
    log_success.info("Completed Execution in {}".format(runningtime(time)))
