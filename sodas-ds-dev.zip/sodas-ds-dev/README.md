# sodas-ds

Git repo to track all scripts and artifacts of Data Science track of SODAS project.

## Name
SODAS Data Science Track

## Description
This repository tracks all scripts, config files and artifacts related to the Data Science track of SODAS project.

## Installation
The required environment has already set up in BDP. Any local or other installation will require creating a Python environment (using either conda or pip) with libraries/packages of specified version as found in BDP.

## SODAS Phase 1
* Data Pre-processing
  - VOQ
  - Warranty

* Classification
  - Binary & multi-class
  - Model scoring (400 samples)

* Alerts
  - Severity
  - SAF I
  - SAF II
  - PAF

## Project status
Phase 1 is in development that is slated to be completed by April end.
SIT to begin first week of May
UAT to begin last week of May
