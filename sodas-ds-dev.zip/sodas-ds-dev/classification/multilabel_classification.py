#Importing joblib and pickle for loading pretrained classifier and vectorizers
import joblib
import pickle
import numpy as np
import pandas as pd
import datetime
import json

with open("config/preprocessing_labelling.json", "r") as jsonfile:
    data = json.load(jsonfile)

m_path = data['m_path']

#Loading the list of labels and pretrained multilabel classifier and tfidf vectorizer
idx2label = pickle.load(open(m_path+"/labelnew.pickle", "rb"))
classifier_tuned = joblib.load(m_path+"/Multname_jlib")
vect_mult = pickle.load(open(m_path+"/vect_mult.pickle", "rb"))

#Specifying the list of direction and speed sub hazards
speed_list = ['Partial or full loss of braking', 'Unintended Acceleration',
              'Loss of speed control due to ABS, stability control or traction control',
              'Park brake condition affecting safety', 'Difficulty/inability to control speed-Other',
              'Unintended activation of the brake system',
              'Transmission shifter able to be moved out of Park without first applying the brake',
              'Inability to disengage the cruise control when brake depressed']

dir_list = ['Partial or full loss of steering',
            'Difficulty/inability to control direction/path (steering, stability, etc.)-Other',
            "Unintentional movement of the driver's seat may affect the driver's ability to control the vehicle",
            'Partial or full loss of stability',
            'Tire contact with sharp edge on vehicle which could cause puncture']

#The order of columns in the dataframe that will be pushed for alert generation 'updated_dt'
cols_trim = ['hazard_labelled_id', 'issue_id', 'issue_description', 'source', 'transaction_id',
             'hazard_type', 'hazard_sub_type', 'rec_create_date', 'rec_create_by',
             'rec_update_by', 'rec_update_date']

search_cols = ['sodas_sd_dataset_id', 'issue_id', 'transaction_id', 'source', 'processed_date', 'labelled_date',
               'vin', 'issue_date', 'issue_description', 'make', 'model', 'model_year', 'production_date',
               'rdr_date', 'engine_litre_spec_name', 'compdesc', 'hazard_type_1',
               'hazard_subtype_1', 'hazard_type_2', 'hazard_subtype_2', 'hazard_type_3', 'hazard_subtype_3',
               'rec_create_date', 'rec_create_by',  'rec_update_by', 'rec_update_date']

def make_multi_voq_new(df_voq):
    """ Multilabel prediction for VOQ #Based on the sub hazard predicted, the hazard category will be populated"""
    voq_unlab = df_voq
    voq_unlab_vector = vect_mult.transform(voq_unlab['text_new'])
    preds = classifier_tuned.predict(voq_unlab_vector)
    preds = list(preds.toarray())
    pred_label_idxs_voq = []
    pred_label_texts_voq = []
    for vals in preds:
        pred_label_idxs_voq.append(np.where(vals)[0].flatten().tolist())
    for vals in pred_label_idxs_voq:
        if vals:
            pred_label_texts_voq.append([idx2label[val] for val in vals])
        else:
            pred_label_texts_voq.append(vals)
    voq_unlab['Sub-Hazard'] = pred_label_texts_voq
    # For search cluster file
    voq_unlab['hazard_subtype_1'] = ''
    voq_unlab['hazard_subtype_2'] = ''
    voq_unlab['hazard_subtype_3'] = ''
    voq_unlab['hazard_type_1'] = ''
    voq_unlab['hazard_type_2'] = ''
    voq_unlab['hazard_type_3'] = ''

    for i in range(len(voq_unlab)):
        voq_unlab['hazard_subtype_1'][i] = voq_unlab['Sub-Hazard'][i][0]
        if len(voq_unlab['Sub-Hazard'][i]) == 2:
            voq_unlab['hazard_subtype_2'][i] = voq_unlab['Sub-Hazard'][i][1]
        if len(voq_unlab['Sub-Hazard'][i]) >= 3:
            voq_unlab['Sub-Hazard'][i] = voq_unlab['Sub-Hazard'][i][:3]
            voq_unlab['hazard_subtype_2'][i] = voq_unlab['Sub-Hazard'][i][1]
            voq_unlab['hazard_subtype_3'][i] = voq_unlab['Sub-Hazard'][i][2]
            
    for i in range(len(voq_unlab)):
        if str(voq_unlab['hazard_subtype_1'][i]) in speed_list:
            voq_unlab['hazard_type_1'][i] = 'Difficulty/inability to control speed'
        else:
            voq_unlab['hazard_type_1'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'

        if str(voq_unlab['hazard_subtype_2'][i]) in speed_list:
            voq_unlab['hazard_type_2'][i] = 'Difficulty/inability to control speed'
        elif str(voq_unlab['hazard_subtype_2'][i]) in dir_list:
            voq_unlab['hazard_type_2'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
        if str(voq_unlab['hazard_subtype_3'][i]) in speed_list:
            voq_unlab['hazard_type_3'][i] = 'Difficulty/inability to control speed'
        elif str(voq_unlab['hazard_subtype_3'][i]) in dir_list:
            voq_unlab['hazard_type_3'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'

    #For service table and alert generation
    voq_new = voq_unlab.drop(['text_new', 'hazard_subtype_1', 'hazard_subtype_2',
                              'hazard_subtype_3', 'hazard_type_1', 'hazard_type_2', 'hazard_type_3'], axis=1)
    voq_new = voq_new.rename(columns = {"Sub-Hazard":'sub_hazard'})
    voq_explode = voq_new.explode('sub_hazard')
    voq_explode = voq_explode.reset_index().drop('index', axis=1)
    voq_explode['hazard_type'] = ''
    for i in range(len(voq_explode)):
        if str(voq_explode['sub_hazard'][i]) in speed_list:
            voq_explode['hazard_type'][i] = 'Difficulty/inability to control speed'
        elif str(voq_explode['sub_hazard'][i]) in dir_list :
            voq_explode['hazard_type'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
    voq_explode = voq_explode.rename(columns={'sub_hazard':'hazard_sub_type'})
    voq_unlab = voq_unlab.rename(columns = {'text':'issue_description'})
    voq_unlab = voq_unlab.drop(['Sub-Hazard','text_new'], axis=1)
    voq_unlab['labelled_date'] = datetime.datetime.now().strftime("%Y-%m-%d")
    voq_unlab = voq_unlab.reset_index().drop('index', axis=1)
    return voq_unlab, voq_explode


def make_multi_warr_new(df_warr):
    """ Multilabel prediction for Warranty
    Based on the sub hazard predicted, the hazard category will be populated"""
    warr_unlab = df_warr
    warr_unlab_vector = vect_mult.transform(warr_unlab['text_new'])
    preds = classifier_tuned.predict(warr_unlab_vector)
    preds = list(preds.toarray())
    pred_label_idxs_warr = []
    pred_label_texts_warr = []
    for vals in preds:
        pred_label_idxs_warr.append(np.where(vals)[0].flatten().tolist())
    for vals in pred_label_idxs_warr:
        if vals:
            pred_label_texts_warr.append([idx2label[val] for val in vals])
        else:
            pred_label_texts_warr.append(vals)

    #For search cluster table
    warr_unlab['Sub-Hazard'] = pred_label_texts_warr
    warr_unlab['hazard_subtype_1'] = ''
    warr_unlab['hazard_subtype_2'] = ''
    warr_unlab['hazard_subtype_3'] = ''
    warr_unlab['hazard_type_1'] = ''
    warr_unlab['hazard_type_2'] = ''
    warr_unlab['hazard_type_3'] = ''
    for i in range(len(warr_unlab)):
        warr_unlab['hazard_subtype_1'][i] = warr_unlab['Sub-Hazard'][i][0]
        if len(warr_unlab['Sub-Hazard'][i]) == 2:
            warr_unlab['hazard_subtype_2'][i] = warr_unlab['Sub-Hazard'][i][1]
        if len(warr_unlab['Sub-Hazard'][i]) >= 3:
            warr_unlab['Sub-Hazard'][i] = warr_unlab['Sub-Hazard'][i][:3]
            warr_unlab['hazard_subtype_2'][i] = warr_unlab['Sub-Hazard'][i][1]
            warr_unlab['hazard_subtype_3'][i] = warr_unlab['Sub-Hazard'][i][2]
    for i in range(len(warr_unlab)):
        if str(warr_unlab['hazard_subtype_1'][i]) in speed_list:
            warr_unlab['hazard_type_1'][i] = 'Difficulty/inability to control speed'
        else:
            warr_unlab['hazard_type_1'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
        if str(warr_unlab['hazard_subtype_2'][i]) in speed_list:
            warr_unlab['hazard_type_2'][i] = 'Difficulty/inability to control speed'
        elif str(warr_unlab['hazard_subtype_2'][i]) in dir_list:
            warr_unlab['hazard_type_2'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
        if str(warr_unlab['hazard_subtype_3'][i]) in speed_list:
            warr_unlab['hazard_type_3'][i] = 'Difficulty/inability to control speed'
        elif str(warr_unlab['hazard_subtype_3'][i]) in dir_list :
            warr_unlab['hazard_type_3'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
        #For service cluster and alert generation
    warr_new = warr_unlab.drop(['text_new', 'hazard_subtype_1', 'hazard_subtype_2', 'hazard_subtype_3',
                              'hazard_type_1', 'hazard_type_2', 'hazard_type_3'], axis=1)
    warr_new = warr_new.rename(columns={"Sub-Hazard":'sub_hazard'})
    warr_explode = warr_new.explode('sub_hazard')
    warr_explode = warr_explode.reset_index().drop('index', axis=1)
    warr_explode['hazard_type'] = ''
    for i in range(len(warr_explode)):
        if str(warr_explode['sub_hazard'][i]) in speed_list:
            warr_explode['hazard_type'][i] = 'Difficulty/inability to control speed'
        elif str(warr_explode['sub_hazard'][i]) in dir_list :
            warr_explode['hazard_type'][i] = 'Difficulty/inability to control direction/path (steering, stability, etc.)'
    warr_explode = warr_explode.rename(columns={'sub_hazard':'hazard_sub_type'})
    warr_unlab = warr_unlab.rename(columns = {'text':'issue_description'})
    warr_unlab = warr_unlab.drop(['Sub-Hazard','text_new'], axis=1)
    warr_unlab['labelled_date'] = datetime.datetime.now().strftime("%Y-%m-%d")
    #warr_unlab['engine_litre_spec_name']=''
    warr_unlab=warr_unlab.reset_index().drop('index',axis=1)
    return warr_unlab,warr_explode


def make_multi_pred(df_voq, df_warr):
    """Combining the warranty and voq dataframes
    The function below will return two dataframes,one for search cluster The other for alert generation"""
    df_voq, df_voq_explode = make_multi_voq_new(df_voq)
    df_warr, df_warr_explode = make_multi_warr_new(df_warr)
    df_combined = pd.concat([df_voq, df_warr])
    df_explode = pd.concat([df_voq_explode, df_warr_explode])
    df_combined = df_combined.reset_index().drop('index',axis=1)
    df_explode['hazard_labelled_id'] = ''
    for i in range(len(df_combined)):
        df_explode['hazard_labelled_id'][i] = i+1
    df_explode = df_explode[cols_trim]
    df_explode = df_explode.rename(columns={"text" : "issue_description"})
    df_combined['labelled_date'] = datetime.datetime.now().strftime("%Y-%m-%d")
    return df_combined, df_explode