#Importing joblib and pickle for loading pretrained classifier and vectorizers
import joblib
import pickle
import json

with open("config/preprocessing_labelling.json", "r") as jsonfile:
    data = json.load(jsonfile)

m_path = data['m_path']

#Loading the pretrained classifier and vectorizer
vect_bin = pickle.load(open(m_path + "/vect_bin.pickle", "rb"))
lr = joblib.load(m_path + "/Binary_jlib")

def make_pred_voq(df):
    """ Making predictions for VOQ Source.
    Post the classification,only rows belonging to direction-speed will be retained"""
    voq_unlab = df[df['source'] == 'VOQ']
    voq_unlab = voq_unlab.reset_index().drop('index', axis = 1)
    voq_unlab_vector = vect_bin.transform(voq_unlab['text_new'])
    voq_unlab['Flag'] = lr.predict(voq_unlab_vector)
    voq_unlab = voq_unlab[voq_unlab['Flag'] == 0]
    voq_unlab = voq_unlab.reset_index().drop('index', axis = 1)
    voq_unlab = voq_unlab.drop(['Flag'], axis = 1)
    return voq_unlab

def make_pred_warr(df):
    """ Making predictions for Warranty Source.
    Post the classification,only rows belonging to direction-speed will be retained"""
    warr_unlab = df[df['source'] == 'WARRANTY']
    warr_unlab = warr_unlab.reset_index().drop('index', axis = 1)
    warr_unlab_vector = vect_bin.transform(warr_unlab['text_new'])
    warr_unlab['Flag'] = lr.predict(warr_unlab_vector)
    warr_unlab = warr_unlab[warr_unlab['Flag'] == 0]
    warr_unlab = warr_unlab.reset_index().drop('index', axis = 1)
    warr_unlab = warr_unlab.drop(['Flag'], axis = 1)
    return warr_unlab


def make_binary_pred(df):
    """ The function below will return two dataframes, one for VOQ and Warranty
     The dataframes will be pushed for multilabel classification"""
    df_voq = make_pred_voq(df)
    df_warr = make_pred_warr(df)
    return df_voq, df_warr
