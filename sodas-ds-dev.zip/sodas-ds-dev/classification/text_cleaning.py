#Importing initial libraries

import warnings
warnings.filterwarnings("ignore")
import pandas as pd
pd.options.mode.chained_assignment = None
import re

#Nltk Library
from nltk.tokenize import word_tokenize
from nltk.tokenize.treebank import TreebankWordDetokenizer

#Spacy
import spacy
from spacy.lang.en.stop_words import STOP_WORDS
nlp = spacy.load("en_core_web_sm", disable = ['parser', 'ner'])
allowed_postags = ['NOUN', 'ADJ', 'VERB']
sw = spacy.load('en_core_web_sm')

#custom stopword list
sw.Defaults.stop_words |= {'sonata', 'elantra', 'tucson', 'accent', 'santa fe',
                            'hyundai','cust','customer','states','state','hard','fine','vehicle',  
                            'checked','went','stiff','turn','cold','work','became',
                            'car','came','still','feels','shop','problem','back','get','wet','looks','esp',
                            'sudden','hit','says','int','got','sometimes','working','check','shift',
                            'occur','performed','steer','happened','right','client','visit','coming','red',
                            'making','started','gone','today','prior','appears','starting','acting','update',
                            'veh','last','difficult','night','come','driving','morning','around','also',
                            'going','run','hear','week','trac','issue','low','way','needs','minutes','guest',
                            'seems','diag','body','due','happen','please','since','randomly','move','lot',
                            'later','sterring','act','month','lite','involved','comes','awhile','yesterday',
                            'felt','pow','pwer','adn','chk','inop','complete','runs','make','pop','million',
                            'lamp','stay','previous','possible','locked','keep','notice','yaw','could','time',
                            'gets','pwr','warrantyt','found','wait','use','lit','stated','see','stoped','tcs',
                            'happens','high','slow','shows','stop','tsb','psteering','lost','front','every',
                            'min','stops','start','feeling','present','weekend','keeps','sitting','twice',
                            'cel','times','owenr','may','adv','tuesday','done','side','road','rack','lites',
                            'occurs','vehicel','air','tight','several','customerstates','makes','possibly',
                            'hwy','mile','hour','miles','contact','failure','accel','like','took','hour',
                            'tried','feel','order','ago','mostly','happening','placed','number','respond',
                            'short','feet','goes','cause','harsh','per','day','tech','loss','following','bag',
                            'dba','noise','must','ftout','yellow','unable',
                            'always','line','warr','advised','second','middle','nothing','dbc','awd','staes',
                            'suddenly','assit','spot','report','put','quit','till','while','tow',
                            'upon','event','want','shimmy','slip','shi','hub','sbd'}


def ret_cols(voq_unlab):
    """ Function for retaining required columns in the dataframe 'updated_dt'"""
    columns = ['issues_mrgd_id', 'transaction_id', 'issue_id', 'source', 'issue_description',
               'rec_create_date', 'rec_create_by',  'rec_update_by', 'rec_update_date']
    voq_unlab = voq_unlab[columns]
    voq_unlab = voq_unlab.rename(columns = {'issue_description':'text'})
    return voq_unlab


def lower_contraction(text):
    """ Lowercasing the text and expanding the contractions """
    text = text.lower()
    text = re.sub(r"mph", "miles per hour", text)
    text = re.sub(r"aren't", "are not", text)
    text = re.sub(r"cant", "cannot", text)
    text = re.sub(r"doesnt", " does not", text)
    text = re.sub(r"abs", "anti lock braking system", text)
    text = re.sub(r"esc", "electronic stability control", text)
    return text

def lemmatize(text):
    """Lemmatizing the text and retaining the relevant parts of speech. """
    text = nlp(text)
    text = [token.lemma_ for token in text if token.pos_ in allowed_postags]
    text = TreebankWordDetokenizer().detokenize(text)
    return text   

def stopword_removal(text):
    # Removing special characters
    text = re.sub('[^a-zA-Z]', ' ' ,str(text))
    # Removing url's from the text
    text = re.sub('\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*', ' ', text)
    # Removing additional special characters
    text = re.sub('<.*?>', ' ', text)
    # Removing time stamp
    text = re.sub('^(?:(?:[0-9]{2}[:\/,]){2}[0-9]{2,4}|am|pm)$', ' ', text)
    # Removing single characters from the text
    text = re.sub('\s+[a-zA-Z]\s+', ' ', text)
    # Removing unwanted whitespaces from the text
    text = re.sub('\W+|\s+', ' ', str(text))
    # Removing stopwords
    temp = []
    for j in word_tokenize(text):
        if len(j) > 2 and not j.lower() in STOP_WORDS:
            temp.append(j)            
    text = ' '.join(temp)
    text = ' '.join(text.split())
    return text