#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import warnings
import numpy as np
import json
import datetime
import sys
from pathlib import Path
from pyhive import hive
from preprocess import sodas_srv_vin_decoding
from utils import sodas_logger
from utils import hive_data_load


log = sodas_logger.LogConfig()
log_success = log.create_success_log(param='VOQ')
log_failure = log.create_failure_log(param='VOQ')
date = datetime.datetime.now().strftime("%Y%m%d_%H%M")


# Loading Json config file
def configload():
    """Function to load the config file"""
    try:
        with open("config/preprocessing.json", "r") as jsonfile:
            data = json.load(jsonfile)

        return data
    except Exception as e:
        log_failure.error(
            'Exception occurred while loading the config file. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def hive_conn():
    """Function to connect with Hive - Analytical cluster"""
    try:
        data = configload()
        conn = hive.connect(host=data['host'], port=data['port'],
                            username=data['username'],
                            password=data['password'], auth=data['auth'])
        log_success.info("Hive connection successful")
        return conn
    except Exception as e:
        log_failure.error(
            'Exception occurred while hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def runtime(t):
    return f"{(datetime.datetime.now() - t).total_seconds():0.3f} seconds"


def datacheck(*datasets):
    """Function for Data count check"""
    try:
        for dataset in datasets:
            if len(dataset) > 0:
                log_success.info(" Data check done successfully")
            else:
                log_success.info("Data is not available to proceed")
                return sys.exit("Data is not available to proceed")
    except Exception as e:
        log_failure.error(
            'Exception occurred while hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def voq_vinlist(voqdata, vindata):
    """
    Function to fetch full vin from vindata and replace the 
    incomplete or NaN VIN available in voqdata.
    """
    try:
        voqdata = voqdata.set_index('odino')
        vindata = vindata.set_index('odi_id')
        voqdata.update(vindata)
        log_success.info('Updated the vin of VOQ fom vin of vin_list table')
        voqdata.reset_index(inplace=True)
        log_success.info('Index got reset')
        return voqdata
    except Exception as e:
        log_failure.error(
            'Exception occurred while merging voq with vinlist. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def vin_decode(new_df, df):
    """
    Function to get the manufacturer name and vin year with the help of VIN decoding Script.
    Input : VIN
    Output : Manufacturer and VIN year
    """
    try:
        p = []
        year = []
        for i in new_df['vin']:
            p.append(sodas_srv_vin_decoding.VinDecoding(i).model_manu())
            year.append(sodas_srv_vin_decoding.VinDecoding(i).model_year())
        new_df['new_manufacturer'] = p
        new_df['vinyear'] = year
        new_df = new_df.filter(['new_manufacturer', 'vinyear'], axis=1)
        df = df.join(new_df, how='left')
        log_success.info(
            'Added columns new_manufacturer and vinyear with the help of VIN decoding')
        return(df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while adding the columns new_manufacturer and vinyear. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def vin_decoding_data(df):
    """Function to call Vun decoding script"""
    try:
        newdf = df.loc[df['vin'].notna()]
        newdf['vin'] = newdf['vin'].str.upper()
        output_df = vin_decode(newdf, df)
        log_success.info('VIN decoding done successfully')

        return output_df
    except Exception as e:
        log_failure.error(
            'Exception occurred while decoding the VIN. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def manu_name(manufacturer_df):
    """
    Function to fill the blank manufacturer name with the help of VIN decoding Script.
    Input : Rows where manufacturer and make text is null
    Output : Fetched manufacturer name with the help of VIN decoding Script
    """
    try:

        manufacturer_df['mfr_name'] = manufacturer_df['mfr_name'].fillna(
            manufacturer_df['maketxt'])
        blank_mfr = manufacturer_df[['mfr_name', 'maketxt']].apply(
            lambda x: x.str.strip()).replace('', np.nan)
        manufacturer_df['mfr_name'] = blank_mfr['mfr_name']
        manufacturer_df['maketxt'] = blank_mfr['maketxt']

        new_df = manufacturer_df[manufacturer_df['mfr_name'].isnull(
        ) & manufacturer_df['maketxt'].isnull() & manufacturer_df['vin'].notnull()]
        log_success.info(
            'Shape of dataframe of where manufacturer is Null and maketxt is Null : {} '.format(new_df.shape))

        manufacturer_df['mfr_name'] = np.where(((manufacturer_df.mfr_name.isna()) & (
            manufacturer_df.maketxt.isna())), manufacturer_df.new_manufacturer, manufacturer_df['mfr_name'])

        return manufacturer_df
    except Exception as e:
        log_failure.error(
            'Exception occurred while replacing manufacturer name. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def top_model(top, df):
    """
    Function to fetch the top models
    """
    try:
        data = configload()
        top['mfr_name'] = top['mfr_name'].astype(str)
        hyundai_df = top[top['mfr_name'].str.upper().str.contains(data['mfr_name'])]

        log_success.info(
            'Shape of dataframe where mfr_name = Hyundai Motor America : {} '.format(hyundai_df.shape))

        p = set(df["model"].values)

        topmodel = hyundai_df.apply(
            lambda row: row[hyundai_df['modeltxt'].isin(p)])
        log_success.info('Data filtered for top 5 make/models : {}'.format(p))
        log_success.info(
            'Shape of dataframe of top model : {} '.format(topmodel.shape))
        return topmodel
    except Exception as e:
        log_failure.error(
            'Exception occurred while filtering out for top models. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def fill_null(filln):
    """
    Fuction to replace null faildate values with datea
    """
    try:
        filln['faildate'].fillna(filln['datea'], inplace=True)
        log_success.info('Null Datea values are replaced with faildate')
        return filln
    except Exception as e:
        log_failure.error(
            'Exception occurred while null value filling of datea column. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def year_text_filter(df):
    """Function to replaced the yeartxt with vin_year where vin is not null"""
    try:
        df['yeartxt'] = np.where(
            (df['vinyear'].notnull()), df['vinyear'], df['yeartxt'])
        log_success.info(
            'yeartxt replaced with vinyear where the vinyear is notnull')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while year_text_filter. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def faildate_year_column(df):
    """Function for adding the faildate_year column for filtering purpose"""
    try:
        df['faildate'] = pd.to_datetime(
            df['faildate'], format="%Y%m%d", errors='coerce')
        df['faildate_year'] = pd.to_datetime(df['faildate']).dt.year
        log_success.info('faildate_year column is added succefully')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while year_text_filter. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def faildate_filter(df):
    """Function for filtering the data which have faildate_year greater than or equal to 1990"""
    try:
        newdf = df[(df.faildate_year >= 1990)]
        log_success.info(
            'Filtered the dataframe over faildate_year greater than or equal to 1990 {}'.format(newdf.shape))
        return newdf
    except Exception as e:
        log_failure.error(
            'Exception occurred while year_text_filter. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def dedup(df):
    """
    Function for de-duplication cmplid,odino,yeartxt,faildate,modeltxt
    Input = Dataframe with duplicated values
    Output = Dataframe with removed duplicates
    """
    try:
        grpby_lst = ['cmplid', 'odino', 'yeartxt', 'faildate', 'modeltxt',
                     'datea', 'ldate', 'cdescr']
        agg_dct = {'mfr_name': 'last',
                   'maketxt': 'last',
                   'crash': 'last',
                   'fire': 'last',
                   'injured': 'last',
                   'deaths': 'last',
                   'compdesc': ', '.join,
                   'city': 'last',
                   'state': 'last',
                   'vin': 'last',
                   'cmpl_type': 'last',
                   'fuel_sys': 'last',
                   'fuel_type': 'last',
                   'miles': 'last',
                   'occurences': 'last'
                   }
        dedup1 = df.groupby(grpby_lst).agg(agg_dct).reset_index()
        log_success.info(
            'Shape of VOQ after first dedup scenario : {} '.format(dedup1.shape))
        return dedup1
    except Exception as e:
        log_failure.error(
            'Exception occurred while deduplication. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def dedup2(df):
    """
    Function for de-duplication based on odino,yeartxt,faildate,modeltxt,datea,ldate
    Input = Dataframe with duplicated values
    Output = Dataframe with removed duplicates
    """
    try:
        grpby_lst = ['odino', 'yeartxt', 'faildate',
                     'modeltxt', 'ldate', 'cdescr']
        agg_dct = {'cmplid': 'last',
                   'mfr_name': 'last',
                   'maketxt': 'last',
                   'crash': 'last',
                   'fire': 'last',
                   'injured': 'last',
                   'deaths': 'last',
                   'compdesc': ', '.join,
                   'city': 'last',
                   'state': 'last',
                   'vin': 'last',
                   'datea': 'last',
                   'cmpl_type': 'last',
                   'fuel_sys': 'last',
                   'fuel_type': 'last',
                   'miles': 'last',
                   'occurences': 'last'
                   }
        dedup2 = df.groupby(grpby_lst).agg(agg_dct).reset_index()
        log_success.info(
            'Shape of VOQ after second dedup scenario : {} '.format(dedup2.shape))
        return dedup2
    except Exception as e:
        log_failure.error(
            'Exception occurred while year_text_filter. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def final_data(df):
    """Function for creating the final dataframe"""
    try:
        
        issue_id = []
        for i in range(1, len(df)+1):
            issue_id.append(date + '_' + str(i))
        
        tmstmp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        df['VOQ_PROCESSED_ID'] = issue_id
        df.insert(1, 'PROCESSED_DATE', tmstmp[:10])
        df['rec_create_date'] = tmstmp
        df['rec_create_by'] = 'VOQ_Preprocess_Batch'
        df['rec_update_by'] = 'VOQ_Preprocess_Batch'
        df['rec_update_date'] = tmstmp
        fltr_lst = ['VOQ_PROCESSED_ID', 'PROCESSED_DATE',
                    'cmplid', 'odino', 'mfr_name', 'maketxt', 'modeltxt',
                    'yeartxt', 'crash', 'faildate', 'fire', 'injured',
                    'deaths', 'compdesc', 'city', 'state', 'vin', 'cdescr',
                    'cmpl_type', 'datea', 'ldate', 'miles', 'occurences',
                    'rec_create_date', 'rec_create_by', 'rec_update_by', 'rec_update_date']
        output = df.filter(fltr_lst, axis=1)
        output.columns = output.columns.str.lower()
        log_success.info(
            'Final structure is created according to the data model')
        return output

    except Exception as e:
        log_failure.error(
            'Exception occurred while creating the final dataframe. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def data_type_change(df):
    '''Function to chnage the data type in accordance with thh data model'''
    try:
        df['odino'] = df['odino'].astype(int, errors="ignore")
        df['yeartxt'] = df['yeartxt'].astype(int, errors="ignore")
        df['cmplid'] = df['cmplid'].astype(int, errors="ignore")
        df['injured'] = df['injured'].astype(int, errors="ignore")
        df['deaths'] = df['deaths'].astype(int, errors="ignore")
        df['datea'] = pd.to_datetime(
            df['datea'], format="%Y%m%d", errors='coerce')
        df['ldate'] = pd.to_datetime(
            df['ldate'], format="%Y%m%d", errors='coerce')
        log_success.info(
            'Data type changed for the columns odino,yeartxt,cmplid,injured,deaths')
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while changing the data type. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def issue_merge(df):
    """Function to push the data in issue merge"""
    try:
        tmstmp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        df['SOURCE'] = 'VOQ'
        df['PRODUCTION_DATE'] = ''
        df['RDR_DATE'] = ''
        df['processed_date'] = tmstmp[:10]
        df['rec_create_date'] = tmstmp
        df['rec_create_by'] = 'VOQ_Preprocess_Batch'
        df['rec_update_by'] = 'VOQ_Preprocess_Batch'
        df['rec_update_date'] = tmstmp
        log_success.info('New columns added successfully in table')
        df.rename(columns = {'odino': 'TRANSACTION_ID',
                             'cmplid': 'ISSUE_ID',
                             'faildate': 'ISSUE_DATE',
                             'cdescr': 'ISSUE_DESCRIPTION',
                             'maketxt': 'MAKE',
                             'modeltxt': 'MODEL',
                             'yeartxt': 'MODEL_YEAR'}, inplace = True)
        log_success.info('Column renamed successfully for voq table')
        
        issue_id = []
        for i in range(1,len(df)+1):
            issue_id.append(date + '_' + str(i))
        
        df['ISSUES_MRGD_ID'] = issue_id
        df['engine_litre_spec_name'] = ''
        
        output = df.filter(['ISSUES_MRGD_ID', 'TRANSACTION_ID', 'ISSUE_ID', 'SOURCE',
                            'processed_date', 'vin', 'ISSUE_DATE', 'ISSUE_DESCRIPTION',
                            'MAKE', 'MODEL', 'MODEL_YEAR', 'PRODUCTION_DATE', 'RDR_DATE',
                            'engine_litre_spec_name', 'compdesc', 'rec_create_date', 
                            'rec_create_by', 'rec_update_by', 'rec_update_date'], axis=1)
        output.columns = output.columns.str.lower()
        log_success.info('Final structure of issue merge is created according to the data model')
        return output
    
    except Exception as e:
        log_failure.error('Exception occurred while creating issue merge table. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def output_file(df1, df2):
    """Function to save the output file"""
    try:
        data = configload()
        df1['vin'].fillna(' ', inplace=True)
        df1.info()
        dt = datetime.datetime.now().strftime('%Y-%m-%d').split('-')
        opath = data['destination']['outpath'] + f"{dt[0]}/{dt[1]}/{dt[2]}/"
        lp = Path(opath)
        if not lp.exists():
            lp.mkdir(parents=True)
        outfile1 = opath + data['destination']['VOQ'] + '_' + \
                   datetime.datetime.now().strftime('%Y%m%d_%H%M') + '.prq'
        df1.to_parquet(outfile1)
        hive_data_load.load_data(df1, data['destination']['VOQ'], log_success)

        outfile2 = opath + data['destination']['Issue_merged'] + '_' + \
                   datetime.datetime.now().strftime('%Y%m%d_%H%M') + '.prq'
        df2['vin'].fillna(' ', inplace=True)
        df2.info()
        df2.to_parquet(outfile2)
        hive_data_load.load_data(df2, data['destination']['Issue_merged'], log_success)
        log_success.info('Output file is saved in parquet format')
    except Exception as e:
        log_failure.error(
            'Exception occurred while changing the data type. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def main():
    time = datetime.datetime.now()
    data = configload()

    log_success.info("Config file read successful")
    conn = hive_conn()

    voq = pd.read_sql(data['source']['voq'], conn)
    log_success.info('Shape of VOQ : {} '.format(voq.shape))
    vinlst = pd.read_sql(data['source']['vinlist'], conn)
    log_success.info('Shape of VINLST : {} '.format(vinlst.shape))
    model_master = pd.read_sql(data['source']['model_master'], conn)

    # Checking whether the dataframe is empty or not
    log_success.info("Data count checking for VOQ")
    datacheck(voq)

    voq = voq_vinlist(voq, vinlst)
    voq_new = vin_decoding_data(voq)
    voq_manu = manu_name(voq_new)
    datatop = top_model(voq_manu, model_master)
    datatop.drop_duplicates(inplace=True)
    log_success.info(
        'Shape after dropping duplicates : {} '.format(datatop.shape))
    voq_datafill = fill_null(datatop)
    year_text_filter_df = year_text_filter(voq_datafill)
    df_faildate_year = faildate_year_column(year_text_filter_df)

    df_year = faildate_filter(df_faildate_year)

    dedup_1 = dedup(df_year)
    dedup_2 = dedup2(dedup_1)

    final_preprocessed_data = final_data(dedup_2)

    final_preprocessed_data = data_type_change(final_preprocessed_data)
    log_success.info('Shape of final preprocessed data : {} '.format(
        final_preprocessed_data.shape))
    issue_merge_df = issue_merge(dedup_2)
    output_file(final_preprocessed_data, issue_merge_df)

    log_success.info(f"Completed Execution in {runtime(time)}")
    return (final_preprocessed_data)


if __name__ == "__main__":
    warnings.filterwarnings('ignore')

    log_success.info(
        f'Starting the Pre-processing steps for VOQ - {datetime.datetime.now().isoformat()}')
    main()
