#!/usr/bin/env python
# coding: utf-8


import re

"""
Python Version -- Python 3.8.8
Developer - Naveen Kumar
Reviewer - Roopa
"""


class VinDecoding():

    def __init__(self, vin):
        #self.df = df
        #self.VIN = VIN
        #self.VIN_List = VIN_List
        self.vin = vin

    def model_year(self):
        try:

            c_6_digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
            year_dict_1 = {'G': 1986, 'H': 1987, 'J': 1988, 'K': 1989,
                           'L': 1990, 'M': 1991, 'N': 1992, 'P': 1993,
                           'R': 1994, 'S': 1995, 'T': 1996, 'V': 1997,
                           'W': 1998, 'X': 1999, 'Y': 2000, '1': 2001,
                           '2': 2002, '3': 2003, '4': 2004, '5': 2005,
                           '6': 2006, '7': 2007, '8': 2008, '9': 2009}
            year_dict_2 = {'A': 2010, 'B': 2011, 'C': 2012, 'D': 2013,
                           'E': 2014, 'F': 2015, 'G': 2016, 'H': 2017,
                           'J': 2018, 'K': 2019, 'L': 2020, 'M': 2021,
                           'N': 2022}

            if len(self.vin) < 10:
                return (None)
            elif (self.vin[6].upper() in c_6_digits) and (self.vin[9].upper() in year_dict_1):
                return year_dict_1[self.vin[9].upper()]
            elif (self.vin[6].upper() not in c_6_digits) and (self.vin[9].upper() in year_dict_2):
                return year_dict_2[self.vin[9].upper()]
            else:
                return (None)
        except Exception as e:
            return ("Exception at model year +", e)

    def vin_validity(self):
        try:
            c_less_2000 = ['KMH', '2HM']
            c_less_2010 = ['KMH', 'KM8', 'KND', '5NP', '5NM']
            c_less_2020 = ['KMH', 'KM8', '3KP', '5NM', '5NP', '5XY']
            c_2020_and_on = ['KMH', 'KM8', '3KP', '5NM', '5NP', '5XY', '5NT']
            c_genesis_2018 = ['KMH', 'KMT', 'KMU']

            if len(self.vin) < 10:
                return (None)
            elif self.model_year() < 2000 and (self.vin[:3] in c_less_2000) and self.vin[3].upper() in ['B', 'C', 'J', 'L', 'V']:
                return ('VALID VIN')

            elif ((self.model_year() > 1999 and self.model_year() < 2010) and (self.vin[:3] in c_less_2010)
                  and self.vin[3].upper() in ['C', 'D', 'E', 'F', 'G', 'H', 'J', 'M', 'N', 'S', 'W']):
                return ('VALID VIN')

            elif ((self.model_year() > 2009 and self.model_year() < 2020) and (self.vin[:3] in c_less_2020)
                  and self.vin[3].upper() in ['C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'N', 'S', 'T', 'Z']):
                return ('VALID VIN')
            elif ((self.model_year() > 2018) and (self.vin[:3] in c_genesis_2018) and self.vin[3].upper() in ['F', 'G', 'H', 'M']):
                return ('VALID VIN')
            elif ((self.model_year() > 2019) and (self.vin[:3] in c_2020_and_on)
                  and self.vin[3].upper() in ['C', 'D', 'E', 'H', 'J', 'K', 'L', 'R', 'S', 'T']):
                return ('VALID VIN')
            else:
                return('INVALID VIN')
        except Exception as e:
            return ("Exception at VIN Validity +", e)

    def model_manu(self):
        try:
            manufacturer_1 = {'KMH': "Hyundai Korea (Passenger Vehicle)",
                              '2HM': "Hyundai Canada",
                              '5NP': "Hyundai USA Alabama (Passenger Vehicle)",
                              '3KP': "Kia Mexico (Passenger Vehicle)",
                              None: None
                              }
            manufacturer_2 = {'KMH': "Hyundai Korea (Multi-Purpose Vehicle - Venue)",
                              'KM8': "Hyundai Korea (Multi-Purpose Vehicle)",
                              'KND': "Hyundai Motor Group (Multi-Purpose Vehicle - Venue)",
                              '5NM': "Hyundai USA Alabama (Multi-Purpose Vehicle)",
                              '5XY': "Hyundai USA Georgia (Multi-Purpose Vehicle)",
                              '5NT': "Hyundai USA Georgia (Multi-Purpose Vehicle)",
                              None: None
                              }
            manufacturer_genesis = {'KMT': "Genesis, Passenger Vehicle(Hyundai Korea)",
                                    'KMH': "Genesis, Passenger Vehicle(Hyundai Korea)",
                                    'KMU': "Genesis, Multi-Purpose Vehicle(Hyundai Korea)",
                                    None: None}
            c3_2020_less_multi = ['J', 'K', 'N', 'S', 'Z']
            c3_2020_greater_pass = ['C', 'D', 'E', 'H', 'L', 'T']
            c3_2020_greater_multi = ['J', 'K', 'R', 'S']
            c3_genesis = ['G', 'H', 'F', 'M']

            if self.vin_validity() == 'VALID VIN':
                if self.vin[3].upper() in c3_2020_less_multi and self.model_year() < 2020:
                    return(manufacturer_2[self.vin[:3].upper()])
                elif self.vin[3].upper() in c3_2020_greater_multi and self.model_year() > 2019:
                    return(manufacturer_2[self.vin[:3].upper()])
                elif self.vin[3].upper() in c3_2020_greater_pass and self.model_year() > 2019:
                    return(manufacturer_1[self.vin[:3].upper()])
                elif self.vin[3].upper() in c3_genesis and self.model_year() >= 2020:
                    return manufacturer_genesis[self.vin[:3].upper()]
                else:
                    return manufacturer_1[self.vin[:3].upper()]
        except Exception as e:
            return("Exception at Model manu +", e)
