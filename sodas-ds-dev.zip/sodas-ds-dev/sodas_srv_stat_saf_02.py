############################ SAF_Scenario_2 ##########################################
# The script has a block header with the following details:
# Program Name- sodas_srv_stat_saf_02.py(Model,Model_Year,Prod_Year,Prod_Month,Hazard_type and Subhazard_type)
# Description - This script generates statistical alert for the combination of model, model_year, prod_year, prod_month, hazard_type and hazard_subtype
# Author/Developer Name -Rishi Nigam
# Input file Name/Input Database Name. sodas_srv_issues_merged, sodas_mas_srv_vehicle, sodas_srv_hazard_type, sodas_srv_subhazard_type
# Output file Name/Output Database Name. sodas_srv_statistical_alerts, sodas_srv_stat_alrt_chart_metadata, sodas_srv_stat_alrt_issue_metadata
# List of called programs.
# Date of Development- 6th April,2022
# Approximate time to execute the code-


import pandas as pd
import numpy as np
import datetime
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta
import json
import warnings
from pyhive import hive
import sys
from utils.sodas_logger import LogConfig


warnings.filterwarnings("ignore")
pd.set_option('display.max_columns', 500)

# Load Config file
config = 'config/config_alert_generation.json'

with open(config) as f:
    config_file = json.load(f)

config = LogConfig()
log_success = config.create_success_log(param='SAF2')
log_failure = config.create_failure_log(param='SAF2')

# run_time_model
run_time_model = sys.argv[1]
run_time_model_cmd = '\''+run_time_model+'\''

# Data model columns
stat_alert_column = config_file['statistical']['ALERT_columns']
stat_chart_metadata_column = config_file['statistical']['CHART_METADATA_columns']
issue_alert_metadata_column = config_file['statistical']['ISSUE_METADATA_columns']

# datab variables
number_of_months = config_file['common']['number_of_months']
threshold_value = config_file['common']['threshold_value']
claim_count_threshold = config_file['common']['claim_count_threshold']
last_12_months = config_file['common']['last_12_months']
one = config_file['common']['one']
percentile_25th = config_file['common']['percentile_25th']
percentile_75th = config_file['common']['percentile_75th']
host = config_file['hive_connection']['host']
username = config_file['hive_connection']['username']
password = config_file['hive_connection']['password']
port = config_file['hive_connection']['port']
vehicle_master_hive = config_file['hive_queries']['vehicle_master_hive'].format(
    run_time_model_cmd)
hazard_master_hive = config_file['hive_queries']['hazard_master_hive']
issue_hive_saf_2 = config_file['hive_queries']['issue_hive_saf_2'].format(
    run_time_model_cmd)


# Data model column variables
current_year_UK = config_file['statistical']['current_year_UK']
saf = config_file['statistical']['saf']
attribute_2 = config_file['statistical']['attribute_2']
alert_source = config_file['statistical']['source']
output_file_prefix_2 = config_file['statistical']['output_file_prefix_2']
chart_prefix = config_file['statistical']['CHART_METADATA_UK_prefix']
issue_prefix = config_file['statistical']['ISSUE_METADATA_UK_prefix']
alert_status = config_file['statistical']['alert_status']
scenario2_prefix = config_file['statistical']['scenario2_prefix']
created_by_2 = config_file['statistical']['created_by_2']
x_axis_label = config_file['statistical']['x_axis']
y_axis_label = config_file['statistical']['y_axis']
title = config_file['statistical']['title']
subtitle_2 = config_file['statistical']['subtitle_2']
alert_type = config_file['statistical']['alert_type']
drilldown = config_file['statistical']['STATISTICAL_ALERT_DRILLDOWN']

# Output file names
STATISTICAL_ALERT_file_name = config_file['statistical']['STATISTICAL_ALERT_file_name']
CHART_METADATA_file_name = config_file['statistical']['CHART_METADATA_file_name']
ISSUE_METADATA_file_name = config_file['statistical']['ISSUE_METADATA_file_name']


def hive_query_data(host='', username='', password='', port='', statement='', auth='CUSTOM'):
    '''
    connect to hive and get the input data
    '''
    try:
        host = config_file['hive_connection']['host']
        username = config_file['hive_connection']['username']
        password = config_file['hive_connection']['password']
        port = config_file['hive_connection']['port']
        conn = hive.connect(host=host, username=username,
                            password=password, port=port, auth=auth)
        data = pd.read_sql(statement, conn)
        return data
    except Exception as e:
        log_failure.error(
            'Exception occurred while connecting to hive and data is not read. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def runningtime(t):
    now = datetime.datetime.now()
    diff = now - t
    return f"{(diff).total_seconds():0.3f} seconds"


def issue_merged_data(vehicle, voq, warranty):
    try:
        warranty['PRODUCTION_DATE'] = pd.to_datetime(
            warranty['PRODUCTION_DATE'], errors='coerce')
        warranty['prod_month'] = warranty['PRODUCTION_DATE'].dt.month
        warranty['prod_year'] = warranty['PRODUCTION_DATE'].dt.year
        warranty['key'] = warranty['prod_year']+'_'+warranty['prod_month']
        col_rename = {'MODEL': 'model_name',
                      'MODELYEAR': 'model_year',
                      'HAZARD_TYPE': 'Hazard_Category',
                      'HAZARD_SUB_TYPE': 'SubHazard_Category'}
        warranty.rename(columns=col_rename, inplace=True)
        log_success.info('Issue merged data created successfully')
        return(warranty)
    except Exception as e:
        log_failure.error(
            'Exception occurred while creating Issue merged data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def check_12_month_prod(df, x, months_selected):
    '''
    input: date column (prod_date)
    output: prod_date <= present_date-12 & rdr_date <= present_date-12
    '''
    try:
        df[x] = pd.to_datetime(df[x], errors='coerce')
        months_ = -(months_selected)-2
        calculated_months = date.today() + relativedelta(months=months_)
        df = df[df[x].dt.date <= calculated_months]
        # print(df.shape)
        log_success.info("12 Months check applied")
        return df
    except Exception as e:
        log_failure.error(
            'Exception occurred while checing for 12 months. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def get_total_prod_count(df):
    '''
    Functionality: Get total prod count from vehicle master on basis of model_name and model_year
    '''
    try:
        df = adding_prod(df, 'production_date')
        df['production_date'] = pd.to_datetime(
            df['production_date'], errors='coerce')
        calculated_months = (
            date.today() + relativedelta(months=-last_12_months)).replace(day=1)
        df = df[df['production_date'].dt.date <= calculated_months]
        log_success.info(
            'Shape of vehicle master after production_date check ->{}'.format(df.shape))
        df = df.groupby(['model', 'model_year', 'prod_year', 'prod_month']).aggregate(
            {'production_date': 'count'})
        df = df.reset_index()
        df = df.rename(columns={'production_date': 'prod_count'})
        log_success.info('Total prod_count calculated')
        return(df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while get_total_prod_count. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def create_master_table(df1, df2):
    '''
    input: takes in vehicle_master_file_name and hazard_master_file_name
    output: merged df
    '''
    try:
        df3 = df1.assign(key=1).merge(df2.assign(
            key=1), on="key").drop("key", axis=1)
        log_success.info('Master table created')
        return df3
    except Exception as e:
        log_failure.error(
            'Exception occurred while merging . Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def adding_prod(df, date_column):
    '''
    get prod_month and prod_year
    '''
    df[date_column] = pd.to_datetime(df[date_column], errors='coerce')
    df['prod_month'] = df[date_column].dt.month
    df['prod_year'] = df[date_column].dt.year
    return df


def get_claim_month(number_of_months):
    '''
    Functionality: Create claim_month_df for last 14 months
    '''
    try:
        def get_last_months(start_date, months):
            for i in range(months):
                yield (start_date.year, start_date.month)
                start_date += relativedelta(months=-1)
        last_day_of_prev_month = date.today().replace(day=1) - timedelta(days=1)
        # list of months as tuples
        months = [i for i in get_last_months(
            last_day_of_prev_month, number_of_months)]
        # convert list of tuples in dataframe and changing column names
        claim_month_df = pd.DataFrame(months)
        claim_month_df = claim_month_df.rename(
            columns={0: 'claim_year', 1: 'claim_month'})
        # sort values
        claim_month_df = claim_month_df.sort_values(
            by=['claim_year', 'claim_month'])
        return (claim_month_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while getting claim month. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def create_alert(warranty_df, master_data, claim_month_df):
    try:
        count = 0
        alert_df = pd.DataFrame()
        detailed_df = pd.DataFrame()
        issue_df = pd.DataFrame()
        Master_data = master_data
        warranty_df = adding_prod(warranty_df, "production_date")
        col_rename = {'model': 'model_name',
                      'model_year': 'model_year',
                      'hazard_type': 'Hazard_Category',
                      'hazard_subtype': 'SubHazard_Category'}
        warranty_df.rename(columns=col_rename, inplace=True)

        for ind in Master_data.index:
            filtered_df = warranty_df[(warranty_df['model_name'] == Master_data['model'][ind]) &
                                      (warranty_df['model_year'] == Master_data['model_year'][ind]) &
                                      (warranty_df['prod_year'] == Master_data['prod_year'][ind]) &
                                      (warranty_df['prod_month'] == Master_data['prod_month'][ind]) &
                                      (warranty_df['Hazard_Category'] == Master_data['hazard_type'][ind]) &
                                      (warranty_df['SubHazard_Category'] == Master_data['hazard_subtype'][ind])]
            filtered_df['issue_date'] = pd.to_datetime(
                filtered_df['issue_date'], errors='coerce')
            filtered_df['claim_month'] = filtered_df['issue_date'].dt.month
            filtered_df['claim_year'] = filtered_df['issue_date'].dt.year

            grpby_lst = ['model_name', 'model_year', 'prod_month', 'prod_year', 
                         'claim_month', 'claim_year', 'Hazard_Category', 
                         'SubHazard_Category', 'processed_date', 'make']
            claim_count_df = filtered_df.groupby(grpby_lst, as_index=False)['issue_date'].count()
            claim_count_df = claim_count_df.rename(
                columns={'issue_date': 'claims_count'})
            claim_count_df['prod_count'] = Master_data['prod_count'][ind]
            claim_count_df = claim_count_df.sort_values(
                by=['claim_year', 'claim_month'])
            claim_count_df = claim_count_df[['claim_year', 'claim_month', 'prod_month', 
                                             'prod_year', 'model_name', 'model_year', 
                                             'Hazard_Category', 'SubHazard_Category', 
                                             'prod_count', 'claims_count', 'processed_date', 
                                             'make']]
            claim_final_df = pd.merge(claim_month_df, claim_count_df, on=[
                                      'claim_year', 'claim_month'], how='left')
            claim_final_df['model_name'] = claim_final_df['model_name'].fillna(
                Master_data['model'][ind])
            claim_final_df['model_year'] = claim_final_df['model_year'].fillna(
                Master_data['model_year'][ind])
            claim_final_df['prod_count'] = claim_final_df['prod_count'].fillna(
                Master_data['prod_count'][ind])
            claim_final_df['claims_count'] = claim_final_df['claims_count'].fillna(
                0)
            if (claim_final_df['claims_count'].tail(last_12_months).mean() > claim_count_threshold):
                claim_final_df['PP100'] = round(
                    (claim_final_df['claims_count']/claim_final_df['prod_count'])*100, 2)
                claim_final_df['PP100_MOVING_AVERAGE'] = round(
                    claim_final_df['PP100'].rolling(window=3).mean(), 2)
                Q1 = claim_final_df['PP100'].quantile(percentile_25th)
                Q3 = claim_final_df['PP100'].quantile(percentile_75th)
                IQR = percentile_75th*(Q3-Q1)
                claim_final_df['Q1'] = Q1
                claim_final_df['Q3'] = Q3
                claim_final_df['IQR'] = claim_final_df['Q3'] - \
                    claim_final_df['Q1']
                claim_final_df['REVISED_IQR'] = IQR
                median = claim_final_df['PP100'].median()
                claim_final_df['MEDIAN_VAL'] = claim_final_df['PP100'].median()
                claim_final_df['UPPER_CONTROL_LIMIT'] = round(IQR+median, 2)
                claim_final_df['LOWER_CONTROL_LIMIT'] = round(IQR-median, 2)
                claim_final_df['median_deviation'] = round(
                    (claim_final_df['PP100_MOVING_AVERAGE'] - median), 2)
                if IQR > 0:
                    claim_final_df['zscore'] = round(
                        (claim_final_df['median_deviation'] / IQR), 2)
                else:
                    claim_final_df['zscore'] = 0
                alert_df1 = claim_final_df[(claim_final_df['zscore'] > 1)]
                alert_df1['key'] = alert_df1['claim_year'].astype(
                    str)+'_'+alert_df1['claim_month'].astype(str)
                if alert_df1.shape[0] > threshold_value:
                    calculated_months = date.today() + relativedelta(months=-1)
                    selected_month_year = str(
                        calculated_months.year)+'_'+str(calculated_months.month)
                    alert_df1 = alert_df1[alert_df1['key']
                                          == selected_month_year]
                    alert_df = alert_df.append(alert_df1)
                    indicator = claim_final_df['claim_month'].iloc[-12:].notnull().reindex(
                        claim_final_df.index, fill_value=False)
                    claim_final_df['Claim_Month_Indicator'] = np.where(
                        indicator, 1, 0)
                    detailed_df = detailed_df.append(claim_final_df)
                    detailed_df = detailed_df
                    new_df = pd.merge(claim_month_df, filtered_df, on=[
                                      'claim_year', 'claim_month'], how='inner')
                    issue_df = issue_df.append(new_df)
        alert_df.reset_index(inplace=True)
        alert_df.drop(['index'], axis=1, inplace=True)
        detailed_df.reset_index(inplace=True)
        detailed_df.drop(['index'], axis=1, inplace=True)
        issue_df.reset_index(inplace=True)
        issue_df.drop(['index'], axis=1, inplace=True)
        log_success.info(
            'Alert df, detailed df and issue df created successfully')
        return(alert_df, detailed_df, issue_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while creating Alert df, detailed df and issue df. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def alert_df_data_model(alert_df):
    try:
        columns_needed = stat_alert_column
        alert_df.columns = alert_df.columns.str.upper()
        # print('alert_df cols: ',list(alert_df.columns))
        alert_df = alert_df.rename(columns={
            'MODEL_NAME': 'MODEL',
            'PROD_MONTH': 'PRODUCTION_MONTH',
            'PROD_YEAR': 'PRODUCTION_YEAR',
            'HAZARD_CATEGORY': 'HAZARD_TYPE',
            'SUBHAZARD_CATEGORY': 'HAZARD_SUBTYPE'
        })
        yy = str(date.today().year)[2:]
        mm = '{:02d}'.format(date.today().month)
        dd = '{:02d}'.format(date.today().day)
        if(list(alert_df.columns) not in columns_needed):
            alert_df['Counter'] = np.arange(1, len(alert_df)+1)
            alert_df['STATISTICAL_ALERT_PK'] = scenario2_prefix+yy+mm+dd+'_' + \
                (alert_df['Counter'].apply(
                    lambda x: '{0:0>4}'.format(x))).astype(str)
            alert_df['STATISTICAL_ALERT_TYPE'] = saf
            alert_df['ALERT_TYPE'] = alert_type
            alert_df['PROCESSED_DATE'] = pd.to_datetime('today').normalize()
            alert_df['STATISTICAL_ALERT_ATTR_SET'] = attribute_2
            alert_df['ALERT_STATUS'] = alert_status
            alert_df['ASSIGNED_TO'] = ''
            alert_df['REC_CREATE_DATE'] = pd.to_datetime('today').normalize()
            alert_df['REC_CREATE_BY'] = created_by_2
            alert_df['REC_UPDATE_BY'] = ''
            alert_df['REC_UPDATE_DATE'] = ''
            alert_df['COMPLAINT_TYPE'] = ''
            alert_df['TENURE_MONTH'] = ''
            alert_df['SOURCE'] = alert_source
        alert_df = alert_df[stat_alert_column]
        # print(alert_df.columns)
        return(alert_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while creating data model for alert data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def detailed_df_data_model(detailed_df, alert_df, run_time_model):
    detailed_df.columns = detailed_df.columns.str.upper()
    try:
        count = 0
        temp = pd.DataFrame()
        df1 = pd.DataFrame()
        yy = str(date.today().year)[2:]
        mm = '{:02d}'.format(date.today().month)
        dd = '{:02d}'.format(date.today().day)
        for ind in alert_df.index:
            temp = detailed_df[(detailed_df['MODEL_NAME'] == alert_df['MODEL_NAME'][ind]) &
                               (detailed_df['MODEL_YEAR'] == alert_df['MODEL_YEAR'][ind]) &
                               (detailed_df['PROD_YEAR'] == alert_df['PROD_YEAR'][ind]) &
                               (detailed_df['PROD_MONTH'] == alert_df['PROD_MONTH'][ind]) &
                               (detailed_df['HAZARD_CATEGORY'] == alert_df['HAZARD_CATEGORY'][ind]) &
                               (detailed_df['SUBHAZARD_CATEGORY'] == alert_df['SUBHAZARD_CATEGORY'][ind])]
            count += 1
            temp['STATISTICAL_ALERT_PK'] = count
            temp['ALERT_CHART_METADATA_PK'] = np.arange(1, len(temp)+1)
            df1 = df1.append(temp)
        columns_needed = stat_chart_metadata_column
        detailed_df = detailed_df.rename(columns={
            'PROD_COUNT': 'PRODUCTION_COUNT',
            'PROD_MONTH': 'PRODUCTION_MONTH',
            'PROD_YEAR': 'PRODUCTION_YEAR'
        })
        if(list(detailed_df.columns) not in columns_needed):
            detailed_df['ALERT_CHART_METADATA_PK'] = df1['ALERT_CHART_METADATA_PK']
            detailed_df['STATISTICAL_ALERT_PK'] = scenario2_prefix+run_time_model+'_'+yy+mm+dd + \
                '_' + \
                (df1['ALERT_CHART_METADATA_PK'].apply(
                    lambda x: '{0:0>4}'.format(x))).astype(str)
            detailed_df['TENURE_MONTH'] = ''
            detailed_df['STATISTICAL_ALERT_ATTR_SET'] = attribute_2
            detailed_df['THRESHOLD'] = threshold_value
            detailed_df['TITLE'] = title
            detailed_df['SUBTITLE'] = subtitle_2
            detailed_df['X_AXIS_LABEL'] = x_axis_label
            detailed_df['Y_AXIS_LABEL'] = y_axis_label
            detailed_df['REC_CREATE_DATE'] = pd.to_datetime(
                'today').normalize()
            detailed_df['REC_CREATE_BY'] = created_by_2
            detailed_df['REC_UPDATE_BY'] = ''
            detailed_df['REC_UPDATE_DATE'] = ''
            detailed_df['STATISTICAL_ALERT_DRILLDOWN'] = drilldown
            detailed_df['COMPLAINT_TYPE'] = ''
            detailed_df['TENURE_MONTH'] = ''
        detailed_df = detailed_df[stat_chart_metadata_column]
        detailed_df = detailed_df[~detailed_df['STATISTICAL_ALERT_PK'].isnull()]
        return(detailed_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while creating data model for chart_meta_data. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def issue_df_data_model(issue_df, alert_df, run_time_model):
    issue_df.columns = issue_df.columns.str.upper()
    try:
        count = 0
        temp = pd.DataFrame()
        df1 = pd.DataFrame()
        yy = str(date.today().year)[2:]
        mm = '{:02d}'.format(date.today().month)
        dd = '{:02d}'.format(date.today().day)
        for ind in alert_df.index:
            temp = issue_df[(issue_df['MODEL_NAME'] == alert_df['MODEL_NAME'][ind]) &
                            (issue_df['MODEL_YEAR'] == alert_df['MODEL_YEAR'][ind]) &
                            (issue_df['PROD_YEAR'] == alert_df['PROD_YEAR'][ind]) &
                            (issue_df['PROD_MONTH'] == alert_df['PROD_MONTH'][ind]) &
                            (issue_df['HAZARD_CATEGORY'] == alert_df['HAZARD_CATEGORY'][ind]) &
                            (issue_df['SUBHAZARD_CATEGORY'] == alert_df['SUBHAZARD_CATEGORY'][ind])]
            count += 1
            temp['STATISTICAL_ALERT_PK'] = count
            temp['ALERT_ISSUE_METADATA_PK'] = np.arange(1, len(temp)+1)
            df1 = df1.append(temp)
        columns_needed = issue_alert_metadata_column
        issue_df = issue_df.rename(columns={
            'MODEL_NAME': 'MODEL',
                                   'PROD_MONTH': 'PRODUCTION_MONTH',
                                   'PROD_YEAR': 'PRODUCTION_YEAR',
                                   'HAZARD_CATEGORY': 'HAZARD_TYPE',
                                   'SUBHAZARD_CATEGORY': 'HAZARD_SUBTYPE'})
        if(list(issue_df.columns) not in columns_needed):
            issue_df['ALERT_ISSUE_METADATA_PK'] = df1['ALERT_ISSUE_METADATA_PK']
            issue_df['STATISTICAL_ALERT_PK'] = scenario2_prefix+run_time_model+'_'+yy+mm+dd+'_' + \
                (df1['ALERT_ISSUE_METADATA_PK'].apply(
                    lambda x: '{0:0>4}'.format(x))).astype(str)
            issue_df['STATISTICAL_ALERT_ATTR_SET'] = attribute_2
            issue_df['ISSUE_ID'] = issue_df['TRANSACTION_ID']
            issue_df['CLAIM_NUM'] = np.arange(1, len(issue_df)+1)
            issue_df['CMPL_TYPE'] = ''
            issue_df['ALERT_TYPE'] = alert_type
            issue_df['REC_CREATE_DATE'] = pd.to_datetime('today').normalize()
            issue_df['REC_CREATE_BY'] = created_by_2
            issue_df['REC_UPDATE_BY'] = ''
            issue_df['REC_UPDATE_DATE'] = ''
            issue_df['COMPLAINT_TYPE'] = ''
            issue_df['TENURE_MONTH'] = ''
        issue_df = issue_df[issue_alert_metadata_column]
        issue_df = issue_df[~issue_df['STATISTICAL_ALERT_PK'].isnull()]
        return(issue_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while creating data model for issue_data. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def write_files(alert_df, detailed_df, issue_df, run_time_model):
    try:
        yy = str(date.today().year)[2:]
        mm = '{:02d}'.format(date.today().month)
        dd = '{:02d}'.format(date.today().day)
        file_name = output_file_prefix_2+run_time_model+'_'+yy+mm+dd
        alert_df.to_parquet(file_name+'.parquet', index=False)
        log_success.info('{} file written successfully.'.format(file_name))
        file_name = output_file_prefix_2+run_time_model+'_'+chart_prefix+yy+mm+dd
        detailed_df.to_parquet(file_name+'.parquet', index=False)
        log_success.info('{} file written successfully.'.format(file_name))
        file_name = output_file_prefix_2+run_time_model+'_'+issue_prefix+yy+mm+dd
        issue_df.to_parquet(file_name+'.parquet', index=False)
        log_success.info('{} file written successfully.'.format(file_name))
    except Exception as e:
        log_failure.error(
            'Exception occurred while writing files. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def write_files_csv(alert_df, detailed_df, issue_df, run_time_model):
    try:
        yy = str(date.today().year)[2:]
        mm = '{:02d}'.format(date.today().month)
        dd = '{:02d}'.format(date.today().day)
        file_name = output_file_prefix_2+run_time_model+'_'+yy+mm+dd
        alert_df.to_csv(file_name+'.csv', index=False)
        log_success.info(
            '{} file written successfully in csv format.'.format(file_name))
        file_name = output_file_prefix_2+run_time_model+'_'+chart_prefix+yy+mm+dd
        detailed_df.to_csv(file_name+'.csv', index=False)
        log_success.info(
            '{} file written successfully in csv format.'.format(file_name))
        file_name = output_file_prefix_2+run_time_model+'_'+issue_prefix+yy+mm+dd
        issue_df.to_csv(file_name+'.csv', index=False)
        log_success.info(
            '{} file written successfully in csv format.'.format(file_name))
    except Exception as e:
        log_failure.error(
            'Exception occurred while writing files. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def create_empty_dataframes(stat_alert_column, stat_chart_metadata_column, issue_alert_metadata_column):
    '''
    Create empty dataframe if no alerts are there
    '''
    try:
        alert_df = pd.DataFrame(columns=stat_alert_column)
        detailed_df = pd.DataFrame(columns=stat_chart_metadata_column)
        issue_df = pd.DataFrame(columns=issue_alert_metadata_column)
        return(alert_df, detailed_df, issue_df)
    except Exception as e:
        log_failure.error(
            'Exception occurred while writing empty files. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def main():
    # reading files from hive
    vehicle_master_data = hive_query_data(
        host, username, password, port, statement=vehicle_master_hive, auth='CUSTOM')
    log_success.info('Shape of vehicle_master Data : {} '.format(
        vehicle_master_data.shape))
    hazard_master_data = hive_query_data(
        host, username, password, port, statement=hazard_master_hive, auth='CUSTOM')
    log_success.info('Shape of hazard_master Data : {} '.format(
        hazard_master_data.shape))
    warranty_data = hive_query_data(
        host, username, password, port, statement=issue_hive_saf_2, auth='CUSTOM')
    log_success.info(
        'Shape of warranty Data : {} '.format(warranty_data.shape))
    log_success.info('All input files are read successfully')
    # Data verification
    if (warranty_data.shape[0] > 0) & (vehicle_master_data.shape[0] > 0) & (hazard_master_data.shape[0] > 0):
        # Data Manipulation
        vehicle_master = get_total_prod_count(vehicle_master_data)
        master_data = create_master_table(vehicle_master, hazard_master_data)
        issue_merged_df = check_12_month_prod(
            warranty_data, 'production_date', last_12_months)
        # print(issue_merged_df.columns)
        claim_month_df = get_claim_month(number_of_months)
        alert_df, detailed_df, issue_df = create_alert(
            issue_merged_df, master_data, claim_month_df)
        if alert_df.shape[0] > 0:
            data_model_alert_df = alert_df_data_model(alert_df)
            data_model_detailed_df = detailed_df_data_model(
                detailed_df, alert_df, run_time_model)
            data_model_issue_df = issue_df_data_model(
                issue_df, alert_df, run_time_model)
            log_success.info('Shape of Alert Data : {} '.format(
                data_model_alert_df.shape))
            log_success.info('Shape of Chart Meta Data : {} '.format(
                data_model_detailed_df.shape))
            log_success.info('Shape of Issue Meta Data : {} '.format(
                data_model_issue_df.shape))
        else:
            data_model_alert_df, data_model_detailed_df, data_model_issue_df = create_empty_dataframes(stat_alert_column,
                                                                                                       stat_chart_metadata_column, issue_alert_metadata_column)
            log_success.info(
                "No alerts generated. All Output Files are empty.")
    else:
        data_model_alert_df, data_model_detailed_df, data_model_issue_df = create_empty_dataframes(stat_alert_column,
                                                                                                   stat_chart_metadata_column, issue_alert_metadata_column)
        log_success.info('No Data found in . All Output Files are empty.')
    # Write output File
    write_files(data_model_alert_df, data_model_detailed_df,
                data_model_issue_df, run_time_model)
    write_files_csv(data_model_alert_df, data_model_detailed_df,
                    data_model_issue_df, run_time_model)
    log_success.info("Completed Execution in {}".format(runningtime(time)))


if __name__ == "__main__":
    log_success.info(
        'Starting the script for SAF Scenario-2 - {}'.format(datetime.datetime.now().isoformat()))
    time = datetime.datetime.now()
    saf_2 = main()
