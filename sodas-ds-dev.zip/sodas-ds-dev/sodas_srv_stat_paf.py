############################ PAF #######################################################################

# The script has a block header with the following details:
# Program Name- sodas_srv_stat_paf(Model,Model_Year,Hazard and Sub-hazard category)
# Description - This script generates statistical alert for the combination of model, model_year, hazard_type and hazard_subtype
# Author/Developer Name -Abhinav Khandelwal
# Input file Name/Input Database Name. sodas_srv_issues_merged, sodas_mas_srv_vehicle, sodas_srv_hazard_type, sodas_srv_subhazard_type
# Output file Name/Output Database Name. sodas_srv_statistical_alerts, sodas_srv_stat_alrt_chart_metadata, sodas_srv_stat_alrt_issue_metadata
# List of called programs.
# Date of Development- 6th April,2022
# Approximate time to execute the code-


import pandas as pd
import numpy as np
from datetime import date,timedelta
from dateutil.relativedelta import relativedelta
from pyhive import hive
import warnings
warnings.filterwarnings("ignore")
import time
import datetime
import json
from utils import hive_data_load
from utils import sodas_logger
import sys


#### LOAD CONFIG FILE

config='config_alert_generation.json'
with open(config) as f:
    config_file=json.load(f)


#### LOAD  LOG FILE
config = sodas_logger.LogConfig()
log_success = config.create_success_log(param = 'PAF_')
log_failure = config.create_failure_log(param = 'PAF_')


#### Variable/Column names definition
#data variables
percentile_25th=config_file['common']['percentile_25th']
percentile_75th=config_file['common']['percentile_75th']
iqr_percentage=config_file['common']['iqr_percentage']
threshold=config_file['common']['threshold_value']
drilldown_paf=config_file['statistical']['drilldown_paf']
drilldown_tenure=config_file['statistical']['drilldown_tenure']
attribute=config_file['statistical']['attribute']
paf=config_file['statistical']['paf']
title=drilldown_paf
alert_status=config_file['statistical']['alert_status']
subtitle=config_file['statistical']['subtitle']
x_axis_label=config_file['statistical']['x_axis']
y_axis_label=config_file['statistical']['y_axis']
created_by=config_file['statistical']['created_by_paf']
alert_type=config_file['statistical']['alert_type']
paf_prefix=config_file['statistical']['paf_prefix']
alert_source=config_file['statistical']['source_paf']
output_file_prefix=config_file['statistical']['output_file_prefix_paf']
chart_prefix=config_file['statistical']['CHART_METADATA_UK_prefix']
issue_prefix=config_file['statistical']['ISSUE_METADATA_UK_prefix']

#paramterized_variable
run_time_model=sys.argv[1]
run_time_model_vehicle='\''+run_time_model+'\''
run_time_model_issue='\'%'+run_time_model+'%\''

#Hive Queries
hazard_query=config_file['hive_queries']['hazard_master_hive']
vehicle_query=config_file['hive_queries']['vehicle_master_hive'].format(run_time_model_vehicle)
warranty_query=config_file['hive_queries']['issue_hive_paf'].format(run_time_model_issue)

#Data model columns
stat_alert_column=config_file['statistical']['ALERT_columns']
stat_chart_metadata_column=config_file['statistical']['CHART_METADATA_columns']
issue_alert_metadata_column=config_file['statistical']['ISSUE_METADATA_columns']

#Output file names
STATISTICAL_ALERT_file_name=config_file['statistical']['STATISTICAL_ALERT_file_name']
CHART_METADATA_file_name=config_file['statistical']['CHART_METADATA_file_name']
ISSUE_METADATA_file_name=config_file['statistical']['ISSUE_METADATA_file_name']


#### Functions Used

def hive_conn():    
    """Function to connect with Hive - Analytical cluster"""
    try:
        conn = hive.connect(host=config_file['hive_connection']['host'], port=config_file['hive_connection']['port'], username=config_file['hive_connection']['username'], 
                        password=config_file['hive_connection']['password'],auth=config_file['hive_connection']['auth'])
        return conn
    except Exception as e:
        log_failure.error('Exception occurred while hive connection. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def runtime(t):
    return f"{(datetime.datetime.now() - t).total_seconds():0.3f} seconds"

def prod_count(df):
    '''
    Functionality: Get prod count from vehicle master table
    '''
    try:
        df['production_date'] = pd.to_datetime(df['production_date'], errors='coerce')
        df['production_month'] = df['production_date'].dt.month
        df['production_year'] = df['production_date'].dt.year
        df=df.groupby(['model','model_year','production_year','production_month']).aggregate({'production_date':'count'})
        df=df.reset_index()
        df=df.rename(columns={'production_date':'production_count'})
        return(df)
    except Exception as e:
        log_failure.error('Exception occurred while calculating prod_count. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def create_master_data(df1,df2):
    '''
    input: takes in vehicle_master_file_name and hazard_master_file_name
    output: merged df    
    '''
    try:
        df3 = df1.assign(key=1).merge(df2.assign(key=1), on="key").drop("key", axis=1)
        log_success.info('Master data created successfully')
        return df3
    except Exception as e:
        log_failure.error('Exception occurred while creating master data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def pp100(master_data,warranty_data):
    '''
    Functionality: Calculate PP100 on warranty data and master data
    '''
    try:
        warranty_data['production_date'] = pd.to_datetime(warranty_data['production_date'], errors='coerce')
        warranty_data['production_month'] = warranty_data['production_date'].dt.month     
        warranty_data['production_year'] = warranty_data['production_date'].dt.year
        df = pd.merge(master_data, warranty_data, on=['model','model_year','production_month','production_year','hazard_type','hazard_subtype'], how='left')
        df = df[['model','model_year','production_month','production_year','hazard_type','hazard_subtype','production_count','issue_date','make']]
        pp100 = df.groupby(['model', 'model_year','hazard_type','hazard_subtype','production_month','production_year','production_count','make'],as_index=False)['issue_date'].count()
        pp100 = pp100.rename(columns={'issue_date':'claims_count'})
        pp100['claims_count'] = pp100['claims_count'].fillna(0)
        pp100['pp100'] = round((pp100['claims_count']/pp100['production_count'])*100,2)
        log_success.info('PP100 calculated.')
        return (warranty_data,pp100)
    except Exception as e:
        log_failure.error('Exception occurred while calculating pp100. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def get_key_combinations(vehicle_df,hazard_df):
    try:
        df = vehicle_df.groupby(['model', 'model_year']).aggregate({'production_date':'count'}).reset_index()
        df= df.assign(key=1).merge(hazard_df.assign(key=1), on="key").drop("key", axis=1)
        return df
    except Exception as e:
        log_failure.error('Exception occurred while creating key cominations for filter. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def alert_detail_df(df_pp100,df_key):
    '''
    Functionality: create alert_df and detailed_Df if a key combination breaches threshold
    '''
    try:
        alert_df = pd.DataFrame()
        detailed_df=pd.DataFrame()
        for ind in df_key.index:
            prod_df = df_pp100[(df_pp100['model']==df_key['model'][ind]) & 
                          (df_pp100['model_year']==df_key['model_year'][ind]) &
                          (df_pp100['hazard_type']==df_key['hazard_type'][ind]) &
                          (df_pp100['hazard_subtype']==df_key['hazard_subtype'][ind])]
            prod_df['q1']=round((prod_df['pp100'].quantile(percentile_25th)),2)
            prod_df['q3']=round((prod_df['pp100'].quantile(percentile_75th)),2)
            prod_df['iqr']=round(prod_df['q3']-prod_df['q1'],2)
            prod_df['revised_iqr']=round((iqr_percentage*(prod_df['iqr'])),2)
            prod_df['median_val']=round(prod_df['pp100'].median(),2)
            prod_df['upper_control_limit']=round(prod_df['revised_iqr']+prod_df['median_val'],2)
            prod_df['lower_control_limit']=round(prod_df['revised_iqr']-prod_df['median_val'],2)
            prod_df['median_deviation'] = round((prod_df['pp100']-prod_df['median_val']),2)
            if (prod_df['revised_iqr']).all() > 0:
                prod_df['zscore'] = round((prod_df['median_deviation'] / prod_df['revised_iqr']),2)
            else:
                prod_df['zscore'] = 0 
            prod_df['threshold']=threshold
            alert_df1 = prod_df[(prod_df['zscore'] >prod_df['threshold'] )]  
            if alert_df1.shape[0] >= 1:
                alert_df1=alert_df1.sort_values(by='pp100')
                alert_df1=alert_df1.tail(1)
                alert_df = alert_df.append(alert_df1)
                alert_df=alert_df.groupby(['model','model_year','hazard_type','hazard_subtype','make']).first({'production_count','claims_count','pp100','production_month','production_year','threshold','q1','q3','iqr','revised_iqr','median_val','upper_control_limit','lower_control_limit','median_deviation','zscore'})
                alert_df=alert_df.reset_index()
                detailed_df=detailed_df.append(prod_df)
                detailed_df.reset_index(inplace=True)
                detailed_df.drop(['index'],axis=1,inplace=True)
        log_success.info('Alert df and detailed df created successfully')
        return alert_df,detailed_df
    except Exception as e:
        log_failure.error('Exception occurred while creating alert and detailed data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def tenure(Master_data,df):
    '''
    Functionality: Calculate tenure in detailed df
    '''
    try:
        df['issue_date'] = pd.to_datetime(df['issue_date'], errors='coerce')
        df['rdr_date'] = pd.to_datetime(df['rdr_date'], errors='coerce')
        df['tenure_month'] = (df['issue_date'].dt.year - df['rdr_date'].dt.year) * 12 + (df['issue_date'].dt.month - df['rdr_date'].dt.month)
        df['production_date'] = pd.to_datetime(df['production_date'], errors='coerce')
        df['production_month'] = df['production_date'].dt.month     
        df['production_year'] = df['production_date'].dt.year   
        Filtered_df = pd.merge(Master_data, df, on=['model','model_year','hazard_type','hazard_subtype'], how='left')
        Filtered_df = Filtered_df[['model','model_year','hazard_type','hazard_subtype','production_count','issue_date','tenure_month']]
        Tenure_pp100=Filtered_df.groupby(['model', 'model_year','hazard_type','hazard_subtype','tenure_month','production_count']).aggregate({'issue_date':'count'}).reset_index()
        Tenure_pp100 = Tenure_pp100.rename(columns={'issue_date':'claims_count'})
        Tenure_pp100['claims_count'] = Tenure_pp100['claims_count'].fillna(0)
        Tenure_pp100['pp100'] = round((Tenure_pp100['claims_count']/Tenure_pp100['production_count'])*100,2)
        log_success.info('Tenure calculated.')
        return Tenure_pp100
    except Exception as e:
        log_failure.error('Exception occurred while calculating tenure. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))


def alert_df_data_model(alert_df,run_time_model):
    '''
    Functionality: Transform alert df as per required data model output tables
    '''
    try:
        columns_needed=stat_alert_column
        yy=str(date.today().year)[2:]
        mm='{:02d}'.format(date.today().month)
        dd='{:02d}'.format(date.today().day)
        if(list(alert_df.columns) not in columns_needed):
            alert_df['Counter']=np.arange(1,len(alert_df)+1)
            alert_df['statistical_alert_pk']=paf_prefix+run_time_model+'_'+yy+mm+dd+'_'+(alert_df['Counter'].apply(lambda x: '{0:0>4}'.format(x))).astype(str)
            alert_df['statistical_alert_type']=paf
            alert_df['alert_type']=alert_type
            alert_df['processed_date']=pd.to_datetime('today').normalize()
            alert_df['statistical_alert_attr_set']=attribute
            alert_df['alert_status']=alert_status
            alert_df['assigned_to']=''
            alert_df['rec_create_date']=pd.to_datetime('today').normalize()
            alert_df['rec_create_by']=created_by
            alert_df['rec_update_by']=''
            alert_df['rec_update_date']=''
            alert_df['source']=alert_source  
            alert_df['pp100_moving_average']=''
            alert_df['claim_month']=''
            alert_df['claim_year']=''
        alert_df=alert_df[stat_alert_column] 
        return(alert_df)
    except Exception as e:
        log_failure.error('Exception occurred while creating data model for alert data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def metadata_df(Tenure_pp100,df,detailed_df,alert_df,run_time_model):
    '''
    Functionality: Create tenure DF
    '''
    try:
        tenure_df=pd.DataFrame()
        count=0
        df1=pd.DataFrame()
        yy=str(date.today().year)[2:]
        mm='{:02d}'.format(date.today().month)
        dd='{:02d}'.format(date.today().day)
        for ind in df.index:
            ten_prod_df = Tenure_pp100[(Tenure_pp100['model']==df['model'][ind]) & 
                              (Tenure_pp100['model_year']==df['model_year'][ind]) &
                              (Tenure_pp100['hazard_type']==df['hazard_type'][ind]) &
                              (Tenure_pp100['hazard_subtype']==df['hazard_subtype'][ind])]
            ten_Q1=ten_prod_df['pp100'].quantile(0.25)
            ten_Q3=ten_prod_df['pp100'].quantile(0.75) 
            ten_Modified_IQR=0.75*(ten_Q3-ten_Q1)
            ten_median=ten_prod_df['pp100'].median()
            ten_prod_df['upper_control_limit']=round(ten_Modified_IQR+ten_median,2)
            ten_prod_df['lower_control_limit']=round(ten_Modified_IQR-ten_median,2)
            tenure_df=tenure_df.append(ten_prod_df)
        for ind in alert_df.index:
            temp = tenure_df[(tenure_df['model']==alert_df['model'][ind]) & 
                      (tenure_df['model_year']==alert_df['model_year'][ind]) &
                      (tenure_df['hazard_type']==alert_df['hazard_type'][ind]) &
                      (tenure_df['hazard_subtype']==alert_df['hazard_subtype'][ind])]
            count+=1 
            temp['statistical_alert_pk']=count
            temp['alert_chart_metadata_pk']=np.arange(1,len(temp)+1)
            df1=df1.append(temp)  
        tenure_df['alert_chart_metadata_pk']=df1['alert_chart_metadata_pk']
        tenure_df['statistical_alert_pk']=paf_prefix+run_time_model+'_'+yy+mm+dd+'_'+(df1['statistical_alert_pk'].apply(lambda x: '{0:0>4}'.format(x))).astype(str)
        tenure_df=tenure_df.sort_values(by=['statistical_alert_pk','alert_chart_metadata_pk'])
        tenure_df['statistical_alert_drilldown']=drilldown_tenure
        tenure_df['q1']=''
        tenure_df['q3']=''
        tenure_df['iqr']=''
        tenure_df['revised_iqr']=''
        tenure_df['median_val']=''
        tenure_df['median_deviation']=''
        tenure_df['zscore']=''
        tenure_df['threshold']=''
        return tenure_df
    except Exception as e:
        log_failure.error('Exception occurred while creating metadata_df. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def detailed_df_data_model(detailed_df,alert_df,tenure_df,run_time_model):
    '''
    Functionality: Transform detailed df as per required data model output tables
    '''
    try:
        count=0
        temp=pd.DataFrame()
        df1=pd.DataFrame()
        yy=str(date.today().year)[2:]
        mm='{:02d}'.format(date.today().month)
        dd='{:02d}'.format(date.today().day)        
        for ind in alert_df.index:
            temp = detailed_df[(detailed_df['model']==alert_df['model'][ind]) & 
                      (detailed_df['model_year']==alert_df['model_year'][ind]) &
                      (detailed_df['hazard_type']==alert_df['hazard_type'][ind]) &
                      (detailed_df['hazard_subtype']==alert_df['hazard_subtype'][ind])]
            count+=1 
            temp['statistical_alert_pk']=count
            temp['alert_chart_metadata_pk']=np.arange(1,len(temp)+1)
            df1=df1.append(temp)         
        detailed_df['alert_chart_metadata_pk']=df1['alert_chart_metadata_pk']
        detailed_df['statistical_alert_pk']=paf_prefix+run_time_model+'_'+yy+mm+dd+'_'+(df1['statistical_alert_pk'].apply(lambda x: '{0:0>4}'.format(x))).astype(str)
        detailed_df['tenure_month']=0
        detailed_df['statistical_alert_drilldown']=drilldown_paf
        detailed_df['median_deviation']=detailed_df['median_deviation'].astype(str)
        detailed_df['median_val']=detailed_df['median_val'].astype(str)
        detailed_df['zscore']=detailed_df['zscore'].astype(str)
        detailed_df['q1']=detailed_df['q1'].astype(str)
        detailed_df['q3']=detailed_df['q3'].astype(str)
        detailed_df['iqr']=detailed_df['iqr'].astype(str)
        detailed_df['revised_iqr']=detailed_df['revised_iqr'].astype(str)
        detailed_df['threshold']=detailed_df['threshold'].astype(str)
        detailed_df=detailed_df.sort_values(by=['statistical_alert_pk','alert_chart_metadata_pk'])
        data=pd.concat([detailed_df,tenure_df])
        data['statistical_alert_attr_set']=attribute
        data['title']=title
        data['subtitle']=subtitle
        data['x_axis_label']=x_axis_label
        data['y_axis_label']=y_axis_label
        data['rec_create_date']=pd.to_datetime('today').normalize()
        data['rec_create_by']=created_by
        data['rec_update_by']=''
        data['rec_update_date']=''   
        data['pp100_moving_average']=''
        data['claim_month']=''
        data['claim_month_indicator']=''
        data['claim_year']=''
        data=data[stat_chart_metadata_column]
        return(data)
    except Exception as e:
        log_failure.error('Exception occurred while creating data model for chart_meta_data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def issue_df_data_model(warranty_df,alert_df,run_time_model):
    '''
    Functionality: Create and transform issue df as per required data model output tables
    '''
    try:
        count=0
        issue_df=pd.DataFrame()
        yy=str(date.today().year)[2:]
        mm='{:02d}'.format(date.today().month)
        dd='{:02d}'.format(date.today().day) 
        warranty_df['issue_date'] = pd.to_datetime(warranty_df['issue_date'], errors='coerce')
        warranty_df['rdr_date'] = pd.to_datetime(warranty_df['rdr_date'], errors='coerce')
        warranty_df['tenure_month'] = (warranty_df['issue_date'].dt.year - warranty_df['rdr_date'].dt.year) * 12 + (warranty_df['issue_date'].dt.month - warranty_df['rdr_date'].dt.month)
        for ind in alert_df.index:
            warr_df = warranty_df[(warranty_df['model']==alert_df['model'][ind]) & 
                          (warranty_df['model_year']==alert_df['model_year'][ind]) &
                          (warranty_df['hazard_type']==alert_df['hazard_type'][ind]) &
                          (warranty_df['hazard_subtype']==alert_df['hazard_subtype'][ind])]
            count+=1
            warr_df['statistical_alert_pk']=count
            warr_df['alert_issue_metadata_pk']=np.arange(1,len(warr_df)+1)
            issue_df=issue_df.append(warr_df)    
        issue_df['statistical_alert_pk']=paf_prefix+run_time_model+'_'+yy+mm+dd+'_'+(issue_df['statistical_alert_pk'].apply(lambda x: '{0:0>4}'.format(x))).astype(str)
        issue_df['statistical_alert_attr_set']=attribute
        issue_df['complaint_type']=''
        issue_df['alert_type']=alert_type
        issue_df['rec_create_date']=pd.to_datetime('today').normalize()
        issue_df['rec_create_by']=created_by
        issue_df['rec_update_by']=''
        issue_df['rec_update_date']='' 
        issue_df.reset_index(inplace=True)
        issue_df.drop(['index'],axis=1,inplace=True)
        issue_df=issue_df[issue_alert_metadata_column]
        issue_df.columns=issue_df.columns.str.lower()
        log_success.info('Issue df created successfully')
        return issue_df
    except Exception as e:
        log_failure.error('Exception occurred while creating data model for issue_data. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def write_files(alert_df,detailed_df,issue_df,run_time_model):
    try:
        hive_data_load.load_data(alert_df, STATISTICAL_ALERT_file_name, log_success)
        log_success.info('{} file written successfully.'.format(STATISTICAL_ALERT_file_name))
        hive_data_load.load_data(detailed_df, CHART_METADATA_file_name, log_success)
        log_success.info('{} file written successfully.'.format(CHART_METADATA_file_name))
        hive_data_load.load_data(detailed_df, ISSUE_METADATA_file_name, log_success)
        log_success.info('{} file written successfully.'.format(ISSUE_METADATA_file_name))
    except Exception as e:
        log_failure.error('Exception occurred while writing files. Error : {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

def create_empty_dataframes(stat_alert_column,stat_chart_metadata_column,issue_alert_metadata_column):
    '''
    Functionality: Create empty dataframe if no alerts are there
    '''
    try:
        alert_df=pd.DataFrame(columns=stat_alert_column)
        detailed_df=pd.DataFrame(columns=stat_chart_metadata_column)
        issue_df=pd.DataFrame(columns=issue_alert_metadata_column)
        return(alert_df,detailed_df,issue_df)
    except Exception as e:
        log_failure.error('Exception occurred while writing empty files. Error: {}'.format(str(e)))
        log_failure.exception("message")
        log_failure.error('Error Type : {}'.format(type(e)))

#### Main Script

def main():
    time = datetime.datetime.now()
    conn = hive_conn()
    log_success.info('Script running for {} realted models.'.format(run_time_model))
    log_success.info('Reading input data')
    #Read Files
    vehicle_data = pd.read_sql(vehicle_query,conn)
    log_success.info('Shape of vehicle data : {} '.format(vehicle_data.shape))
    hazard_master_data = pd.read_sql(hazard_query,conn)
    log_success.info('Shape of hazard_master data : {} '.format(hazard_master_data.shape))
    warranty_data = pd.read_sql(warranty_query,conn)
    log_success.info('Shape of warranty data : {} '.format(warranty_data.shape))
    log_success.info('All input files are read successfully')
    time1=round(float(runtime(time).replace(' seconds','')),2)
    log_success.info("Time taken in reading input data-> {} seconds".format(str(time1)))
    time = datetime.datetime.now()
    if (warranty_data.shape[0]>0) & (vehicle_data.shape[0]>0) & (hazard_master_data.shape[0]>0):
        vehicle_master_data=prod_count(vehicle_data)
        master_data = create_master_data(vehicle_master_data,hazard_master_data)
        master_data.to_csv("Master.csv",index=False)
        warranty_data,df_pp100 = pp100(master_data,warranty_data)
        df_key_comb = get_key_combinations(vehicle_data,hazard_master_data)
        #Create alert and detailed df
        df_alert,df_detailed = alert_detail_df(df_pp100,df_key_comb)
        if df_alert.shape[0]>0:
            #calculate tenure
            df_tenure=tenure(df_key_comb,warranty_data)
            df_metadata=metadata_df(df_tenure,df_key_comb,df_detailed,df_alert,run_time_model)
            data_model_alert_df=alert_df_data_model(df_alert,run_time_model)
            data_model_detailed_df=detailed_df_data_model(df_detailed,df_alert,df_metadata,run_time_model)
            data_model_issue_df = issue_df_data_model(warranty_data,df_alert,run_time_model)
            log_success.info('Shape of Alert Data : {} '.format(data_model_alert_df.shape))
            log_success.info('Shape of Chart Meta Data : {} '.format(data_model_detailed_df.shape))
            log_success.info('Shape of Issue Meta Data : {} '.format(data_model_issue_df.shape))
        else:
            log_success.info('No alerts generated. All Output Files are empty.') 
            data_model_alert_df,data_model_detailed_df,data_model_issue_df=create_empty_dataframes(stat_alert_column,
                                            stat_chart_metadata_column,issue_alert_metadata_column)
    else:
        log_success.info('Empty data input file . All Output Files are empty.') 
        data_model_alert_df,data_model_detailed_df,data_model_issue_df=create_empty_dataframes(stat_alert_column,
                                            stat_chart_metadata_column,issue_alert_metadata_column)
    #Write Output Files
    write_files(data_model_alert_df,data_model_detailed_df,data_model_issue_df,run_time_model)
    time2=round(float(runtime(time).replace(' seconds','')),2)
    log_success.info("Time taken in writing all output files-> {} seconds".format(str(time2)))
    total_time=round((time1+time2),2)
    log_success.info("Total time taken while executing script-> {} seconds".format(str(total_time)))

if __name__ ==  "__main__":
    log_success.info('Starting the script for PAF - {}'.format(datetime.datetime.now().isoformat()))
    paf_execution= main()

