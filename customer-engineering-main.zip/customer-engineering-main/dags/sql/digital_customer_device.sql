MERGE INTO `{{params.project_id}}.raw.customer_device` TARGET
USING `{{params.project_id}}.raw.temp_customer_device` SOURCE
ON TARGET.device_id = SOURCE.device_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.channel_id=SOURCE.channel_id,
TARGET.create_tms=SOURCE.create_tms,
TARGET.device_id=SOURCE.device_id,
TARGET.device_nam=SOURCE.device_nam,
TARGET.kount_session_id=SOURCE.kount_session_id,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.manufacturer_txt=SOURCE.manufacturer_txt,
TARGET.model_txt=SOURCE.model_txt,
TARGET.offer_push_sent_tms=SOURCE.offer_push_sent_tms,
TARGET.os_typ=SOURCE.os_typ,
TARGET.os_version=SOURCE.os_version,
TARGET.phone_flg=SOURCE.phone_flg,
TARGET.print_id=SOURCE.print_id,
TARGET.screen_height_num=SOURCE.screen_height_num,
TARGET.screen_width_num=SOURCE.screen_width_num,
TARGET.source_cod=SOURCE.source_cod,
TARGET.tm_session_id=SOURCE.tm_session_id,
TARGET.user_agent_txt=SOURCE.user_agent_txt,
TARGET.version_id=SOURCE.version_id,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;