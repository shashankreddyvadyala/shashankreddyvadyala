INSERT INTO `{{params.project_id}}.raw.levelup_credit_transactions`
SELECT * FROM `{{params.project_id}}.raw.temp_levelup_credit_transactions`;