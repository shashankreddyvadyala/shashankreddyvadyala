DECLARE filter_lookback INT64;
DECLARE default_lookback INT64;
DECLARE daypart_lookback INT64;
DECLARE freq_march_toggle BOOLEAN;
DECLARE freq_bin_med_threshold NUMERIC;
DECLARE freq_bin_high_threshold NUMERIC;

DECLARE freq_march_int INT64;
DECLARE curr_month INT64;
DECLARE curr_year INT64;

-- Set user-defined variables. Note: Changing the default_lookback period will cause the lookback period to come out of alignment with the column names (e.g. FREQ_12MO).
SET filter_lookback = 12; -- Set the number of months for the query to be capped at looking back in the where clause. No calculations will be able to lookback more than what is specified in this variable.
SET default_lookback = 12; -- Set the number of months for the default lookback period.
SET daypart_lookback = 12; -- Set the number of months for the daypart freq and avg check attributes lookback period.
SET freq_march_toggle = false;  -- FALSE: During the month of March, the FREQ_MARCH calculation is for the current year and shows frequency to date.
                                -- TRUE:  During the month of March, the FREQ_MARCH calculation is for the prior year. The current year will not be reflected until April 1st.
SET freq_bin_med_threshold = 7.5; -- Customers with frequency greater than freq_bin_med_threshold during the default_lookback period will be part of the Medium frequency bin. Lower customer frequencies will be assigned to the Low bin.
SET freq_bin_high_threshold = 15.0; -- Customers with frequency greater than freq_bin_high_threshold during the default_lookback period will be part of the High frequency bin.

-- Program dervied variables.
SET freq_march_int = CAST(freq_march_toggle AS INTEGER);
SET curr_month = extract(month from current_date);
SET curr_year = extract(year from current_date);

TRUNCATE TABLE `{{params.project_id}}.curated.t_fact_order_domain`;

INSERT INTO `{{params.project_id}}.curated.t_fact_order_domain`
WITH `{{params.project_id}}.curated.temp_fe_12_mnth_summ1` AS
(
         SELECT   b.customer_id,
                  countif(b.business_date >= date_sub(current_date, interval default_lookback month)) AS freq_12mo,
                  round(avg(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.net_sales_amt, null)), 2) AS avg_check_12mo,
                  round(sum(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.discount_amt,  null)), 2) AS discount_amount_12mo,
                  max(b.business_date) AS last_visit_tms, -- this will lookback as far as the "filter_lookback" variable allows
                  date_diff(current_date, max(business_date), day) AS days_since_last_visit, -- this will lookback as far as the "filter_lookback" variable allows
                  countif(b.daypart_name = 'BREAKFAST' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_bkfst,
                  countif(b.daypart_name = 'LUNCH' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_lunch,
                  countif(b.daypart_name = 'AFTERNOON SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_aftn,
                  countif(b.daypart_name = 'DINNER' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_dinner,
                  countif(b.daypart_name = 'PM SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_pm_snk,
                  countif(b.daypart_name = 'LATE NIGHT' AND b.business_date >= date_sub(current_date, interval daypart_lookback month)) AS freq_late_nt,
                  round(avg(if(b.daypart_name = 'BREAKFAST' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_bkfst,
                  round(avg(if(b.daypart_name = 'LUNCH' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_lunch,
                  round(avg(if(b.daypart_name = 'AFTERNOON SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_aftn,
                  round(avg(if(b.daypart_name = 'DINNER' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_dinner,
                  round(avg(if(b.daypart_name = 'PM SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_pm_snk,
                  round(avg(if(b.daypart_name = 'LATE NIGHT' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS avg_check_late_nt,
                  case
                      when countif(b.business_date >= date_sub(current_date, interval default_lookback month)) = 0                                                          THEN  null
                      when countif(b.business_date >= date_sub(current_date, interval default_lookback month)) between 0   and freq_bin_med_threshold                       THEN  'Low'
                      when countif(b.business_date >= date_sub(current_date, interval default_lookback month)) between freq_bin_med_threshold and freq_bin_high_threshold   THEN  'Medium'
                      when countif(b.business_date >= date_sub(current_date, interval default_lookback month)) > freq_bin_high_threshold                                    THEN  'High'
                  end AS freq_category_bin,
                  case
                      when ntile(4) over (order by countif(b.business_date >= date_sub(current_date, interval default_lookback month))) = 1 THEN  '<25'               
                      when ntile(4) over (order by countif(b.business_date >= date_sub(current_date, interval default_lookback month))) = 2 THEN  '25-50'             
                      when ntile(4) over (order by countif(b.business_date >= date_sub(current_date, interval default_lookback month))) = 3 THEN  '50-75'                                             
                      when ntile(4) over (order by countif(b.business_date >= date_sub(current_date, interval default_lookback month))) = 4 THEN  '75+'
                  end AS freq_percent_bin,
                  if(countif(b.business_date >= date_sub(current_date, interval default_lookback month)) > 1, 1, 0) AS repeat_cust_flag,
                  round( -- Formula: Discount Amount / (Discount Amount + Net Sales Amount)
                      safe_divide(
                          sum(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.discount_amt, null)),
                          sum(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.discount_amt + b.net_sales_amt,  null))
                      )
                  , 2) AS pct_discounted,
                  if(extract(month from current_date) <= (2 + freq_march_int), -- Will calculate for either this year or last year as described and setup in the user-variable section under freq_march_toggle
                      countif(extract(month from b.business_date) = 3 AND extract(year from b.business_date) = curr_year-1),
                      countif(extract(month from b.business_date) = 3 AND extract(year from b.business_date) = curr_year)
                  ) AS freq_march,
                  countif(b.business_date >= date_sub(current_date, interval 1 month)) AS freq_1mo,
                  round(avg(if(b.business_date >= date_sub(current_date, interval 1 month), b.net_sales_amt, null)), 2) AS avg_check_1mo,
                  countif(b.business_date >= date_sub(current_date, interval 3 month)) AS freq_3mo,
                  round(avg(if(b.business_date >= date_sub(current_date, interval 3 month), b.net_sales_amt, null)), 2) AS avg_check_3mo,
                  countif(b.business_date >= date_sub(current_date, interval 6 month)) AS freq_6mo,
                  round(avg(if(b.business_date >= date_sub(current_date, interval 6 month), b.net_sales_amt, null)), 2) AS avg_check_6mo,
                  round( -- Formula: Digital Net Sales Amount / Total Net Sales Amount
                      safe_divide(
                          sum(if(b.spend_category = 'Digitalspend' AND b.business_date >= date_sub(current_date, interval default_lookback month), b.net_sales_amt, 0)),
                          sum(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.net_sales_amt, null))
                      )
                  , 2) AS pct_digital_spend,
                  array_agg(distinct site_addr ignore nulls) AS visited_site_addrs,
                  array_agg(distinct site_num ignore nulls) AS visited_site_nums
                --   round(sum(if(b.business_date >= date_sub(current_date, interval 1 month), b.net_sales_amt, null)), 2) AS total_check_1mo,
                --   round(sum(if(b.business_date >= date_sub(current_date, interval 3 month), b.net_sales_amt, null)), 2) AS total_check_3mo,
                --   round(sum(if(b.business_date >= date_sub(current_date, interval 6 month), b.net_sales_amt, null)), 2) AS total_check_6mo,
                --   round(sum(if(b.business_date >= date_sub(current_date, interval default_lookback month), b.net_sales_amt, null)), 2) AS total_check_12mo,
                --   round(sum(if(b.daypart_name = 'BREAKFAST' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_bkfst,
                --   round(sum(if(b.daypart_name = 'LUNCH' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_lunch,
                --   round(sum(if(b.daypart_name = 'AFTERNOON SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_aftn,
                --   round(sum(if(b.daypart_name = 'DINNER' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_dinner,
                --   round(sum(if(b.daypart_name = 'PM SNACK' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_pm_snk,
                --   round(sum(if(b.daypart_name = 'LATE NIGHT' AND b.business_date >= date_sub(current_date, interval daypart_lookback month), b.net_sales_amt, null)), 2) AS tot_check_late_nt,
         FROM     `{{params.project_id}}.curated.t_fact_customer_order_trans` AS b 
         WHERE    b.business_date >= date_sub(current_date, interval filter_lookback month)
	       AND	  UPPER(b.transaction_type_desc) <> 'REFUND' 
         GROUP BY b.customer_id
)
		 
--creating final table cdp_order_domain on curated layer
SELECT 
b.CUSTOMER_ID,
b.REPEAT_CUST_FLAG,
b.FREQ_12MO,
b.FREQ_CATEGORY_BIN,
b.FREQ_PERCENT_BIN,
b.AVG_CHECK_12MO,
b.LAST_VISIT_TMS DATE,
b.DAYS_SINCE_LAST_VISIT,
b.AVG_CHECK_BKFST,
b.AVG_CHECK_LUNCH,
b.AVG_CHECK_AFTN,
b.AVG_CHECK_DINNER ,
b.AVG_CHECK_PM_SNK,
b.AVG_CHECK_LATE_NT,
b.FREQ_BKFST,
b.FREQ_LUNCH,
b.FREQ_AFTN,
b.FREQ_DINNER,
b.FREQ_PM_SNK,
b.FREQ_LATE_NT,
b.PCT_DISCOUNTED,
b.FREQ_1MO,
b.AVG_CHECK_1MO,
b.FREQ_3MO,
b.AVG_CHECK_3MO,
b.FREQ_6MO,
b.AVG_CHECK_6MO,
b.FREQ_MARCH,
b.PCT_DIGITAL_SPEND,
b.VISITED_SITE_ADDRS,
b.VISITED_SITE_NUMS,
cltv_predictions.CLTV_12MO,
cltv_predictions.ALIVE_PROB,
cltv_predictions.FUTURE_12MO_PURCHASE,
kmeans_predictions.CLTV_SEGMENT,
CURRENT_TIMESTAMP() AS LAST_UPDT_TMS
 FROM   `{{params.project_id}}.curated.temp_fe_12_mnth_summ1` AS b
  LEFT JOIN
`{{params.project_id}}.curated.t_mdl_cltv_predictions` AS cltv_predictions
ON
b.CUSTOMER_ID=cltv_predictions.CUSTOMER_ID
LEFT JOIN
`{{params.project_id}}.curated.t_mdl_kmeans_predictions` AS kmeans_predictions
ON 
b.CUSTOMER_ID=kmeans_predictions.CUSTOMER_ID
