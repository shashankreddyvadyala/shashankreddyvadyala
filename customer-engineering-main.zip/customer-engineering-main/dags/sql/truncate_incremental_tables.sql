TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_address`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_deletion_request`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_device`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_giveaway`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_meal`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_meal_component`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_meal_product`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_payment_method`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_customer_social`;

TRUNCATE TABLE `{{params.project_id}}.raw.temp_order`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_order_component`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_order_product`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_order_tender`;

TRUNCATE TABLE `{{params.project_id}}.raw.temp_dpvhstcheckinfo`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_accomplishments`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_campaigns`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_credit_transactions`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_item_based_goal`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_items`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_locations`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_orders`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_progress_adjustments`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_progress_contributions`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_progress_redemptions`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_progress_rewards_purchases`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_purchasable_progress_rewards`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_refunds`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_spend_based_goal`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_user`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_user_campaign_progress_totals`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_levelup_visit_based_goals`;

TRUNCATE TABLE `{{params.project_id}}.raw.LUIS_completed_order`;
TRUNCATE TABLE `{{params.project_id}}.raw.LUIS_customer`;
TRUNCATE TABLE `{{params.project_id}}.raw.LUIS_location`;


TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_Click`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_Jobs`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_Journey`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_JourneyActivity`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_MobilePushTrackingDetails`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_Open`;
TRUNCATE TABLE `{{params.project_id}}.raw.temp_SFMC_Sent`;