DECLARE fromdate DATE;

-- STEP 1: SET VARIABLES
SET fromdate     = (SELECT -- set fromdate to the last batch date as recorded in the t_dim_aci_token table
                        IFNULL(
                                DATE_SUB(MAX(BUSINESS_DATE), INTERVAL 2 DAY), 
                                '2020-04-01' -- LevelUp loyalty program started in March 2020, so this will bring the history back to the start of the Level Up loyalty program.
                        )
                    FROM `{{params.project_id}}.curated.t_fact_customer_order_trans`
);


-- STEP 2: MERGE DATA INTO t_fact_customer_order_trans
MERGE INTO `{{params.project_id}}.curated.t_fact_customer_order_trans` per 
USING(
    SELECT trans.*
    FROM `{{params.project_id}}.raw.customer` cust
    INNER JOIN (
        SELECT 
        IFNULL(ord.customer_id, IFNULL(CAST(Luisc.WENDYS_CUSTOMER_ID AS INTEGER), aci_map.customer_id)) as customer_id,
        IF(ord.customer_id is not null, 'digital', IF(Luisc.WENDYS_CUSTOMER_ID is not null, 'rewards', IF(aci_map.customer_id is not null, 'credit_card', null))) as customer_id_src,
        IF(ord.customer_id is not null, 'Digitalspend', IF(Luisc.WENDYS_CUSTOMER_ID is not null, 'NonDigitalSpend', IF(aci_map.customer_id is not null, 'NonDigitalSpend', null))) as spend_category,
        dim_site.site_addr,
        aci.Token as card_token,
        concat(a.business_date,"_",a.site_num,"_",a.receipt_id) AS unq_order,
        -- all original tdm columns
        a.sales_transaction_id,
        a.site_num,
        a.business_date,
        a.transaction_number,
        a.receipt_id,
        a.maint_user_id,
        a.maint_tms,
        a.source_system_name,
        a.dim_site_key,
        null as dim_insight_source_key, --3-Jun: this column is causing duplication on the curated.t_fact_sales_transactions table, so it was removed from selection from the table
        a.dim_customer_key,
        a.dim_location_key,
        a.location_name,
        a.transaction_reason,
        a.transaction_type_desc,
        a.transaction_close_time_num,
        a.txn_close_time_utc,
        a.txn_updateDateTime_utc as TXN_UPDATEDATETIME_UTC,
        a.txn_close_time_local,
        a.dim_daypart_key,
        a.daypart_name,
        a.employee_num,
        a.currency_code,
        a.tender_amt,
        a.tender_cnt,
        a.total_tax_amt,
        a.gross_sales_amt,
        a.net_sales_amt,
        a.transaction_cnt,
        a.discount_amt,
        a.discount_cnt,
        a.kids_meal_amt,
        a.kids_meal_cnt,
        a.kids_meal_toy_amt,
        a.kids_meal_toy_cnt,
        a.gift_card_sales_amt,
        a.gift_card_sales_cnt,
        a.gift_cert_sales_amt,
        a.gift_cert_sales_cnt,
        a.local_promo_amt,
        a.local_promo_cnt,
        a.national_promo_amt,
        a.national_promo_cnt,
        a.manager_void_amt,
        a.manager_void_cnt,
        a.surcharge_amt,
        a.register_num,
        a.register_operator_void_cnt,
        a.end_of_day_complete_flag,
        ord.customer_order_id as dgtl_customer_order_id,
        cast(ord.order_id  as int64) as dgtl_order_id,
        cast(ord.pos_order_num as int64) as dgtl_pos_order_num,
        ord.ato_order_id as dgtl_ato_order_id,
        ord.order_status_cod as dgtl_order_status_cod,
        cast(ord.create_tms as timestamp) as dgtl_create_tms,
        ord.sub_total_amt as dgtl_subtotal_amt,
        ord.tax_amt as dgtl_tax_amt,
        ord.total_amt as dgtl_total_amt,
        ord.latitude_num as dgtl_latitude_num,
        ord.longitude_num as dgtl_longitude_num,
        IFNULL(lvl1.street_address, lvl2.street_address) as lu_street_address,
        IFNULL(lvl1.channel, lvl2.channel) as lu_channel,
        IFNULL(lvl1.order_id, lvl2.order_id) as lu_order_id,
        IFNULL(lvl1.created_at, lvl2.created_at) as lu_created_at,
        IFNULL(lvl1.loyalty_id, lvl2.loyalty_id) as lu_loyalty_id,		
        ROUND(IFNULL(lvl1.food_and_beverage, lvl2.food_and_beverage)/100, 2) as lu_subtotal_amt,
        ROUND(IFNULL(lvl1.tax_amount, lvl2.tax_amount)/100, 2) as lu_tax_amt,
        ROUND(IFNULL(lvl1.food_and_beverage, lvl2.food_and_beverage)/100 + IFNULL(lvl1.tax_amount, lvl2.tax_amount)/100, 2) as lu_total_amt,
        IFNULL(lvl1.order_source, lvl2.order_source) as lu_order_source,
        IFNULL(cast(lvl1.reward_credit_redeemed as int64), cast(lvl2.reward_credit_redeemed as int64)) as lu_reward_credit_redeemed
        FROM (        SELECT DISTINCT * EXCEPT (dim_insight_source_key) --3-Jun: handles duplication of transactions in the curated dataset
                      FROM `{{params.gcp_wen_id}}.curated.t_fact_sales_transactions`) as a
        INNER JOIN ( SELECT site_num, 
                      any_value(
                                concat(
                                    concat(site_adr1, if(site_adr2 is not null, concat(" ", site_adr2, ", "), ", ")),
                                    concat(city_name, ", "),
                                    concat(state_prov_code, " "),
                                    ifnull(concat(lpad(cast(zip_code as string), 5, "0"), ", "),", "),
                                    country_code
                                )
                              ) as site_addr,
                    any_value(timezone_id) as timezone_id
                    FROM `{{params.gcp_wen_id}}.curated.t_dim_site`
                    WHERE effective_end_tms > TIMESTAMP(CURRENT_DATE)
                    GROUP BY site_num) as dim_site
          ON a.site_num = dim_site.site_num
        LEFT JOIN ( SELECT DISTINCT 
                    atttext as dgtl_order_id,
                    fkstoreid as site_num,
                    dateofbusiness as business_date,
                    checkid as receipt_id,
                    attname
                    FROM `{{params.project_id}}.raw.dpvhstcheckinfo`
                    WHERE attname = 'ORDER_REFERENCE_ID') as checkinfo 
          ON  a.receipt_id = checkinfo.receipt_id
          AND a.business_date = checkinfo.business_date
          AND a.site_num = checkinfo.site_num
        LEFT JOIN ( SELECT max(customer_order_id) OVER (PARTITION BY cast(order_id as int64), order_status_cod) as parent_id, 
                    *
                    FROM `{{params.project_id}}.raw.order`
                    WHERE order_status_cod = 'PREPARED') as ord
          ON  checkinfo.dgtl_order_id = cast(ord.order_id as string)
          AND ord.customer_order_id = ord.parent_id
        LEFT JOIN `{{params.project_id}}.raw.LUIS_location` as LuisL 
          ON a.site_num = LuisL.WENDYS_SITE_NUM 
        LEFT JOIN ( SELECT --3-Jun: handles duplication of levelup order data
                    max(created_at) OVER  (PARTITION BY business_order_id) as max_created_at,
                    *
                    FROM `{{params.project_id}}.raw.levelup_orders`
                    WHERE state = 'completed'
                    AND order_source = 'online'
        ) as lvl1
          ON  CAST(ord.order_id AS STRING) = lvl1.business_order_id
          AND lvl1.max_created_at = lvl1.created_at
        LEFT JOIN ( SELECT --3-Jun: handles duplication of levelup order data
                    max(lvl.created_at) OVER  (PARTITION BY lvl.business_order_id,
                                                            lvl.location_id, 
                                                            DATE(DATETIME_SUB(SAFE.DATETIME(timestamp(lvl.created_at) , dim_site.timezone_id) , INTERVAL 4 HOUR))
                                              ) as max_created_at,
                    DATE(DATETIME_SUB(SAFE.DATETIME(timestamp(lvl.created_at) , dim_site.timezone_id) , INTERVAL 4 HOUR)) as business_date,
                    *
                    FROM `{{params.project_id}}.raw.levelup_orders` as lvl
                    INNER JOIN `{{params.project_id}}.raw.LUIS_location` as LuisL 
                      ON lvl.location_id = LuisL.LEVELUP_LOCATION_ID
                    INNER JOIN (
                                SELECT site_num, 
                                any_value(timezone_id) as timezone_id
                                FROM `{{params.gcp_wen_id}}.curated.t_dim_site`
                                WHERE effective_end_tms > TIMESTAMP(CURRENT_DATE)
                                GROUP BY site_num
                    ) as dim_site
                      ON LuisL.WENDYS_SITE_NUM = dim_site.site_num
                    WHERE lvl.state = 'completed'
                    AND lvl.order_source = 'in_store'
                    AND SAFE.DATETIME(timestamp(lvl.created_at) , dim_site.timezone_id) is not null
        ) as lvl2
          ON  CAST(a.receipt_id AS STRING) = lvl2.business_order_id
          AND LuisL.LEVELUP_LOCATION_ID = lvl2.location_id 
          AND a.business_date = lvl2.business_date
          AND lvl2.max_created_at = lvl2.created_at
        LEFT JOIN `{{params.project_id}}.raw.LUIS_customer` as Luisc 
          ON  lvl2.loyalty_id = Luisc.LEVELUP_CUSTOMER_ID
        LEFT JOIN `{{params.project_id}}.raw.aci` as aci
          ON aci.Amount = a.gross_sales_amt
          AND aci.Store_Location_ID = a.site_num
          AND DATETIME(aci.Store_Timestamp) BETWEEN DATETIME_SUB(a.txn_close_time_local, INTERVAL 120 SECOND) AND DATETIME_ADD(a.txn_close_time_local, INTERVAL 60 SECOND)
          AND DATE(DATETIME_SUB(aci.Store_Timestamp, INTERVAL 4 HOUR)) = a.business_date
          AND aci.Journal_Message = 'Approved'
        LEFT JOIN (	SELECT max(last_used) OVER (PARTITION BY token) as latest_last_used,
                    *
                    FROM `{{params.project_id}}.curated.t_dim_aci_token`) as aci_map 
          ON aci.Token = aci_map.token
          AND aci_map.last_used = aci_map.latest_last_used 
        WHERE a.business_date > fromdate
        AND IFNULL(ord.customer_id, IFNULL(CAST(Luisc.WENDYS_CUSTOMER_ID AS INTEGER), aci_map.customer_id)) is not null
    ) as trans
    ON cust.customer_id = trans.customer_id
    WHERE cust.status_ind in ('A', 'P')
    AND cust.create_source_cod <> 'QA_AUTO'
    AND UPPER(cust.email_adr) not like 'GUEST@GUEST_%'
) as tmp
ON  per.unq_order=tmp.unq_order
AND per.business_date=tmp.business_date
WHEN NOT MATCHED THEN
  INSERT ROW;