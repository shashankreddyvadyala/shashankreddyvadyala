MERGE INTO `{{params.project_id}}.raw.levelup_purchasable_progress_rewards` TARGET
USING `{{params.project_id}}.raw.temp_levelup_purchasable_progress_rewards` SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.active=SOURCE.active,
TARGET.description=SOURCE.description,
TARGET.details=SOURCE.details,
TARGET.name=SOURCE.name,
TARGET.purchasable_until=SOURCE.purchasable_until,
TARGET.required_progress_amount=SOURCE.required_progress_amount,
TARGET.source_campaign_id=SOURCE.source_campaign_id,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,  
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;