MERGE INTO `{{params.project_id}}.raw.levelup_progress_redemptions` TARGET
USING `{{params.project_id}}.raw.temp_levelup_progress_redemptions` SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.created_at=SOURCE.created_at,
TARGET.id=SOURCE.id,
TARGET.progress_amount=SOURCE.progress_amount,
TARGET.progress_reward_purchases_id=SOURCE.progress_reward_purchases_id,
TARGET.progress_source_id=SOURCE.progress_source_id,
TARGET.progress_source_type=SOURCE.progress_source_type,
TARGET.purchasable_progress_reward_id=SOURCE.purchasable_progress_reward_id,
TARGET.updated_at=SOURCE.updated_at,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;