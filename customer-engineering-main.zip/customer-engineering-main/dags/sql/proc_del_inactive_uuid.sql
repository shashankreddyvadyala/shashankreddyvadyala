-- Remove customer UUIDs when the customer has requested deletion of their loyalty account.
-- This is represented by status_ind = 'I' in the Digital Customer table. 
DELETE FROM `{{params.project_id}}.curated.t_dim_uuid`
WHERE customer_id IN (
  SELECT customer_id
  FROM `{{params.project_id}}.raw.customer`
  WHERE status_ind = 'I'
);