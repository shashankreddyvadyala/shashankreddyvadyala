MERGE INTO `{{params.project_id}}.raw.customer_social` TARGET
USING `{{params.project_id}}.raw.temp_customer_social` SOURCE
ON (TARGET.social_id=SOURCE.social_id AND TARGET.social_typ=SOURCE.social_typ AND TARGET.customer_id=SOURCE.customer_id

)
WHEN MATCHED THEN
UPDATE SET
TARGET.customer_id=SOURCE.customer_id,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.social_id=SOURCE.social_id,
TARGET.social_typ=SOURCE.social_typ,
TARGET.source_cod=SOURCE.source_cod,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;