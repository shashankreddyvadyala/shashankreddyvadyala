MERGE INTO `{{params.project_id}}.raw.levelup_locations` TARGET
USING `{{params.project_id}}.raw.temp_levelup_locations` SOURCE
ON TARGET.location_id = SOURCE.location_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.location_id=SOURCE.location_id,
TARGET.reference_name=SOURCE.reference_name,
TARGET.latitude=SOURCE.latitude,
TARGET.longitude=SOURCE.longitude,
TARGET.street_address=SOURCE.street_address,
TARGET.extended_address=SOURCE.extended_address,
TARGET.locality=SOURCE.locality,
TARGET.region=SOURCE.region,
TARGET.postal_code=SOURCE.postal_code,
TARGET.terminated=SOURCE.terminated,
TARGET.time_zone=SOURCE.time_zone,
TARGET.visible=SOURCE.visible,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;