INSERT INTO
  `{{params.project_id}}.curated.t_dim_uuid`
SELECT
  GENERATE_UUID() AS UUID,
  i.*
FROM (
  SELECT
    DISTINCT a.DGTL_CUST_ID AS CUSTOMER_ID,
    a.FIRST_NAME,
    a.LAST_NAME,
    a.PHONE,
    a.EMAIL,
    a.SF_VENDOR_ID AS VENDOR_ID,
    a.SF_CONTACT_ID,
    CURRENT_TIMESTAMP() AS CREATED_TMS
  FROM
    `{{params.project_id}}.curated.t_dim_customer_domain` AS a) AS i
WHERE
  NOT EXISTS (
  SELECT
    1
  FROM
    `{{params.project_id}}.curated.t_dim_uuid` AS t
  WHERE
    t.customer_id=i.CUSTOMER_ID );