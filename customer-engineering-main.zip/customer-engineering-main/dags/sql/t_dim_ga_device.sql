-- DECLARE VARIABLES
DECLARE fromdate_str STRING;
DECLARE todate_str STRING;
DECLARE todate_dt DATE;

-- STEP 1: SET VARIABLES
SET fromdate_str = (SELECT -- set fromdate to one day after the last batch date as recorded in the t_dim_ga_device table
                    FORMAT_DATE(
                                '%Y%m%d',
                                ifnull(
                                        max(record_date)+1,
                                        '1970-01-01' -- the historical load will run from 1970 to bring in all data
                                )
                    )
                    FROM `{{params.project_id}}.curated.t_dim_ga_device`
);

SET todate_str = (  SELECT max(_TABLE_SUFFIX) as max_dt_str 
                    FROM `{{params.ga_project_id}}.{{params.ga_dataset_id}}.events_*`
                    WHERE _TABLE_SUFFIX > FORMAT_DATE('%Y%m%d', current_date - 7)
                    AND   _TABLE_SUFFIX NOT LIKE 'intraday%' 
);

SET todate_dt = CAST(todate_str AS DATE FORMAT 'YYYYMMDD');

-- STEP 2: MERGE DATA INTO t_dim_ga_device
MERGE INTO `{{params.project_id}}.curated.t_dim_ga_device` perm
USING (
    SELECT DISTINCT 
    up.value.string_value as id,
    IF(length(device.advertising_id) < 2 OR device.advertising_id='00000000-0000-0000-0000-000000000000',
        null,
        device.advertising_id
    ) as device_idfa,
    IF(length(device.vendor_id) < 2 OR device.vendor_id='00000000-0000-0000-0000-000000000000', 
        null,
        device.vendor_id
    ) as device_idfv,
    todate_dt as record_date 
    FROM `{{params.ga_project_id}}.{{params.ga_dataset_id}}.events_*`, UNNEST(user_properties) up
    WHERE _TABLE_SUFFIX BETWEEN fromdate_str AND todate_str 
    AND up.key = 'sfmc_contact_key'
    AND (length(up.value.string_value) = 18 OR length(up.value.string_value) = 32) 
) tmp
ON tmp.id = perm.id
AND (tmp.device_idfa = perm.device_idfa OR tmp.device_idfv = perm.device_idfv)
WHEN NOT MATCHED THEN
  INSERT ROW;