MERGE INTO `{{params.project_id}}.raw.customer_deletion_request` TARGET
USING `{{params.project_id}}.raw.temp_customer_deletion_request` SOURCE
ON TARGET.customer_deletion_request_id = SOURCE.customer_deletion_request_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.create_version_id=SOURCE.create_version_id,
TARGET.customer_deletion_request_id=SOURCE.customer_deletion_request_id,
TARGET.customer_id=SOURCE.customer_id,
TARGET.dwh_process_tms=SOURCE.dwh_process_tms,
TARGET.email_adr=SOURCE.email_adr,
TARGET.givex_amt=SOURCE.givex_amt,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;