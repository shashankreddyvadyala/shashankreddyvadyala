MERGE INTO `{{params.project_id}}.raw.customer_giveaway` TARGET
USING `{{params.project_id}}.raw.temp_customer_giveaway` SOURCE
ON ( TARGET.redemption_cod=SOURCE.redemption_cod AND TARGET.customer_id=SOURCE.customer_id

)
WHEN MATCHED THEN
UPDATE SET
TARGET.assignment_tms=SOURCE.assignment_tms,
TARGET.category=SOURCE.category,
TARGET.customer_id=SOURCE.customer_id,
TARGET.device_id=SOURCE.device_id,
TARGET.end_dat=SOURCE.end_dat,
TARGET.giveaway_amt=SOURCE.giveaway_amt,
TARGET.giveaway_type=SOURCE.giveaway_type,
TARGET.redemption_cod=SOURCE.redemption_cod,
TARGET.redemption_tms=SOURCE.redemption_tms,
TARGET.start_dat=SOURCE.start_dat,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;
