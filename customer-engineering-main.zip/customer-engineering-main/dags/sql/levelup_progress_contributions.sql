MERGE INTO `{{params.project_id}}.raw.levelup_progress_contributions` TARGET
USING `{{params.project_id}}.raw.temp_levelup_progress_contributions` SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.order_id=SOURCE.order_id,
TARGET.user_campaign_progress_total_id=SOURCE.user_campaign_progress_total_id,
TARGET.contribution=SOURCE.contribution,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;
