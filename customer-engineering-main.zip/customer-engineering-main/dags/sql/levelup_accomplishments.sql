MERGE INTO `{{params.project_id}}.raw.levelup_accomplishments` TARGET
USING `{{params.project_id}}.raw.temp_levelup_accomplishments` SOURCE
ON TARGET.id = SOURCE.id 
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.goal_id=SOURCE.goal_id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.threshold_as_integer=SOURCE.threshold_as_integer,
TARGET.expires_at=SOURCE.expires_at,
TARGET.goal_type=SOURCE.goal_type,
TARGET.overtaken=SOURCE.overtaken,
TARGET.terminal=SOURCE.terminal,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;