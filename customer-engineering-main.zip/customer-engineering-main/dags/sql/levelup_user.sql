MERGE INTO `{{params.project_id}}.raw.levelup_user` TARGET
USING `{{params.project_id}}.raw.temp_levelup_user` SOURCE
ON TARGET.loyalty_id = SOURCE.loyalty_id
WHEN MATCHED THEN
UPDATE SET
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.first_name = SOURCE.first_name,
TARGET.last_name=SOURCE.last_name,
TARGET.email=SOURCE.email,
TARGET.phone=SOURCE.phone,
TARGET.registered_at=SOURCE.registered_at,
TARGET.registered_device_type=SOURCE.registered_device_type,
TARGET.account_type=SOURCE.account_type,
TARGET.subscribed_to_emails =SOURCE.subscribed_to_emails,
TARGET.birthdate=SOURCE.birthdate,
TARGET.gender=SOURCE.gender,
TARGET.favorite_location=SOURCE.favorite_location,
TARGET.first_order_created_at=SOURCE.first_order_created_at,
TARGET.last_order_created_at=SOURCE.last_order_created_at,
TARGET.number_of_visits=SOURCE.number_of_visits,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;