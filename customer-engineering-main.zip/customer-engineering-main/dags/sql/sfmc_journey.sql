MERGE INTO `{{params.project_id}}.raw.SFMC_Journey` TARGET
USING `{{params.project_id}}.raw.temp_SFMC_Journey` SOURCE
ON TARGET.JourneyID=SOURCE.JourneyID AND TARGET.VersionID=SOURCE.VersionID
WHEN MATCHED THEN
UPDATE SET
TARGET.CreatedDate=SOURCE.CreatedDate,
TARGET.JourneyID=SOURCE.JourneyID,
TARGET.JourneyName=SOURCE.JourneyName,
TARGET.JourneyStatus=SOURCE.JourneyStatus,
TARGET.LastPublishedDate=SOURCE.LastPublishedDate,
TARGET.ModifiedDate=SOURCE.ModifiedDate,
TARGET.VersionID=SOURCE.VersionID,
TARGET.VersionNumber=SOURCE.VersionNumber,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.CreatedFullDate=SOURCE.CreatedFullDate,
TARGET.LastPublishedFullDate=SOURCE.LastPublishedFullDate,
TARGET.ModifiedFullDate=SOURCE.ModifiedFullDate

WHEN NOT MATCHED THEN
INSERT ROW;