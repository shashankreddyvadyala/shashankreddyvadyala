-------------------- Creating the dataset --------------------

CREATE SCHEMA IF NOT EXISTS
  `cdp-dev-bdfa.curated` OPTIONS( description="curated Layer" );
CREATE SCHEMA IF NOT EXISTS 
  `cdp-dev-bdfa.gold` OPTIONS( description="gold Layer" );
  
CREATE SCHEMA IF NOT EXISTS 
  `cdp-dev-bdfa.cdp_audiences` OPTIONS( description="cdp audiences Layer" );  

----------------------------- Creating the necessary tables --------------------------------

CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_fact_customer_order_trans` (CUSTOMER_ID INT64 OPTIONS( description="Unique identifier for customer"),
    CUSTOMER_ID_SRC STRING OPTIONS( description="Source for Unique identifier for customer example Digital/Rewards/creditcard"),
    SPEND_CATEGORY STRING OPTIONS( description="Category to identify if its digital or non-digital spend"),
    SITE_ADDR STRING OPTIONS( description="Site address which customer visited"),
    CARD_TOKEN STRING OPTIONS( description="Unique identifier for credit card for customer"),
    UNQ_ORDER STRING OPTIONS( description="Unique identifier to identify unique order"),
    SALES_TRANSACTION_ID STRING OPTIONS( description="Sales transaction ID"),
    SITE_NUM INT64 OPTIONS( description="Unique identification for each site"),
    BUSINESS_DATE DATE OPTIONS( description="Order date in Date format"),
    TRANSACTION_NUMBER INT64 OPTIONS( description="Unique identifier for transaction"),
    RECEIPT_ID INT64 OPTIONS( description="Unique identification"),
    MAINT_USER_ID STRING OPTIONS( description="MAINT_USER_ID"),
    MAINT_TMS TIMESTAMP OPTIONS( description="System generated time stamp"),
    SOURCE_SYSTEM_NAME STRING OPTIONS( description="Source system name"),
    DIM_SITE_KEY INT64 OPTIONS( description="DIM_SITE_KEY"),
    DIM_INSIGHT_SOURCE_KEY INT64 OPTIONS( description="DIM_INSIGHT_SOURCE_KEY"),
    DIM_CUSTOMER_KEY INT64 OPTIONS( description="DIM_CUSTOMER_KEY"),
    DIM_LOCATION_KEY INT64 OPTIONS( description="DIM_LOCATION_KEY"),
    LOCATION_NAME STRING OPTIONS( description="Categorical variable to identify example online etc"),
    TRANSACTION_REASON STRING OPTIONS( description="TRANSACTION_REASON"),
    TRANSACTION_TYPE_DESC STRING OPTIONS( description="Transaction type"),
    TRANSACTION_CLOSE_TIME_NUM INT64 OPTIONS( description="Time stamp"),
    TXN_UPDATEDATETIME_UTC TIMESTAMP OPTIONS( description="Updated timestamp"),
    TXN_CLOSE_TIME_UTC TIMESTAMP OPTIONS( description="Transaction close date in UTC"),
    TXN_CLOSE_TIME_LOCAL DATETIME OPTIONS( description="Transaction close date in local zone"),
    DIM_DAYPART_KEY INT64 OPTIONS( description="DIM_DAYPART_KEY"),
    DAYPART_NAME STRING OPTIONS( description="Type of order such as Breakfast Lunch etc"),
    EMPLOYEE_NUM INT64 OPTIONS( description="Unique identifier to identify employee"),
    CURRENCY_CODE STRING OPTIONS( description="Code to identify currency"),
    TENDER_AMT FLOAT64 OPTIONS( description="TENDER_AMT"),
    TENDER_CNT INT64 OPTIONS( description="TENDER_CNT"),
    TOTAL_TAX_AMT FLOAT64 OPTIONS( description="Total Tax Amount"),
    GROSS_SALES_AMT FLOAT64 OPTIONS( description="Gross sales amount including tax"),
    NET_SALES_AMT FLOAT64 OPTIONS( description="Net sales amount which customer need to to pay"),
    TRANSACTION_CNT INT64 OPTIONS( description="TRANSACTION_CNT"),
    DISCOUNT_AMT FLOAT64 OPTIONS( description="Discount amount given to customer"),
    DISCOUNT_CNT INT64 OPTIONS( description="Discount count"),
    KIDS_MEAL_AMT FLOAT64 OPTIONS( description="Kid meal amount if any"),
    KIDS_MEAL_CNT INT64 OPTIONS( description="Kid meal count if any"),
    KIDS_MEAL_TOY_AMT FLOAT64 OPTIONS( description="Kid meal toy amount if any"),
    KIDS_MEAL_TOY_CNT INT64 OPTIONS( description="kid meal toy amount if any"),
    GIFT_CARD_SALES_AMT FLOAT64 OPTIONS( description="Gift cards sales amount if any"),
    GIFT_CARD_SALES_CNT INT64 OPTIONS( description="Gift cards sales count if any"),
    GIFT_CERT_SALES_AMT FLOAT64 OPTIONS( description="GIFT_CERT_SALES_AMT"),
    GIFT_CERT_SALES_CNT INT64 OPTIONS( description="GIFT_CERT_SALES_CNT"),
    LOCAL_PROMO_AMT FLOAT64 OPTIONS( description="Promo amount if any"),
    LOCAL_PROMO_CNT INT64 OPTIONS( description="Promo count if any"),
    NATIONAL_PROMO_AMT FLOAT64 OPTIONS( description="NATIONAL_PROMO_AMT"),
    NATIONAL_PROMO_CNT INT64 OPTIONS( description="NATIONAL_PROMO_CNT"),
    MANAGER_VOID_AMT FLOAT64 OPTIONS( description="MANAGER_VOID_AMT"),
    MANAGER_VOID_CNT INT64 OPTIONS( description="MANAGER_VOID_CNT"),
    SURCHARGE_AMT FLOAT64 OPTIONS( description="SURCHARGE_AMT"),
    REGISTER_NUM INT64 OPTIONS( description="REGISTER_NUM"),
    REGISTER_OPERATOR_VOID_CNT INT64 OPTIONS( description="REGISTER_OPERATOR_VOID_CNT"),
    END_OF_DAY_COMPLETE_FLAG STRING OPTIONS( description="END_OF_DAY_COMPLETE_FLAG"),
    DGTL_CUSTOMER_ORDER_ID INT64 OPTIONS( description="Unique identifier DGTL_CUSTOMER_ORDER_ID"),
    DGTL_ORDER_ID INT64 OPTIONS( description="DGTL_ORDER_ID"),
    DGTL_POS_ORDER_NUM INT64 OPTIONS( description="DGTL_POS_ORDER_NUM"),
    DGTL_ATO_ORDER_ID INT64 OPTIONS( description="DGTL_ATO_ORDER_ID"),
    DGTL_ORDER_STATUS_COD STRING OPTIONS( description="Order status code example Prepared"),
    DGTL_CREATE_TMS TIMESTAMP OPTIONS( description="Timestamp"),
    DGTL_SUBTOTAL_AMT FLOAT64 OPTIONS( description="Digital subtotal amount"),
    DGTL_TAX_AMT FLOAT64 OPTIONS( description="Digital tax amount"),
    DGTL_TOTAL_AMT FLOAT64 OPTIONS( description="Digital total amount"),
    DGTL_LATITUDE_NUM FLOAT64 OPTIONS( description="Coordinates information"),
    DGTL_LONGITUDE_NUM FLOAT64 OPTIONS( description="Cordinates information"),
    LU_STREET_ADDRESS STRING OPTIONS( description="Levelup Street address"),
    LU_CHANNEL STRING OPTIONS( description="Levelup Order channel"),
    LU_ORDER_ID INT64 OPTIONS( description="Levelup unique identifier for order"),
    LU_CREATED_AT DATETIME OPTIONS( description="LU_CREATED_AT"),
    LU_LOYALTY_ID INT64 OPTIONS( description="Unique identifier"),
    LU_SUBTOTAL_AMT FLOAT64 OPTIONS( description="Levelup subtotal amount"),
    LU_TAX_AMT FLOAT64 OPTIONS( description="Levelup tax amount"),
    LU_TOTAL_AMT FLOAT64 OPTIONS( description="Levelup total amount"),
    LU_ORDER_SOURCE STRING OPTIONS( description="Levelup order source"),
    LU_REWARD_CREDIT_REDEEMED INT64 OPTIONS( description="Levelup Rewards of each loyality ID") )
PARTITION BY
  BUSINESS_DATE;


CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_mdl_rfm` ( CUSTOMER_ID INT64 OPTIONS(description="Wendy's digital customer ID"),
    FREQUENCY INT64 OPTIONS(description="Number of transactions made by customer in the last 12 months"),
    RECENCY INT64 OPTIONS(description="Number of days between the customer's first and last transaction within the last 12 months"),
    MONETARY_VALUE FLOAT64 OPTIONS(description="Average check amount (net sales) for the customer's transactions in the last 12 months"),
    T INT64 OPTIONS(description="Number of days since the customer's first transaction made within the last 12 months"),
    CREATED_DATE DATE OPTIONS(description="Created date") )
PARTITION BY
  CREATED_DATE;


CREATE TABLE IF NOT EXISTS
`cdp-dev-bdfa.curated.t_dim_customer_domain` ( DGTL_CUST_ID INT64 OPTIONS(description="Digital customer ID"),
SF_CONTACT_ID STRING OPTIONS(description="Salesforce Marketing Cloud ID"),
SF_VENDOR_ID STRING OPTIONS(description="Salesforce Service Cloud ID"),
LVL_UP_LOYALTY_ID INT64 OPTIONS(description="Level Up Loyalty ID"),
FIRST_NAME STRING OPTIONS(description="First Name(PII)"),
LAST_NAME STRING OPTIONS(description="LAST Name(PII)"),
BIRTH_DATE TIMESTAMP OPTIONS(description="BIRTH DATE(PII)"),
GENDER STRING  OPTIONS(description="GENDER"),
LANG_CODE STRING  OPTIONS(description="Language code ex- en "),
COUNTRY_CODE STRING  OPTIONS(description="Country code ex. US or CA"),
LATITUDE FLOAT64  OPTIONS(description="LATITUDE"),
LONGITUDE FLOAT64  OPTIONS(description="LONGITUDE"),
CC_POSTAL_CODES ARRAY<STRING>  OPTIONS(description="Array of postal codes tied to credit cards that the customer has added to his/her digital payment profile(PII)"),
DELIVERY_ADDRESSES ARRAY<STRING>  OPTIONS(description="Array of delivery addresses that the customer has used for delivery orders(PII)"),
DELIVERY_COORDS ARRAY<struct<LATITUDE FLOAT64, LONGITUDE FLOAT64>>  OPTIONS(description="Array of lat-long coordinates of delivery addresses that the customer has used for delivery orders(PII)"),
CURRENCY_CODE STRING  OPTIONS(description="Currency code ex. USD or CAD"),
EMAIL STRING  OPTIONS(description="Email address(PII)"),
EMAIL_OPT_IN STRING(1)  OPTIONS(description="Flag that denotes Opt-in status for emails"),
POSTAL_CODE STRING  OPTIONS(description="Postal Code"),
STATE STRING  OPTIONS(description="STATE"),
VETERAN_FLAG STRING  OPTIONS(description="Veteran status"),
PHONE STRING  OPTIONS(description="PHONE NUMBER(PII)"),
FAVORITE_LOCATION STRING  OPTIONS(description="FAVORITE LOCATION"),
DGTL_CUST_CREATE_TMS TIMESTAMP  OPTIONS(description="Date of digital account creation"),
LVL_UP_CREATE_TMS DATETIME  OPTIONS(description="Date of Level Up loyalty account creation"),
LVL_UP_FIRST_VISIT_TMS STRING  OPTIONS(description="The first date where the customer made a purchase tied to their loyalty account"),
LVL_UP_NUM_VISITS INT64  OPTIONS(description="The total loyalty purchases made by the customer via Level Up"),
LVL_UP_LOY_BAL INT64  OPTIONS(description="Loyalty Point Balance of the customer"),
LVL_UP_LOY_TOT_PTS INT64  OPTIONS(description="The total Loyalty points earned by customer"));


CREATE TABLE IF NOT EXISTS
`cdp-dev-bdfa.curated.t_fact_order_domain` ( 
CUSTOMER_ID INT64  OPTIONS(description="Digital customer ID"),
REPEAT_CUST_FLAG INT64  OPTIONS(description="Binary Indicator for Repeat Customers -greater than 1 visit in 12 months"),
FREQ_12MO INT64  OPTIONS(description="Number of Times a customer has completed a purchase in 12MONTH"),
FREQ_CATEGORY_BIN STRING  OPTIONS(description="Grouped by Number of Purchases-Purchase Count in the last 12 months, avg 1.5 purchases per month"),
FREQ_PERCENT_BIN STRING  OPTIONS(description="Grouped by Number of Purchases-Quartile in the last 12 months"),
AVG_CHECK_12MO FLOAT64  OPTIONS(description="The average check size for the customer over the lookback period -null if no orders were made"),
LAST_VISIT_TMS DATE  OPTIONS(description="Date of most recent purchase"),
DAYS_SINCE_LAST_VISIT INT64  OPTIONS(description="Number of days since the last purchase"),
AVG_CHECK_BKFST FLOAT64  OPTIONS(description="The average check size for the customer during breakfast-4:00 - 10:30"),
AVG_CHECK_LUNCH FLOAT64  OPTIONS(description="The average check size for the customer during lunch-10:30 - 13:59"),
AVG_CHECK_AFTN FLOAT64  OPTIONS(description="The average check size for the customer during afternoon snack 14:00 - 16:59"),
AVG_CHECK_DINNER FLOAT64  OPTIONS(description="The average check size for the customer during dinner-17:00 - 19:59"),
AVG_CHECK_PM_SNK FLOAT64  OPTIONS(description="The average check size for the customer during PM snack-20:00 - 21:59"),
AVG_CHECK_LATE_NT FLOAT64  OPTIONS(description="The average check size for the customer during late night-22:00 - 03:59"),
FREQ_BKFST INT64  OPTIONS(description="Number of Times a customer has completed a purchase during breakfast-4:00 - 10:30"),
FREQ_LUNCH INT64  OPTIONS(description="Number of Times a customer has completed a purchase during lunch-10:30 - 13:59"),
FREQ_AFTN INT64  OPTIONS(description="Number of Times a customer has completed a purchase during afternoon snack-14:00 - 16:59"),
FREQ_DINNER INT64  OPTIONS(description="Number of Times a customer has completed a purchase during dinner-17:00 - 19:59"),
FREQ_PM_SNK INT64  OPTIONS(description="Number of Times a customer has completed a purchase during PM Snack-20:00 - 21:59"),
FREQ_LATE_NT INT64  OPTIONS(description="Number of Times a customer has completed a purchase during late night-22:00 - 03:59"),
PCT_DISCOUNTED FLOAT64  OPTIONS(description="% Discounted Total Discounted / Total Spent + Total Discounted"),
FREQ_1MO INT64  OPTIONS(description="Number of Times a customer has completed a purchase in 1MONTH"),
AVG_CHECK_1MO FLOAT64  OPTIONS(description="The average check size for the customer over the lookback period -null if no orders were made"),
FREQ_3MO INT64  OPTIONS(description="Number of Times a customer has completed a purchase in 3MONTH"),
AVG_CHECK_3MO FLOAT64  OPTIONS(description="The average check size for the customer over the lookback period -null if no orders were made"),
FREQ_6MO INT64  OPTIONS(description="Number of Times a customer has completed a purchase in 6MONTH"),
AVG_CHECK_6MO FLOAT64  OPTIONS(description="The average check size for the customer over the lookback period -null if no orders were made"),
FREQ_MARCH INT64  OPTIONS(description="Number of Times a customer has completed a purchase in March"),
PCT_DIGITAL_SPEND FLOAT64  OPTIONS(description="% Digital Spend of Total Spend -Digital Spend / Digital Spend + Non-Digital Spend"),
VISITED_SITE_ADDRS ARRAY<STRING>  OPTIONS(description="Array of restaurant addresses where customer has made purchases within the last 12 months"),
VISITED_SITE_NUMS ARRAY<INT64>  OPTIONS(description="Array of restaurant numbers where customer has made purchases within the last 12 months"),
CLTV_12MO FLOAT64 OPTIONS(description="Output customer lifetime value from predictive model (as opposed to simple formula)"),
ALIVE_PROB FLOAT64 OPTIONS(description="Probability that the customer will not churn. Values close to 0 mean the customer is likely to churn."),
FUTURE_12MO_PURCHASE FLOAT64 OPTIONS(description="Predicted number of purchases that the customer will make in the next 12 months"),
CLTV_SEGMENT STRING  OPTIONS(description="Predicted segements for each customer such as low,mid and high"),
LAST_UPDT_TMS TIMESTAMP  OPTIONS(description="LAST UPDATE DATE")
);


CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_mdl_cltv_checkpoints` ( CREATED_TMS TIMESTAMP OPTIONS(description="Model Created timestamp"),
    PARETO_NBD_R FLOAT64 OPTIONS(description="Shape parameter of the Gamma distribution of the purchase process. The smaller r, the stronger the heterogeneity of the purchase process."),
    PARETO_NBD_ALPHA FLOAT64 OPTIONS(description="Rate parameter of the Gamma distribution of the purchase process."),
    PARETO_NBD_S FLOAT64 OPTIONS(description="Shape parameter of the Gamma distribution for the lifetime process. The smaller s, the stronger the heterogeneity of customer lifetimes."),
    PARETO_NBD_BETA FLOAT64 OPTIONS(description="Rate parameter for the Gamma distribution for the lifetime process."),
    GAMMA_GAMMA_P FLOAT64 OPTIONS(description="Shape parameter of the Gamma distribution of the spending process."),
    GAMMA_GAMMA_Q FLOAT64 OPTIONS(description="Shape parameter of the Gamma distribution to account for customer heterogeneity."),
    GAMMA_GAMMA_V FLOAT64 OPTIONS(description="Scale parameter of the Gamma distribution to account for customer heterogeneity."),
    RMSE FLOAT64 OPTIONS(description="Model Root Mean Squared Error"),
    MODEL_NO INT64 OPTIONS(description="Model Version Number"),
    TRAINING_DATASET_SIZE INT64 OPTIONS(description="Size of the training data used in model building"),
    MODEL_PATH ARRAY<STRING> OPTIONS(description="Model GCS Path") );
    

CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_fact_dgtl_cust_link` (
    dgtl_cust_id INT64 OPTIONS(description="Wendy's digital customer ID"),
    dgtl_cust_link_id INT64 OPTIONS(description="Wendy's digital customer link ID"));



CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_mdl_kmeans_checkpoints` ( CREATED_TMS TIMESTAMP OPTIONS(description="Model Created timestamp"),
    MODEL_NO INT64 OPTIONS(description="Model Version Number"),
    CLUSTER_ID INT64 OPTIONS(description="Id of the cluster"),
    CLTV_SEGMENT STRING OPTIONS(description="Segments such as high,mid,low"),
    INSTANCE_COUNT INT64 OPTIONS(description="Number of records allocated against a cluster"),
    RULES STRING OPTIONS(description="Based on which condition the cluster got created."),
    FUTURE_12MO_PURCHASE_MEAN FLOAT64 OPTIONS(description="Centroids value allocated by kmeans for FUTURE_12MO_PURCHASE feature"),
    CONCENTRATION FLOAT64 OPTIONS(description="Probability of a cluster"),
    TRAINING_DATASET_SIZE INT64 OPTIONS(description="Size of the training data used in model building"),
    MODEL_PATH ARRAY<STRING> OPTIONS(description="Model GCS Path"));


CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_fact_unified_customer` ( UUID STRING OPTIONS(description="Customer's unique ID") ,
    DGTL_CUST_ID INT64 OPTIONS(description="Digital customer ID"),
    SF_CONTACT_ID STRING OPTIONS(description="Salesforce Marketing Cloud ID"),
    SF_VENDOR_ID STRING OPTIONS(description="Salesforce Service Cloud ID"),
    LVL_UP_LOYALTY_ID INT64 OPTIONS(description="Level Up Loyalty ID"),
    FIRST_NAME STRING OPTIONS(description="First Name(PII)"),
    LAST_NAME STRING OPTIONS(description="Last Name(PII)"),
    BIRTH_DATE TIMESTAMP OPTIONS(description="Date of birth(PII)"),
    GENDER STRING OPTIONS(description="Gender"),
    LANG_CODE STRING OPTIONS(description="Language code (ex. 'en')"),
    COUNTRY_CODE STRING OPTIONS(description="Country code (ex. 'US' or 'CA')"),
    LATITUDE FLOAT64 OPTIONS(description="Latitude"),
    LONGITUDE FLOAT64 OPTIONS(description="Longitude"),
    CURRENCY_CODE STRING OPTIONS(description="Currency code (ex. 'USD' or 'CAD')"),
    EMAIL STRING OPTIONS(description="Email address(PII)"),
    EMAIL_OPT_IN STRING(1) OPTIONS(description="Flag that denotes Opt-in status for emails"),
    POSTAL_CODE STRING OPTIONS(description="Postal Code"),
    STATE STRING OPTIONS(description="State"),
    VETERAN_FLAG STRING OPTIONS(description="Veteran status"),
    PHONE STRING OPTIONS(description="Phone number,NOTE: This data is currently not collected so most entries are null(PII)"),
    FAVORITE_LOCATION STRING OPTIONS(description="Favorite location"),
    LVL_UP_CREATE_TMS DATETIME OPTIONS(description="Date of Level Up loyalty account creation"),
    LVL_UP_FIRST_VISIT_TMS STRING OPTIONS(description="The first date where the customer made a purchase tied to their loyalty account"),
    LVL_UP_NUM_VISITS INT64 OPTIONS(description="The total loyalty purchases made by the customer via Level Up"),
    LVL_UP_LOY_BAL INT64 OPTIONS(description="Loyalty Point Balance of the customer"),
    LVL_UP_LOY_TOT_PTS INT64 OPTIONS(description="The total Loyalty points earned by customer"),
    DGTL_CUST_CREATE_TMS TIMESTAMP OPTIONS(description="Date of digital account creation"),
    VISITED_SITE_ADDRS ARRAY<STRING> OPTIONS(description="Array of restaurant addresses where customer has made purchases within the last 12 months"),
    VISITED_SITE_NUMS ARRAY<INT64> OPTIONS(description="Array of restaurant numbers where customer has made purchases within the last 12 months"),
    CC_POSTAL_CODES ARRAY<STRING> OPTIONS(description="Array of postal codes tied to credit cards that the customer has added to his/her digital payment profile(PII)"),
    CC_TOKENS ARRAY<STRING> OPTIONS(description="Array of credit card tokens that the customer has used to make digital purchases(PII)"), 
    DEVICE_IDFA ARRAY<STRING> OPTIONS(description="Array of device IDFAs used by the customer(PII)"),  
    DEVICE_IDFV ARRAY<STRING> OPTIONS(description="Array of device IDFVs used by the customer(PII)"),
    DELIVERY_ADDRESSES ARRAY<STRING> OPTIONS(description="Array of delivery addresses that the customer has used for delivery orders(PII)"),
    DELIVERY_COORDS ARRAY<STRUCT<latitude FLOAT64 ,longitude FLOAT64>> OPTIONS(description="Array of lat-long coordinates of delivery addresses that the customer has used for delivery orders(PII)"),
    REPEAT_CUST_FLAG INT64 OPTIONS(description="Binary Indicator for Repeat Customers (greater than 1 visit in 12 months)"),
    FREQ_1MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase in 1 month timeframe"),
    FREQ_3MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 3 month timeframe"),
    FREQ_6MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 6 month timeframe"),
    FREQ_12MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 12 month timeframe"),
    FREQ_MARCH INT64 OPTIONS(description="Number of Times a customer has completed a purchase in March"),
    FREQ_CATEGORY_BIN STRING OPTIONS(description="Grouped by Number of Purchases (Purchase Count in the last 12 months, avg 1.5 purchases per month)"),
    FREQ_PERCENT_BIN STRING OPTIONS(description="Grouped by Number of Purchases (Quartile in the last 12 months)"),
    CLTV_12MO FLOAT64 OPTIONS(description="Output customer lifetime value from predictive model (as opposed to simple formula)"),
    ALIVE_PROB FLOAT64 OPTIONS(description="Probability that the customer will not churn. Values close to 0 mean the customer is likely to churn."),
    FUTURE_12MO_PURCHASE FLOAT64 OPTIONS(description="Predicted number of purchases that the customer will make in the next 12 months"),
    CLTV_SEGMENT STRING OPTIONS(description="Predicted segements for each customer such as low,mid and high"),
    AVG_CHECK_1MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_3MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_6MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_12MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    LAST_VISIT_TMS DATE OPTIONS(description="Date of most recent purchase"),
    DAYS_SINCE_LAST_VISIT INT64 OPTIONS(description="Number of days since the last purchase"),
    AVG_CHECK_BKFST FLOAT64 OPTIONS(description="The average check size for the customer during breakfast (4:00 - 10:30)"),
    AVG_CHECK_LUNCH FLOAT64 OPTIONS(description="The average check size for the customer during lunch (10:30 - 13:59)"),
    AVG_CHECK_AFTN FLOAT64 OPTIONS(description="The average check size for the customer during afternoon snack (14:00 - 16:59)"),
    AVG_CHECK_DINNER FLOAT64 OPTIONS(description="The average check size for the customer during dinner (17:00 - 19:59)"),
    AVG_CHECK_PM_SNK FLOAT64 OPTIONS(description="The average check size for the customer during PM snack (20:00 - 21:59)"),
    AVG_CHECK_LATE_NT FLOAT64 OPTIONS(description="The average check size for the customer during late night (22:00 - 03:59)"),
    FREQ_BKFST INT64 OPTIONS(description="Number of Times a customer has completed a purchase during breakfast (4:00 - 10:30)"),
    FREQ_LUNCH INT64 OPTIONS(description="Number of Times a customer has completed a purchase during lunch (10:30 - 13:59)"),
    FREQ_AFTN INT64 OPTIONS(description="Number of Times a customer has completed a purchase during afternoon snack (14:00 - 16:59)"),
    FREQ_DINNER INT64 OPTIONS(description="Number of Times a customer has completed a purchase during dinner (17:00 - 19:59)"),
    FREQ_PM_SNK INT64 OPTIONS(description="Number of Times a customer has completed a purchase during PM Snack (20:00 - 21:59)"),
    FREQ_LATE_NT INT64 OPTIONS(description="Number of Times a customer has completed a purchase during late night (22:00 - 03:59)"),
    PCT_DISCOUNTED FLOAT64 OPTIONS(description="% Digital Spend of Total Spend  (Digital Spend / (Digital Spend + Non-Digital Spend))"),
    PCT_DIGITAL_SPEND FLOAT64 OPTIONS(description="% Discounted  (Total Discounted / (Total Spent + Total Discounted))"),
    LAST_UPDT_TMS TIMESTAMP OPTIONS(description="When the C360 customer record is last updated")
    );


CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.gold.t_fact_unified_customer` ( UUID STRING OPTIONS(description="Customer's unique ID") ,
    DGTL_CUST_ID INT64 OPTIONS(description="Digital customer ID"),
    SF_CONTACT_ID STRING OPTIONS(description="Salesforce Marketing Cloud ID"),
    SF_VENDOR_ID STRING OPTIONS(description="Salesforce Service Cloud ID"),
    LVL_UP_LOYALTY_ID INT64 OPTIONS(description="Level Up Loyalty ID"),
    GENDER STRING OPTIONS(description="Gender"),
    LANG_CODE STRING OPTIONS(description="Language code (ex. 'en')"),
    COUNTRY_CODE STRING OPTIONS(description="Country code (ex. 'US' or 'CA')"),
    LATITUDE FLOAT64 OPTIONS(description="Latitude"),
    LONGITUDE FLOAT64 OPTIONS(description="Longitude"),
    CURRENCY_CODE STRING OPTIONS(description="Currency code (ex. 'USD' or 'CAD')"),
    EMAIL_OPT_IN STRING(1) OPTIONS(description="Flag that denotes Opt-in status for emails"),
    POSTAL_CODE STRING OPTIONS(description="Postal Code"),
    STATE STRING OPTIONS(description="State"),
    VETERAN_FLAG STRING OPTIONS(description="Veteran status"),
    FAVORITE_LOCATION STRING OPTIONS(description="Favorite location"),
    LVL_UP_CREATE_TMS DATETIME OPTIONS(description="Date of Level Up loyalty account creation"),
    LVL_UP_FIRST_VISIT_TMS STRING OPTIONS(description="The first date where the customer made a purchase tied to their loyalty account"),
    LVL_UP_NUM_VISITS INT64 OPTIONS(description="The total loyalty purchases made by the customer via Level Up"),
    LVL_UP_LOY_BAL INT64 OPTIONS(description="Loyalty Point Balance of the customer"),
    LVL_UP_LOY_TOT_PTS INT64 OPTIONS(description="The total Loyalty points earned by customer"),
    DGTL_CUST_CREATE_TMS TIMESTAMP OPTIONS(description="Date of digital account creation"),
    VISITED_SITE_ADDRS ARRAY<STRING> OPTIONS(description="Array of restaurant addresses where customer has made purchases within the last 12 months"),
    VISITED_SITE_NUMS ARRAY<INT64> OPTIONS(description="Array of restaurant numbers where customer has made purchases within the last 12 months"),
    REPEAT_CUST_FLAG INT64 OPTIONS(description="Binary Indicator for Repeat Customers (greater than 1 visit in 12 months)"),
    FREQ_1MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase in 1 month timeframe"),
    FREQ_3MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 3 month timeframe"),
    FREQ_6MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 6 month timeframe"),
    FREQ_12MO INT64 OPTIONS(description="Number of Times a customer has completed a purchase  in 12 month timeframe"),
    FREQ_MARCH INT64 OPTIONS(description="Number of Times a customer has completed a purchase in March"),
    FREQ_CATEGORY_BIN STRING OPTIONS(description="Grouped by Number of Purchases (Purchase Count in the last 12 months, avg 1.5 purchases per month)"),
    FREQ_PERCENT_BIN STRING OPTIONS(description="Grouped by Number of Purchases (Quartile in the last 12 months)"),
    CLTV_12MO FLOAT64 OPTIONS(description="Output customer lifetime value from predictive model (as opposed to simple formula)"),
    ALIVE_PROB FLOAT64 OPTIONS(description="Probability that the customer will not churn. Values close to 0 mean the customer is likely to churn."),
    FUTURE_12MO_PURCHASE FLOAT64 OPTIONS(description="Predicted number of purchases that the customer will make in the next 12 months"),
    CLTV_SEGMENT STRING OPTIONS(description="Predicted segements for each customer such as low,mid and high"),
    AVG_CHECK_1MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_3MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_6MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    AVG_CHECK_12MO FLOAT64 OPTIONS(description="The average check size for the customer over the lookback period (null if no orders were made)"),
    LAST_VISIT_TMS DATE OPTIONS(description="Date of most recent purchase"),
    DAYS_SINCE_LAST_VISIT INT64 OPTIONS(description="Number of days since the last purchase"),
    AVG_CHECK_BKFST FLOAT64 OPTIONS(description="The average check size for the customer during breakfast (4:00 - 10:30)"),
    AVG_CHECK_LUNCH FLOAT64 OPTIONS(description="The average check size for the customer during lunch (10:30 - 13:59)"),
    AVG_CHECK_AFTN FLOAT64 OPTIONS(description="The average check size for the customer during afternoon snack (14:00 - 16:59)"),
    AVG_CHECK_DINNER FLOAT64 OPTIONS(description="The average check size for the customer during dinner (17:00 - 19:59)"),
    AVG_CHECK_PM_SNK FLOAT64 OPTIONS(description="The average check size for the customer during PM snack (20:00 - 21:59)"),
    AVG_CHECK_LATE_NT FLOAT64 OPTIONS(description="The average check size for the customer during late night (22:00 - 03:59)"),
    FREQ_BKFST INT64 OPTIONS(description="Number of Times a customer has completed a purchase during breakfast (4:00 - 10:30)"),
    FREQ_LUNCH INT64 OPTIONS(description="Number of Times a customer has completed a purchase during lunch (10:30 - 13:59)"),
    FREQ_AFTN INT64 OPTIONS(description="Number of Times a customer has completed a purchase during afternoon snack (14:00 - 16:59)"),
    FREQ_DINNER INT64 OPTIONS(description="Number of Times a customer has completed a purchase during dinner (17:00 - 19:59)"),
    FREQ_PM_SNK INT64 OPTIONS(description="Number of Times a customer has completed a purchase during PM Snack (20:00 - 21:59)"),
    FREQ_LATE_NT INT64 OPTIONS(description="Number of Times a customer has completed a purchase during late night (22:00 - 03:59)"),
    PCT_DISCOUNTED FLOAT64 OPTIONS(description="% Digital Spend of Total Spend  (Digital Spend / (Digital Spend + Non-Digital Spend))"),
    PCT_DIGITAL_SPEND FLOAT64 OPTIONS(description="% Discounted  (Total Discounted / (Total Spent + Total Discounted))"),
    LAST_UPDT_TMS TIMESTAMP OPTIONS(description="When the C360 customer record is last updated")
    );




CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.curated.t_dim_uuid` ( UUID STRING OPTIONS(description="UNIQUE IDENTIFIER"),
    CUSTOMER_ID INT64 OPTIONS(description="Digital customer ID"),
    FIRST_NAME STRING OPTIONS(description="FIRST NAME(PII)"),
    LAST_NAME STRING OPTIONS(description="LAST NAME(PII)"),
    PHONE STRING OPTIONS(description="PHONE NUMBER(PII)"),
    EMAIL STRING OPTIONS(description="EMAIL ADDRESS(PII)"),
    VENDOR_ID STRING OPTIONS(description="CUSTOMER VENDOR ID"),
    SF_CONTACT_ID STRING OPTIONS(description="SFMC CONTACT ID"),
    CREATED_TMS TIMESTAMP OPTIONS(description="CREATED DATE"),);


CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.curated.t_dim_ga_domain`(
  ID STRING OPTIONS(description="The sfmc_contact_key that was stored in the GA4 event's user properties. 18-digit values map to the Salesforce ContactID and 32-digit values map to the Salesforce VendorID."),
  ID_TYPE STRING OPTIONS(description="The type of id, either: sf_contact_id, vendor_id."),
  DEVICE_IDFA ARRAY<STRING> OPTIONS(description="Array of all device IDFAs from GA4 used by the customer(PII)"),
  DEVICE_IDFV ARRAY<STRING> OPTIONS(description="Array of all device IDFVs from GA4 used by the customer(PII)")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.curated.t_dim_ga_device`
(
  ID            STRING      OPTIONS(description="The sfmc_contact_key that was stored in the GA4 event's user properties. 18-digit values map to the Salesforce ContactID and 32-digit values map to the Salesforce VendorID."),
  DEVICE_IDFA   STRING      OPTIONS(description="The device IDFA provided by GA4(PII)"),
  DEVICE_IDFV   STRING      OPTIONS(description="The device IDFV provided by GA4(PII)"),
  RECORD_DATE   DATE        OPTIONS(description="This record's insert date.")
)
PARTITION BY RECORD_DATE;
  

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.curated.t_dim_customer_address`
(
  CUSTOMER_ID INT64 OPTIONS(description="Digital customer ID"),
  ADDRESS_TYP STRING OPTIONS(description="The source of address, either: credit card or delivery address"),
  ADDRESS1_TXT STRING OPTIONS(description="Address line 1(PII)"),
  ADDRESS2_TXT STRING OPTIONS(description="Address line 2(PII)"),
  CITY_TXT STRING OPTIONS(description="Address city"),
  STATE_COD STRING OPTIONS(description="Address state"),
  POSTAL_COD STRING OPTIONS(description="Address postal code"),
  CNTRY_COD STRING OPTIONS(description="Address country"),
  LATITUDE_NUM FLOAT64 OPTIONS(description="Latitude coordinate"),
  LONGITUDE_NUM FLOAT64 OPTIONS(description="Longitude coordinate"),
  RECORD_DATE DATE OPTIONS(description="This record's insert date.")
)
PARTITION BY RECORD_DATE;

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.raw.aci`
(
  CORPORATION_NAME STRING OPTIONS(description="Corporation Name"),
  STORE_LOCATION_ID INT64 OPTIONS(description="Store Location ID"),
  STORE_LOCATION_NAME STRING OPTIONS(description="Store Location Name"),
  TERMINAL_ID INT64 OPTIONS(description="Terminal ID"),
  AUTHORIZER_DESCRIPTION STRING OPTIONS(description="Authorizer description"),
  ACCOUNT STRING OPTIONS(description="Account used for transaction"),
  TOKEN STRING OPTIONS(description="Credit card token(PII)"),
  AMOUNT FLOAT64 OPTIONS(description="Transaction Amount"),
  JOURNAL_MESSAGE STRING OPTIONS(description="Status of the journal"),
  JOURNAL_KEY STRING OPTIONS(description="Journal Key"),
  STATUS_CODE STRING  OPTIONS(description="Status code"),
  SWITCH_RECEIVE STRING  OPTIONS(description="Switch receive"),
  AUTH_SEND STRING  OPTIONS(description="Auth send"),
  AUTH_RECEIVE STRING  OPTIONS(description="Auth received"),
  SWITCH_SEND STRING  OPTIONS(description="Switch send"),
  AUTH_TIME__SECS_ INT64  OPTIONS(description="AUTH_TIME__SECS_"),
  RCS_TIME__SECS_ INT64  OPTIONS(description="RCS_TIME__SECS_"),
  TOTAL_TIME__SECS_ INT64  OPTIONS(description="TOTAL_TIME__SECS_"),
  MESSAGE_TYPE STRING  OPTIONS(description="MESSAGE_TYPE"),
  DEBIT_CREDIT_IND STRING  OPTIONS(description="DEBIT_CREDIT_IND"),
  TENDER_TYPE STRING  OPTIONS(description="TENDER_TYPE"),
  RTRN_CODE INT64  OPTIONS(description="RTRN_CODE"),
  AUTHORIZER_CONNECTIO STRING  OPTIONS(description="AUTHORIZER_CONNECTIO"),
  AUTH_CODE STRING  OPTIONS(description="AUTH_CODE"),
  TRANSACTION_TYPE STRING  OPTIONS(description="TRANSACTION_TYPE"),
  STORE_TIMESTAMP TIMESTAMP  OPTIONS(description="STORE_TIMESTAMP"),
  USER_FIELD_1 STRING  OPTIONS(description="USER_FIELD_1")
)
PARTITION BY DATE(STORE_TIMESTAMP);


CREATE TABLE `cdp-dev-bdfa.curated.t_dim_aci_token`
(
  customer_id   INT64       OPTIONS(description="The digital customer ID"),
  token         STRING      OPTIONS(description="The credit card token provided by ACI"),
  last_used     DATETIME   OPTIONS(description="The timestamp (UTC) in which the credit card token was last used for a digital order")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.raw.temp_idr_customer`
(
  DGTL_CUST_ID INT64  OPTIONS( description="Digital customer ID"),
  FN_cleaned STRING  OPTIONS( description="FN_cleaned"),
  LN_cleaned STRING  OPTIONS( description="LN_cleaned"),
  FIRST_NAME STRING  OPTIONS( description="First Name(PII)"),
  LAST_NAME STRING  OPTIONS( description="Last Name(PII)"),
  EMAIL STRING  OPTIONS( description="Email(PII)"),
  EMAIL_REGEX STRING  OPTIONS( description="Regex applied email"),
  EMAIL_SUBSTRING STRING  OPTIONS( description="Email substring"),
  BIRTH_MONTH INT64  OPTIONS( description="Birth Month(PII)"),
  BIRTH_DAY INT64  OPTIONS( description="Birth Day(PII)"),
  POSTAL_CODE STRING  OPTIONS( description="Postal Code"),
  CC_POSTAL_CODES ARRAY<STRING>  OPTIONS( description="Array of postal codes tied to credit cards that the customer has added to his/her digital payment profile(PII)"),
  FAVORITE_LOCATION STRING  OPTIONS( description="favorite location"),
  VISITED_SITE_NUMS ARRAY<INT64>  OPTIONS( description="Array of restaurant numbers where customer has made purchases"),
  DEVICE_ARRAY ARRAY<STRING>  OPTIONS( description="Array of devices customer used to make a purchase")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.raw.temp_idr_cust_dev_match`
(
  dgtl_cust_id_a INT64  OPTIONS( description="Digital customer ID"),
  dgtl_cust_id_b INT64  OPTIONS( description="Digital customer ID")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.curated.t_fact_dgtl_cust_link`
(
  dgtl_cust_id INT64  OPTIONS( description="Digital customer ID"),
  dgtl_cust_link_id INT64  OPTIONS( description="Digital customer link ID")
);

CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.cdp_audiences.t_mdl_breakfast_audience_checkpoints` (
    MODEL_VERSION INT64 OPTIONS(description="Version of the model"),
    MODEL_PATH STRING OPTIONS(description="Path of the parameter file in GCS"),
    TRAINING_DATASET_SIZE INT64 OPTIONS(description="Size of the training data"),
    AUC FLOAT64 OPTIONS(description="Model area under the curve"),
    CREATED_TMS TIMESTAMP OPTIONS(description="Model creation timestamp")
 ) ;

CREATE TABLE IF NOT EXISTS 

  `cdp-dev-bdfa.cdp_audiences.cdp_breakfast_audience` (

    UUID STRING OPTIONS(description="Customer's unique ID") ,

    SF_CONTACT_ID STRING OPTIONS(description="Salesforce Marketing Cloud ID"),

    CUSTOMER_TYPE STRING OPTIONS(description="Breakfast or Non-breakfast customer"),

    PROB_BREAKFAST FLOAT64 OPTIONS(description="Probability of being a breakfast customer"),

    CREATED_DATE DATE OPTIONS(description="Audience creation date")

  ) PARTITION BY CREATED_DATE;