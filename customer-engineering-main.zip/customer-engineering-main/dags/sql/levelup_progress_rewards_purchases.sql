MERGE INTO `{{params.project_id}}.raw.levelup_progress_rewards_purchases` TARGET
USING `{{params.project_id}}.raw.temp_levelup_progress_rewards_purchases` SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.created_at=SOURCE.created_at,
TARGET.id=SOURCE.id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.purchasable_progress_reward_id=SOURCE.purchasable_progress_reward_id,
TARGET.reward_id=SOURCE.reward_id,
TARGET.reward_type=SOURCE.reward_type,
TARGET.updated_at=SOURCE.updated_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;