MERGE INTO `{{params.project_id}}.raw.levelup_user_campaign_progress_totals` TARGET
USING `{{params.project_id}}.raw.temp_levelup_user_campaign_progress_totals` SOURCE
ON (TARGET.loyalty_id = SOURCE.loyalty_id AND TARGET.id= SOURCE.id)
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.total_order_contribution=SOURCE.total_order_contribution,
TARGET.total_adjustment=SOURCE.total_adjustment,
TARGET.progress_period_type=SOURCE.progress_period_type,
TARGET.current_progress=SOURCE.current_progress,
TARGET.fixed_progress_period_starts_at=SOURCE.fixed_progress_period_starts_at,
TARGET.fixed_progress_period_resets_at=SOURCE.fixed_progress_period_resets_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;