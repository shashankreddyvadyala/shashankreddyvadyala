DECLARE max_cust_per_device INT64;
DECLARE levenshtein_threshold NUMERIC;
DECLARE ruleset1_toggle BOOLEAN;
DECLARE ruleset2_toggle BOOLEAN;
DECLARE ruleset3_toggle BOOLEAN;
DECLARE ruleset4_toggle BOOLEAN;
DECLARE ruleset5_toggle BOOLEAN;
DECLARE ruleset6_toggle BOOLEAN;
DECLARE ruleset7_toggle BOOLEAN;
DECLARE TTL INT64;

-- Product Owner Defined Variables
SET max_cust_per_device = 20; -- devices that are shared by more than this number of customers will not be considered for matching purposes.
SET levenshtein_threshold = 0.4; -- levenshtein string comparisons must be at or lower than this threshold for matching purposes
SET ruleset1_toggle = true;
SET ruleset2_toggle = true;
SET ruleset3_toggle = true;
SET ruleset4_toggle = true;
SET ruleset5_toggle = true;
SET ruleset6_toggle = true;
SET ruleset7_toggle = true;

-- Program initialization variable - do not change.
SET TTL = 0;

-----

TRUNCATE TABLE `{{params.project_id}}.raw.temp_idr_customer`;

INSERT INTO `{{params.project_id}}.raw.temp_idr_customer`
SELECT
DGTL_CUST_ID,
TRIM(LOWER(REGEXP_REPLACE(FIRST_NAME,r'[^a-zA-Z]',''))) as FN_cleaned,
TRIM(LOWER(REGEXP_REPLACE(LAST_NAME,r'[^a-zA-Z]',''))) as LN_cleaned,
FIRST_NAME, 
LAST_NAME,
EMAIL,
SUBSTRING(regexp_replace(upper(trim(EMAIL)), '[^A-Z@.]', ''), 0, instr(regexp_replace(upper(trim(EMAIL)), '[^A-Z@.]', ''),'@')-1) as EMAIL_REGEX,
SUBSTRING(upper(trim(EMAIL)), 0, instr(upper(trim(EMAIL)),'@')-1) as EMAIL_SUBSTRING,
EXTRACT(MONTH FROM BIRTH_DATE) AS BIRTH_MONTH,
EXTRACT(DAY FROM BIRTH_DATE) AS BIRTH_DAY,
POSTAL_CODE,
CC_POSTAL_CODES,
FAVORITE_LOCATION,
VISITED_SITE_NUMS,
array_concat(device_idfa, device_idfv) as DEVICE_ARRAY
FROM `{{params.project_id}}.curated.t_fact_unified_customer`;

-----

TRUNCATE TABLE `{{params.project_id}}.raw.temp_idr_cust_dev_match`; 
INSERT INTO `{{params.project_id}}.raw.temp_idr_cust_dev_match`
SELECT DISTINCT
a.dgtl_cust_id as dgtl_cust_id_a,
b.dgtl_cust_id as dgtl_cust_id_b
FROM (      SELECT dgtl_cust_id, device_token
            FROM `{{params.project_id}}.raw.temp_idr_customer`
            LEFT OUTER JOIN UNNEST(device_array) as device_token
) a
INNER JOIN (SELECT dgtl_cust_id, device_token
            FROM `{{params.project_id}}.raw.temp_idr_customer`
            LEFT OUTER JOIN UNNEST(device_array) as device_token
) b                    
  ON  a.device_token = b.device_token
INNER JOIN (SELECT device_token
            FROM `{{params.project_id}}.raw.temp_idr_customer`
            LEFT OUTER JOIN UNNEST(device_array) as device_token
            WHERE device_token is not null
            GROUP BY device_token
            HAVING count(distinct concat(upper(trim(first_name)), upper(trim(last_name)), ifnull(upper(trim(postal_code)),'0'))) <= max_cust_per_device
) c
  ON b.device_token = c.device_token
WHERE a.dgtl_cust_id <> b.dgtl_cust_id;

-----

TRUNCATE TABLE `{{params.project_id}}.curated.t_fact_dgtl_cust_link`;

INSERT INTO `{{params.project_id}}.curated.t_fact_dgtl_cust_link`
WITH results AS (
      SELECT
      a.DGTL_CUST_ID as cid,
      r1.link as r1_link,
      r2.link as r2_link,
      r3.link as r3_link,
      r4.link as r4_link,
      r5.link as r5_link,
      r6.link as r6_link,
      r7.link as r7_link,
      greatest(a.DGTL_CUST_ID,
               ifnull(r1.link,0),
               ifnull(r2.link,0),
               ifnull(r3.link,0),
               ifnull(r4.link,0),
               ifnull(r5.link,0),
               ifnull(r6.link,0),
               ifnull(r7.link,0)
      ) as parent_link
      FROM `{{params.project_id}}.raw.temp_idr_customer` a
      LEFT JOIN
      ( 
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) b                    
              ON  a.FN_cleaned = b.FN_cleaned
              AND a.LN_cleaned = b.LN_cleaned
            WHERE ruleset1_toggle = true
            AND a.POSTAL_CODE = b.POSTAL_CODE
            AND    (
                        (a.FAVORITE_LOCATION = b.FAVORITE_LOCATION AND LENGTH(a.FAVORITE_LOCATION) > 1)
                    OR  (a.BIRTH_MONTH = b.BIRTH_MONTH AND a.BIRTH_DAY = b.BIRTH_DAY AND (a.BIRTH_MONTH + b.BIRTH_DAY <> 2))
                    OR  (a.email_regex = b.email_regex AND length(a.email_regex) > 2)
                    OR  (a.email_substring = b.email_substring)
            )
            GROUP BY a.DGTL_CUST_ID           
      ) as r1
      ON a.DGTL_CUST_ID = r1.dgtl_cust_id
      LEFT JOIN
      (
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
                        LEFT OUTER JOIN UNNEST(cc_postal_codes) as cc_postal_code
            ) b                    
              ON  a.FN_cleaned = b.FN_cleaned
              AND a.LN_cleaned = b.LN_cleaned
            WHERE ruleset2_toggle = true
            AND a.postal_code = b.cc_postal_code
            AND    (
                        (a.FAVORITE_LOCATION = b.FAVORITE_LOCATION AND LENGTH(a.FAVORITE_LOCATION) > 1)
                    OR  (a.BIRTH_MONTH = b.BIRTH_MONTH AND a.BIRTH_DAY = b.BIRTH_DAY AND (a.BIRTH_MONTH + b.BIRTH_DAY <> 2))
                    OR  (a.email_regex = b.email_regex AND length(a.email_regex) > 2)
                    OR  (a.email_substring = b.email_substring)
            )
            GROUP BY a.DGTL_CUST_ID
      ) as r2
      ON a.DGTL_CUST_ID = r2.dgtl_cust_id
      LEFT JOIN
      (
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
                        LEFT OUTER JOIN UNNEST(visited_site_nums) as visited_site_num
            ) b                    
              ON  a.FN_cleaned = b.FN_cleaned
              AND a.LN_cleaned = b.LN_cleaned
            WHERE ruleset3_toggle = true
            AND a.POSTAL_CODE = b.POSTAL_CODE
            AND SAFE_CAST(a.favorite_location AS INT64) = b.visited_site_num
            GROUP BY a.DGTL_CUST_ID
      ) as r3
      ON a.DGTL_CUST_ID = r3.dgtl_cust_id
      LEFT JOIN
      (
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
                        LEFT OUTER JOIN UNNEST(cc_postal_codes) as cc_postal_code
                        LEFT OUTER JOIN UNNEST(visited_site_nums) as visited_site_num
            ) b                    
              ON  a.FN_cleaned = b.FN_cleaned
              AND a.LN_cleaned = b.LN_cleaned
            WHERE ruleset4_toggle = true
            AND a.postal_code = b.cc_postal_code
            AND SAFE_CAST(a.favorite_location AS INT64) = b.visited_site_num
            GROUP BY a.DGTL_CUST_ID
      ) as r4
      ON a.DGTL_CUST_ID = r4.dgtl_cust_id
      LEFT JOIN
      (
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer` customer
            ) a
            INNER JOIN `{{params.project_id}}.raw.temp_idr_cust_dev_match` tie
              ON a.dgtl_cust_id = tie.dgtl_cust_id_a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) b                    
              ON b.dgtl_cust_id = tie.dgtl_cust_id_b
            WHERE ruleset5_toggle = true
            AND (
                        (a.BIRTH_MONTH = b.BIRTH_MONTH AND a.BIRTH_DAY = b.BIRTH_DAY)
                    OR  (a.email_regex = b.email_regex AND length(a.email_regex) > 2)
                    OR  (a.email_substring = b.email_substring)
            )
            GROUP BY a.DGTL_CUST_ID
      ) as r5
      ON a.DGTL_CUST_ID = r5.dgtl_cust_id
      LEFT JOIN
      (
            SELECT
            a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer` customer
            ) a
            INNER JOIN `{{params.project_id}}.raw.temp_idr_cust_dev_match` tie
              ON a.dgtl_cust_id = tie.dgtl_cust_id_a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) b                    
              ON b.dgtl_cust_id = tie.dgtl_cust_id_b
            WHERE ruleset6_toggle = true
            AND   SUBSTRING(a.FIRST_NAME,0,1) = SUBSTRING(b.FIRST_NAME,0,1) AND SUBSTRING(a.LAST_NAME,0,1) = SUBSTRING(b.LAST_NAME,0,1)
            AND   (fhoffa.x.levenshtein(a.FIRST_NAME, b.FIRST_NAME) / greatest(length(a.FIRST_NAME),length(b.FIRST_NAME)) <= levenshtein_threshold)
            AND   (fhoffa.x.levenshtein(a.LAST_NAME, b.LAST_NAME)   / greatest(length(a.LAST_NAME),length(b.LAST_NAME))   <= levenshtein_threshold)
            GROUP BY a.DGTL_CUST_ID
      ) as r6
      ON a.DGTL_CUST_ID = r6.dgtl_cust_id
      LEFT JOIN
      (
            SELECT a.DGTL_CUST_ID as dgtl_cust_id,
            max(ifnull(b.DGTL_CUST_ID,a.DGTL_CUST_ID)) as link
            FROM (      SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer` customer
            ) a
            INNER JOIN `{{params.project_id}}.raw.temp_idr_cust_dev_match` tie
              ON a.dgtl_cust_id = tie.dgtl_cust_id_a
            INNER JOIN (SELECT *
                        FROM `{{params.project_id}}.raw.temp_idr_customer`
            ) b                    
              ON b.dgtl_cust_id = tie.dgtl_cust_id_b
            WHERE ruleset7_toggle = true
            AND (
                      (SOUNDEX(a.FN_cleaned)=SOUNDEX(b.FN_cleaned) AND SOUNDEX(a.LN_cleaned)=SOUNDEX(b.LN_cleaned))
                   OR (SOUNDEX(a.email_regex) = SOUNDEX(b.email_regex) AND length(a.email_regex) > 2)
                   OR (SOUNDEX(a.email_substring) = SOUNDEX(b.email_substring))
            )       
            GROUP BY a.DGTL_CUST_ID
      ) as r7
      ON a.DGTL_CUST_ID = r7.dgtl_cust_id
)
SELECT
  r.cid,
  max(greatest( ifnull(t1.parent_link,0),
                ifnull(t2.parent_link,0),
                ifnull(t3.parent_link,0),
                ifnull(t4.parent_link,0),
                ifnull(t5.parent_link,0),
                ifnull(t6.parent_link,0),
                ifnull(t7.parent_link,0),
                r.parent_link)) as uid
FROM results as r
LEFT JOIN results as t1
ON  r.parent_link = t1.r1_link
AND t1.r1_link < t1.parent_link
LEFT JOIN results as t2
ON  r.parent_link = t2.r2_link
AND t2.r2_link < t2.parent_link
LEFT JOIN results as t3
ON  r.parent_link = t3.r3_link
AND t3.r3_link < t3.parent_link
LEFT JOIN results as t4
ON  r.parent_link = t4.r4_link
AND t4.r4_link < t4.parent_link
LEFT JOIN results as t5
ON  r.parent_link = t5.r5_link
AND t5.r5_link < t5.parent_link
LEFT JOIN results as t6
ON  r.parent_link = t6.r6_link
AND t6.r6_link < t6.parent_link
LEFT JOIN results as t7
ON  r.parent_link = t7.r7_link
AND t7.r7_link < t7.parent_link
GROUP BY r.cid;

REPEAT

  SET TTL = TTL + 1;

  IF
      (SELECT
      count(*)
      FROM `{{params.project_id}}.curated.t_fact_dgtl_cust_link` a
      INNER JOIN `{{params.project_id}}.curated.t_fact_dgtl_cust_link` b
      ON a.dgtl_cust_link_id = b.dgtl_cust_id
      AND a.dgtl_cust_id <> b.dgtl_cust_id
      AND a.dgtl_cust_link_id <> b.dgtl_cust_link_id) = 0
          THEN BREAK;
  END IF;

  MERGE INTO `{{params.project_id}}.curated.t_fact_dgtl_cust_link` b
  USING (
    SELECT
    a.dgtl_cust_id,
    greatest(a.dgtl_cust_id, ifnull(b.dgtl_cust_link_id,0)) as dgtl_cust_link_id
    FROM `{{params.project_id}}.curated.t_fact_dgtl_cust_link` a
    INNER JOIN `{{params.project_id}}.curated.t_fact_dgtl_cust_link` b
    ON a.dgtl_cust_link_id = b.dgtl_cust_id
    AND a.dgtl_cust_id <> b.dgtl_cust_id
    AND a.dgtl_cust_link_id <> b.dgtl_cust_link_id
  ) t
  ON b.dgtl_cust_id = t.dgtl_cust_id
  WHEN MATCHED THEN
    UPDATE SET b.dgtl_cust_link_id = t.dgtl_cust_link_id;

  SELECT TTL;

  UNTIL TTL > 10

END REPEAT;