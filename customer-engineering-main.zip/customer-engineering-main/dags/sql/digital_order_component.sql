MERGE INTO `{{params.project_id}}.raw.order_component` TARGET
USING `{{params.project_id}}.raw.temp_order_component` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.product_seq=SOURCE.product_seq
AND TARGET.component_seq=SOURCE.component_seq

)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_action_id=SOURCE.aloha_action_id,
TARGET.aloha_modifier_group_id=SOURCE.aloha_modifier_group_id,
TARGET.aloha_modifier_id=SOURCE.aloha_modifier_id,
TARGET.aloha_nam=SOURCE.aloha_nam,
TARGET.aloha_pos_group_id=SOURCE.aloha_pos_group_id,
TARGET.aloha_pos_item_id=SOURCE.aloha_pos_item_id,
TARGET.comp_id=SOURCE.comp_id,
TARGET.component_seq=SOURCE.component_seq,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.extended_prc=SOURCE.extended_prc,
TARGET.product_seq=SOURCE.product_seq,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.unit_prc=SOURCE.unit_prc,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.create_tms=SOURCE.create_tms
WHEN NOT MATCHED THEN
INSERT ROW;