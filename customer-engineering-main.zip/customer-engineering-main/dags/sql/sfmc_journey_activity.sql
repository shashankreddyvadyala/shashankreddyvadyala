MERGE INTO `{{params.project_id}}.raw.SFMC_JourneyActivity` TARGET
USING `{{params.project_id}}.raw.temp_SFMC_JourneyActivity` SOURCE
ON TARGET.ActivityID=SOURCE.ActivityID AND TARGET.VersionID=SOURCE.VersionID
WHEN MATCHED THEN
UPDATE SET
TARGET.ActivityExternalKey=SOURCE.ActivityExternalKey,
TARGET.ActivityID=SOURCE.ActivityID,
TARGET.ActivityName=SOURCE.ActivityName,
TARGET.ActivityType=SOURCE.ActivityType,
TARGET.JourneyActivityObjectID=SOURCE.JourneyActivityObjectID,
TARGET.VersionID=SOURCE.VersionID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;