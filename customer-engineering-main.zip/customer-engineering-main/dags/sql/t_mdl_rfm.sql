--deleting current day data from `{{params.project_id}}.curated.t_mdl_rfm`
DELETE 
FROM `{{params.project_id}}.curated.t_mdl_rfm`
WHERE 
CREATED_DATE = CURRENT_DATE();

INSERT INTO `{{params.project_id}}.curated.t_mdl_rfm`
SELECT
  CUSTOMER_ID,
  COUNT(BUSINESS_DATE) - 1 AS FREQUENCY,
  DATE_DIFF( MAX(BUSINESS_DATE), MIN(BUSINESS_DATE),DAY) AS RECENCY,
  AVG(NET_SALES_AMT) AS MONETARY_VALUE,
  DATE_DIFF( CURRENT_DATE(), MIN(BUSINESS_DATE),DAY) AS T,
  CURRENT_DATE() AS CREATED_DATE

FROM ( --Adding another subquery to roll up netsales amt on the basis of cutomer_id and business_date 
  SELECT
    CUSTOMER_ID,
    BUSINESS_DATE,
    SUM(NET_SALES_AMT) AS NET_SALES_AMT
  FROM
    `{{params.project_id}}.curated.t_fact_customer_order_trans`
  WHERE BUSINESS_DATE BETWEEN date_add(cast(CURRENT_DATE() AS date), interval -24 month) AND CURRENT_DATE()
  GROUP BY
    CUSTOMER_ID,
    BUSINESS_DATE)
GROUP BY
  CUSTOMER_ID