MERGE INTO `{{params.project_id}}.raw.levelup_campaigns` TARGET
USING `{{params.project_id}}.raw.temp_levelup_campaigns` SOURCE
ON TARGET.id = SOURCE.id 
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.opens_at=SOURCE.opens_at,
TARGET.closes_at=SOURCE.closes_at,
TARGET.value_amount=SOURCE.value_amount,
TARGET.campaign_type=SOURCE.campaign_type,
TARGET.custom_name=SOURCE.custom_name,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;
