MERGE INTO `{{params.project_id}}.raw.levelup_orders` TARGET
USING `{{params.project_id}}.raw.temp_levelup_orders` SOURCE
ON (TARGET.order_id = SOURCE.order_id AND TARGET.created_at = SOURCE.created_at)
WHEN MATCHED THEN
UPDATE SET
TARGET.order_id=SOURCE.order_id,
TARGET.created_at=SOURCE.created_at,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.food_and_beverage=SOURCE.food_and_beverage,
TARGET.tax_amount=SOURCE.tax_amount,
TARGET.tip=SOURCE.tip,
TARGET.location_id=SOURCE.location_id,
TARGET.street_address=SOURCE.street_address,
TARGET.order_source=SOURCE.order_source,
TARGET.reward_credit_redeemed=SOURCE.reward_credit_redeemed,
TARGET.channel=SOURCE.channel,
TARGET.business_order_id=SOURCE.business_order_id,
TARGET.order_uuid=SOURCE.order_uuid,
TARGET.state=SOURCE.state,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;