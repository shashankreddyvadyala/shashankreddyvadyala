MERGE INTO `{{params.project_id}}.raw.order_product` TARGET
USING `{{params.project_id}}.raw.temp_order_product` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.product_seq=SOURCE.product_seq

)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_menu_item_id=SOURCE.aloha_menu_item_id,
TARGET.aloha_nam=SOURCE.aloha_nam,
TARGET.aloha_pos_item_id=SOURCE.aloha_pos_item_id,
TARGET.aloha_sales_item_id=SOURCE.aloha_sales_item_id,
TARGET.brierley_member_reward_id=SOURCE.brierley_member_reward_id,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.extended_prc=SOURCE.extended_prc,
TARGET.message=SOURCE.message,
TARGET.prod_id=SOURCE.prod_id,
TARGET.product_seq=SOURCE.product_seq,
TARGET.promo_cod=SOURCE.promo_cod,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.reward_pos_item_id=SOURCE.reward_pos_item_id,
TARGET.unit_prc=SOURCE.unit_prc,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.create_tms=SOURCE.create_tms

WHEN NOT MATCHED THEN
INSERT ROW;