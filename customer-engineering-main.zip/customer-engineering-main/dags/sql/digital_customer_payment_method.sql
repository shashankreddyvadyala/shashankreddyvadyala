MERGE INTO `{{params.project_id}}.raw.customer_payment_method` TARGET
USING `{{params.project_id}}.raw.temp_customer_payment_method` SOURCE
ON TARGET.customer_id = SOURCE.customer_id and TARGET.payment_method_id = SOURCE.payment_method_id
WHEN MATCHED THEN
UPDATE SET
TARGET.account_cod=SOURCE.account_cod,
TARGET.account_nam=SOURCE.account_nam,
TARGET.account_num=SOURCE.account_num,
TARGET.address_id=SOURCE.address_id,
TARGET.aloha_account_id=SOURCE.aloha_account_id,
TARGET.collect_cvv_flg=SOURCE.collect_cvv_flg,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.expire_dat=SOURCE.expire_dat,
TARGET.lp_token_id=SOURCE.lp_token_id,
TARGET.maint_source_cod=SOURCE.maint_source_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.payment_method_id=SOURCE.payment_method_id,
TARGET.status_ind=SOURCE.status_ind,
TARGET.vi_tid=SOURCE.vi_tid,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;