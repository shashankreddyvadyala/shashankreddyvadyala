MERGE INTO `{{params.project_id}}.raw.SFMC_MobilePushTrackingDetails` TARGET
USING `{{params.project_id}}.raw.temp_SFMC_MobilePushTrackingDetails` SOURCE
ON TARGET.ContactKey=SOURCE.ContactKey AND TARGET.PushJobId=SOURCE.PushJobId AND TARGET.DateTimeSend=SOURCE.DateTimeSend
WHEN MATCHED THEN
UPDATE SET
TARGET.AndroidMediaUrl=SOURCE.AndroidMediaUrl,
TARGET.AppName=SOURCE.AppName,
TARGET.Campaigns=SOURCE.Campaigns,
TARGET.ContactKey=SOURCE.ContactKey,
TARGET.DateTimeSend=SOURCE.DateTimeSend,
TARGET.DeviceId=SOURCE.DeviceId,
TARGET.Format=SOURCE.Format,
TARGET.GeofenceName=SOURCE.GeofenceName,
TARGET.InboxMessageDownloaded=SOURCE.InboxMessageDownloaded,
TARGET.IosMediaUrl=SOURCE.IosMediaUrl,
TARGET.MediaAlt=SOURCE.MediaAlt,
TARGET.MessageContent=SOURCE.MessageContent,
TARGET.MessageID=SOURCE.MessageID,
TARGET.MessageName=SOURCE.MessageName,
TARGET.MessageOpened=SOURCE.MessageOpened,
TARGET.OpenDate=SOURCE.OpenDate,
TARGET.PageName=SOURCE.PageName,
TARGET.Platform=SOURCE.Platform,
TARGET.PushJobId=SOURCE.PushJobId,
TARGET.RequestId=SOURCE.RequestId,
TARGET.ServiceResponse=SOURCE.ServiceResponse,
TARGET.Status=SOURCE.Status,
TARGET.SystemToken=SOURCE.SystemToken,
TARGET.Template=SOURCE.Template,
TARGET.TimeInApp=SOURCE.TimeInApp,
TARGET.DateTimeSendFull=SOURCE.DateTimeSendFull,
TARGET.OpenDateFull=SOURCE.OpenDateFull,
TARGET.TimeInAppFull=SOURCE.TimeInAppFull
WHEN NOT MATCHED THEN
INSERT ROW;