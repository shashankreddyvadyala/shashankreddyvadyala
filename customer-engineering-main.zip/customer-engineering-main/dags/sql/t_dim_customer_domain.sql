truncate table  `{{params.project_id}}.curated.t_dim_customer_domain`;
insert into `{{params.project_id}}.curated.t_dim_customer_domain`
SELECT customer.customer_id as DGTL_CUST_ID,
customer.sf_contact_id as SF_CONTACT_ID,
customer.vendor_id as SF_VENDOR_ID,
user.loyalty_id as LVL_UP_LOYALTY_ID,
UPPER(TRIM(customer.first_nam)) as FIRST_NAME,
UPPER(TRIM(customer.last_nam)) as LAST_NAME,
CAST(customer.birth_dat as timestamp) as BIRTH_DATE,
customer.gender_ind as GENDER,
customer.lang_cod as LANG_CODE,
customer.cntry_cod as COUNTRY_CODE,
postal.LATITUDE  as LATITUDE,
postal.LONGITUDE as LONGITUDE ,
null as CC_POSTAL_CODES,
null as  DELIVERY_ADDRESSES,
null as DELIVERY_COORDS,
customer.currency_cod as CURRENCY_CODE,
customer.email_adr as EMAIL,
customer.opt_in_flg  as EMAIL_OPT_IN,
replace(UPPER(CAST(customer.postal_cod AS STRING)),' ','') as POSTAL_CODE,
postal.state as STATE,
customer.va_eligibility_flg as VETERAN_FLAG,
user.phone as PHONE,
user.favorite_location as FAVORITE_LOCATION,
CAST(customer.create_tms AS TIMESTAMP) as DGTL_CUST_CREATE_TMS,
user.registered_at as LVL_UP_CREATE_TMS,
CAST(user.first_order_created_at AS STRING) as LVL_UP_FIRST_VISIT_TMS,
user.number_of_visits as LVL_UP_NUM_VISITS,
user_acct.current_progress as LOY_PT_BALANCE,
user_acct.total_order_contribution as LOY_PT_TOT_EARNED
FROM `{{params.project_id}}.raw.customer` customer 
LEFT JOIN `{{params.project_id}}.raw.LUIS_customer` luis
ON customer.customer_id = CAST(luis.WENDYS_CUSTOMER_ID AS INTEGER)
LEFT  JOIN (  SELECT
              loyalty_id,					
              max(phone) as phone,	
              max(registered_at) as registered_at,					
              max(favorite_location) as favorite_location,		
              max(first_order_created_at) as first_order_created_at,				
              max(number_of_visits) as number_of_visits
              FROM `{{params.project_id}}.raw.levelup_user`
              GROUP BY loyalty_id
) as user
ON user.loyalty_id = CAST(luis.LEVELUP_CUSTOMER_ID AS INTEGER)
LEFT JOIN `{{params.project_id}}.raw.levelup_user_campaign_progress_totals` user_acct
ON user.loyalty_id = user_acct.loyalty_id
AND user_acct.campaign_id = 56171 
LEFT JOIN `{{params.project_id}}.curated.t_dim_zipcodes` postal 
ON  replace(UPPER(CAST(customer.postal_cod AS STRING)),' ','')= replace(upper(CAST(postal.zipcode AS STRING)),' ','')
WHERE customer.status_ind in ('A', 'P')
AND customer.create_source_cod <> 'QA_AUTO'
AND UPPER(customer.email_adr) not like 'GUEST@GUEST_%';