-- DECLARE VARIABLES
DECLARE fromdate DATE;

-- STEP 1: SET VARIABLES
SET fromdate     = (SELECT -- set fromdate to the last batch date as recorded in the t_dim_aci_token table
                        ifnull(
                                DATE(max(last_used)),
                                '1970-01-01' -- the historical load will run from 1970 to bring in all data
                        )
                    FROM `{{params.project_id}}.curated.t_dim_aci_token`
);

-- STEP 2: MERGE DATA INTO t_dim_aci_token
MERGE INTO `{{params.project_id}}.curated.t_dim_aci_token` map
USING (
  SELECT
  ord.customer_id,
  aci.Token as token,
  max(ord.create_tms) as last_used
  FROM `{{params.project_id}}.raw.aci` aci
  INNER JOIN `{{params.project_id}}.raw.order` ord
  ON ord.order_id = CAST(aci.User_Field_1 as INTEGER)
  WHERE aci.Journal_Message = 'Approved'
  AND ord.order_status_cod = 'PREPARED'
  AND DATE(ord.create_tms) >= fromdate -- filter only the recent records using the fromdate variable and using the partition on the customer_order table
  AND DATE(aci.Store_Timestamp) >= (fromdate-1) --filter only the recent records using the fromdate variable (going back an extra day since store timestamp is local, not UTC) and using the partition on the aci table
  GROUP BY ord.customer_id, aci.Token
) aci
ON  map.customer_id = aci.customer_id
AND map.token = aci.token
WHEN MATCHED THEN
  UPDATE SET map.last_used = aci.last_used
WHEN NOT MATCHED THEN
  INSERT ROW;