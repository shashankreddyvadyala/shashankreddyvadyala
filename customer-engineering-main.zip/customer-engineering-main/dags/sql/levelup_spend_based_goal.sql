MERGE INTO `{{params.project_id}}.raw.levelup_spend_based_goal` TARGET
USING `{{params.project_id}}.raw.temp_levelup_spend_based_goal` SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.required_spend_amount=SOURCE.required_spend_amount,
TARGET.concept_modifier=SOURCE.concept_modifier,
TARGET.concept_type=SOURCE.concept_type,
TARGET.description=SOURCE.description,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
 TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;