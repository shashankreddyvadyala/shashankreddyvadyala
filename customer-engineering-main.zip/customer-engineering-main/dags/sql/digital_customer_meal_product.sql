MERGE INTO `{{params.project_id}}.raw.customer_meal_product` TARGET
USING `{{params.project_id}}.raw.temp_customer_meal_product` SOURCE
ON (TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID and TARGET.meal_nam = SOURCE.meal_nam  
and TARGET.slot_num = SOURCE.slot_num and TARGET.prod_id = SOURCE.prod_id)
WHEN MATCHED THEN
UPDATE SET

TARGET.customer_id=SOURCE.customer_id,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.prod_id=SOURCE.prod_id,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.set_num=SOURCE.set_num,
TARGET.slot_num=SOURCE.slot_num,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.maint_tms=SOURCE.maint_tms

WHEN NOT MATCHED THEN
INSERT ROW;