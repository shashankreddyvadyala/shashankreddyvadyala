TRUNCATE TABLE `{{params.project_id}}.gold.t_fact_unified_customer`;

INSERT INTO `{{params.project_id}}.gold.t_fact_unified_customer`
SELECT * Except(FIRST_NAME,	LAST_NAME, BIRTH_DATE,EMAIL,PHONE, 
                CC_POSTAL_CODES, CC_TOKENS, DEVICE_IDFA, DEVICE_IDFV,
                DELIVERY_ADDRESSES, DELIVERY_COORDS) FROM `{{params.project_id}}.curated.t_fact_unified_customer`