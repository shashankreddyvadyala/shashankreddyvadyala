MERGE INTO `{{params.project_id}}.raw.SFMC_Jobs` TARGET
USING `{{params.project_id}}.raw.temp_SFMC_Jobs` SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.DeliveredTime=SOURCE.DeliveredTime
WHEN MATCHED THEN
UPDATE SET
TARGET.CreatedDate=SOURCE.CreatedDate,
TARGET.DeduplicateByEmail=SOURCE.DeduplicateByEmail,
TARGET.DeliveredTime=SOURCE.DeliveredTime,
TARGET.DynamicEmailSubject=SOURCE.DynamicEmailSubject,
TARGET.EmailID=SOURCE.EmailID,
TARGET.EmailName=SOURCE.EmailName,
TARGET.EmailSendDefinition=SOURCE.EmailSendDefinition,
TARGET.EmailSubject=SOURCE.EmailSubject,
TARGET.EventID=SOURCE.EventID,
TARGET.FromEmail=SOURCE.FromEmail,
TARGET.FromName=SOURCE.FromName,
TARGET.IPAddress=SOURCE.IPAddress,
TARGET.IsMultipart=SOURCE.IsMultipart,
TARGET.IsWrapped=SOURCE.IsWrapped,
TARGET.JobID=SOURCE.JobID,
TARGET.JobStatus=SOURCE.JobStatus,
TARGET.JobType=SOURCE.JobType,
TARGET.ModifiedBy=SOURCE.ModifiedBy,
TARGET.ModifiedDate=SOURCE.ModifiedDate,
TARGET.OriginalSchedTime=SOURCE.OriginalSchedTime,
TARGET.PickupTime=SOURCE.PickupTime,
TARGET.ResolveLinksWithCurrentData=SOURCE.ResolveLinksWithCurrentData,
TARGET.SalesForceErrorSubscriberCount=SOURCE.SalesForceErrorSubscriberCount,
TARGET.SalesForceTotalSubscriberCount=SOURCE.SalesForceTotalSubscriberCount,
TARGET.SchedTime=SOURCE.SchedTime,
TARGET.SendClassification=SOURCE.SendClassification,
TARGET.SendClassificationType=SOURCE.SendClassificationType,
TARGET.SendType=SOURCE.SendType,
TARGET.SuppressTracking=SOURCE.SuppressTracking,
TARGET.TestEmailAddr=SOURCE.TestEmailAddr,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.CreatedFullDate=SOURCE.CreatedFullDate,
TARGET.DeliveredFullTime=SOURCE.DeliveredFullTime,
TARGET.ModifiedFullDate=SOURCE.ModifiedFullDate,
TARGET.OriginalFullSchedTime=SOURCE.OriginalFullSchedTime,
TARGET.PickupFullTime=SOURCE.PickupFullTime,
TARGET.SchedFullTime=SOURCE.SchedFullTime

WHEN NOT MATCHED THEN
INSERT ROW;