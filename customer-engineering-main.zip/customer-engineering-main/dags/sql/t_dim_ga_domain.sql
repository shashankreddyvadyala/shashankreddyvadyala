-- STEP 3: After each incremental load to update the persistent curated table, the following query can be used to aggregate the data to the customer level and update the customer golden record with the device_idfa and device_idfv attributes
-- After each incremental load to update the persistent curated table
TRUNCATE TABLE `{{params.project_id}}.curated.t_dim_ga_domain`;


INSERT INTO `{{params.project_id}}.curated.t_dim_ga_domain`
SELECT id, 
if(length(id) = 18, "sf_contact_id", "vendor_id") as id_type,
array_agg(device_idfa ignore nulls) as device_idfa,
array_agg(device_idfv ignore nulls) as device_idfv
FROM `{{params.project_id}}.curated.t_dim_ga_device`
GROUP BY id, if(length(id) = 18, "sf_contact_id", "vendor_id");