-- DECLARE VARIABLES
DECLARE fromdate DATE;

-- STEP 1: SET VARIABLES
SET fromdate     = (SELECT -- set fromdate to the last batch date as recorded in the t_dim_customer_address table
                        ifnull(
                                max(record_date),
                                '1970-01-01' -- the historical load will run from 1970 to bring in all data
                        )
                    FROM `{{params.project_id}}.curated.t_dim_customer_address`
);

-- STEP 2: MERGE DATA INTO t_dim_customer_address
MERGE INTO `{{params.project_id}}.curated.t_dim_customer_address` p
USING (
    SELECT DISTINCT customer_id, -- List of unique addresses by customer
    address_typ,
    UPPER(TRIM(address1_txt)) as address1_txt,
    UPPER(TRIM(address2_txt)) as address2_txt,
    UPPER(TRIM(city_txt)) as city_txt,
    UPPER(TRIM(state_cod)) as state_cod,
    UPPER(REPLACE(postal_cod," ","")) as postal_cod,
    UPPER(TRIM(cntry_cod)) as cntry_cod,
    latitude_num,
    longitude_num,
    DATE(maint_tms) as record_date
    FROM `{{params.project_id}}.raw.customer_address`
    WHERE create_source_cod <> 'CSO' 
    AND postal_cod <> '~~INACTIVE' 
    AND DATE(maint_tms) >= fromdate
) t
ON p.customer_id = t.customer_id
AND p.address_typ = t.address_typ
AND IFNULL(p.address1_txt,'') = IFNULL(t.address1_txt,'')
AND IFNULL(p.address2_txt,'') = IFNULL(t.address2_txt,'')
AND IFNULL(p.city_txt,'') = IFNULL(t.city_txt,'')
AND IFNULL(p.state_cod,'') = IFNULL(t.state_cod,'')
AND IFNULL(p.postal_cod,'') = IFNULL(t.postal_cod,'')
AND IFNULL(p.cntry_cod,'') = IFNULL(t.cntry_cod,'')
AND IFNULL(p.latitude_num,0) = IFNULL(t.latitude_num,0)
AND IFNULL(p.longitude_num,0) = IFNULL(t.longitude_num,0)
WHEN NOT MATCHED THEN
    INSERT ROW;

--STEP 3: Merge into curated.t_dim_customer_domain
--NOTE: This merge should happen after the t_dim_customer_domain table has been initially created for the day because we will do update only and not insert records.

MERGE INTO `{{params.project_id}}.curated.t_dim_customer_domain` domain
USING (
    SELECT customer_id,
    array_agg(
                if(address_typ = 'CREDIT_CARD',
                    postal_cod,
                    null
                )
            ignore nulls
    ) as CC_POSTAL_CODES,
    array_agg(
                if(address_typ = 'DELIVERY',
                    concat(
                        if(address1_txt is not null,
                                concat(address1_txt, if(address2_txt is not null, concat(" ", address2_txt, ", "), ", ")),
                                null
                        ),
                        if(city_txt is not null, concat(city_txt, ", "), ""),
                        concat(state_cod, " "),
                        concat(postal_cod, ", "),
                        cntry_cod
                    ),
                    null
                )
            ignore nulls
    ) as DELIVERY_ADDRESSES,
    array_agg(
                if(latitude_num is not null,
                    STRUCT(latitude_num as latitude, longitude_num as longitude),
                    null
                )
            ignore nulls
    ) as DELIVERY_COORDS
    FROM `{{params.project_id}}.curated.t_dim_customer_address`
    GROUP BY customer_id
) address
ON domain.DGTL_CUST_ID = address.customer_id
WHEN MATCHED THEN
    UPDATE SET
        domain.CC_POSTAL_CODES = address.CC_POSTAL_CODES,
        domain.DELIVERY_ADDRESSES = address.DELIVERY_ADDRESSES,
        domain.DELIVERY_COORDS = address.DELIVERY_COORDS;
