MERGE INTO `{{params.project_id}}.raw.customer_meal_component` TARGET
USING `{{params.project_id}}.raw.temp_customer_meal_component` SOURCE
ON (TARGET.customer_id = SOURCE.customer_id AND TARGET.meal_nam = SOURCE.meal_nam AND TARGET.slot_num=SOURCE.slot_num AND TARGET.prod_id=SOURCE.prod_id
AND TARGET.comp_id=SOURCE.comp_id)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_action_id=SOURCE.aloha_action_id,
TARGET.comp_id=SOURCE.comp_id,
TARGET.customer_id=SOURCE.customer_id,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.prod_id=SOURCE.prod_id,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.slot_num=SOURCE.slot_num,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.maint_tms=SOURCE.maint_tms
WHEN NOT MATCHED THEN
INSERT ROW;