MERGE INTO `{{params.project_id}}.raw.SFMC_Open` TARGET
USING `{{params.project_id}}.raw.temp_SFMC_Open` SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.SubscriberKey=SOURCE.SubscriberKey AND TARGET.EventDate=SOURCE.EventDate
WHEN MATCHED THEN
UPDATE SET
TARGET.AccountID=SOURCE.AccountID,
TARGET.BatchID=SOURCE.BatchID,
TARGET.Domain=SOURCE.Domain,
TARGET.EventDate=SOURCE.EventDate,
TARGET.IsUnique=SOURCE.IsUnique,
TARGET.JobID=SOURCE.JobID,
TARGET.ListID=SOURCE.ListID,
TARGET.OYBAccountID=SOURCE.OYBAccountID,
TARGET.SubscriberID=SOURCE.SubscriberID,
TARGET.SubscriberKey=SOURCE.SubscriberKey,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.EventFullDate=SOURCE.EventFullDate

WHEN NOT MATCHED THEN
INSERT ROW;