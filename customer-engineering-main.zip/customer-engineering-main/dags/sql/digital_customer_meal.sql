MERGE INTO `{{params.project_id}}.raw.customer_meal` TARGET
USING `{{params.project_id}}.raw.temp_customer_meal` SOURCE
ON TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID and TARGET.meal_nam = SOURCE.meal_nam 
WHEN MATCHED THEN
UPDATE SET

TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.default_flg=SOURCE.default_flg,
TARGET.favorite_type_cod=SOURCE.favorite_type_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;