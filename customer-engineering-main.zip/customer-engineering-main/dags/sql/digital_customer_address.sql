MERGE INTO `{{params.project_id}}.raw.customer_address` TARGET
USING `{{params.project_id}}.raw.temp_customer_address` SOURCE
ON TARGET.customer_id = SOURCE.customer_id and TARGET.address_id = SOURCE.address_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.address_id=SOURCE.address_id,
TARGET.address_typ=SOURCE.address_typ,
TARGET.address1_txt=SOURCE.address1_txt,
TARGET.address2_txt=SOURCE.address2_txt,
TARGET.city_txt=SOURCE.city_txt,
TARGET.cntry_cod=SOURCE.cntry_cod,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.latitude_num=SOURCE.latitude_num,
TARGET.longitude_num=SOURCE.longitude_num,
TARGET.maint_source_cod=SOURCE.maint_source_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.postal_cod=SOURCE.postal_cod,
TARGET.state_cod=SOURCE.state_cod,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;