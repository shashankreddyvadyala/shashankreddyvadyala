MERGE INTO `{{params.project_id}}.raw.levelup_refunds` TARGET
USING `{{params.project_id}}.raw.temp_levelup_refunds` SOURCE
ON (TARGET.order_id = SOURCE.order_id AND TARGET.refunded_at = SOURCE.refunded_at)
WHEN MATCHED THEN
UPDATE SET
TARGET.order_id=SOURCE.order_id,
TARGET.refunded_at=SOURCE.refunded_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;