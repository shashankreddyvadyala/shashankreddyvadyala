MERGE INTO `{{params.project_id}}.raw.dpvhstcheckinfo` TARGET
USING `{{params.project_id}}.raw.temp_dpvhstcheckinfo` SOURCE
ON (TARGET.dateofbusiness=SOURCE.dateofbusiness and TARGET.distkey=SOURCE.distkey  
and TARGET.uniqueid=SOURCE.uniqueid)
WHEN MATCHED THEN
UPDATE SET

TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.attname=SOURCE.attname,
TARGET.atttext=SOURCE.atttext,
TARGET.checkid=SOURCE.checkid,
TARGET.dateofbusiness=SOURCE.dateofbusiness,
TARGET.datetimestamp=SOURCE.datetimestamp,
TARGET.dim_insight_source_key=SOURCE.dim_insight_source_key,
TARGET.distkey=SOURCE.distkey,
TARGET.fkemployeenumber=SOURCE.fkemployeenumber,
TARGET.fkoccasionid=SOURCE.fkoccasionid,
TARGET.fkstoreid=SOURCE.fkstoreid,
TARGET.importchecksum=SOURCE.importchecksum,
TARGET.last_maint_tms=SOURCE.last_maint_tms,
TARGET.queueid=SOURCE.queueid,
TARGET.tableid=SOURCE.tableid,
TARGET.uniqueid=SOURCE.uniqueid

WHEN NOT MATCHED THEN
INSERT ROW;