MERGE INTO `{{params.project_id}}.raw.order_tender` TARGET
USING `{{params.project_id}}.raw.temp_order_tender` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.tender_seq=SOURCE.tender_seq

)
WHEN MATCHED THEN
UPDATE SET
TARGET.account_cod=SOURCE.account_cod,
TARGET.account_num=SOURCE.account_num,
TARGET.aloha_account_id=SOURCE.aloha_account_id,
TARGET.aloha_tender_id=SOURCE.aloha_tender_id,
TARGET.authorization_num=SOURCE.authorization_num,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.digital_payment_type=SOURCE.digital_payment_type,
TARGET.lp_div_num=SOURCE.lp_div_num,
TARGET.lp_token_id=SOURCE.lp_token_id,
TARGET.mag_device_serial_num=SOURCE.mag_device_serial_num,
TARGET.payment_method_id=SOURCE.payment_method_id,
TARGET.tender_amt=SOURCE.tender_amt,
TARGET.tender_seq=SOURCE.tender_seq,
TARGET.transaction_id=SOURCE.transaction_id,
TARGET.create_tms=SOURCE.create_tms,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;