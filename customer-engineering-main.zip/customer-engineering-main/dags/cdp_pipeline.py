######################################################################### Airflow Dependecies #########################################################################
"""
Airflow dependencies are one of Airflow’s most powerful and popular features. In Airflow, your pipelines are defined as Directed, Acyclic Graphs (DAGs). 
If each task is a node in that graph, then dependencies are the directed edges that determine how you can move through the graph.
"""

################################################################### Module Imports ################################################################################
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryExecuteQueryOperator
from airflow.contrib.hooks.gcp_api_base_hook import GoogleCloudBaseHook
from airflow.utils.task_group import TaskGroup
from datetime import datetime, timedelta
import requests
from airflow.operators.python import PythonOperator
import google.auth
from google.auth.transport.requests import AuthorizedSession
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.models import Variable
import json
import time
import re
import airflow
from airflow.models.baseoperator import chain
from airflow.exceptions import AirflowSkipException

################################################################## Configs ########################################################################################

project_path="/home/airflow/gcs/dags/cdp_c360"

service_account_email=Variable.get('service_account_email')   #Eg: sa-cdp-ai-ml@cdp-dev-bdfa.iam.gserviceaccount.com
ml_model_training_day=Variable.get('ml_model_training_day')
cdp_dag_schedule=Variable.get('cdp_dag_schedule')
poc_email=eval(Variable.get('cdp_poc_email'))
enable_deduplication=eval(Variable.get('cdp_enable_deduplication'))
project_id=service_account_email.split('.')[0].split('@')[1]    

gcp_wen_project_id={'cdp-dev-bdfa':'gcp-wen-analytics-dev-0731','cdp-stg-494a':'gcp-wen-analytics-stg-4115',
                    'cdp-tst-5fba':'gcp-wen-analytics-tst-a5ed','cdp-prd-6370':'gcp-wen-analytics-prd-86d8'}

####### Getting Snaplogic Credentials Info ###############
gcp_hook = GoogleCloudBaseHook(gcp_conn_id="snaplogic")
snaplogic_endpoints=eval(gcp_hook._get_field('keyfile_dict'))

############ Monitor Task Sleep time ###############
sleep_time=int(Variable.get('monitor_sleep_time_seconds'))

################################################################## Dag Configuration  ############################################################################
default_args = {
    'owner': 'wendys',
    'depends_on_past': False, 
    'start_date': datetime(2022, 6, 1, 7, 0,0), 
    'email_on_failure': True, 
    'email': poc_email,
    'retries': 2, 
    'retry_delay': timedelta(minutes=2),
}

dag_ = DAG('cdp_pipeline',default_args=default_args,schedule_interval=cdp_dag_schedule,catchup=False,template_searchpath=[project_path])


############################################################### Custom AIplatform class To Trigger Vertex AI ######################################################
class AiPlatForm:
    """
    Custom Aiplatform  class to submit vertex ai pipeline jobs through google auth transport package, 
        Pseudo Code: 
            - Initialize the class by setting a authorized session using service account.
            - Read project_id and client email from service account to setup project id, bucket id and root path.
                - project id: GCP project ID
                - bucket id: GCP bucket ID, to denote where the artifacts needs to be saved.
                - root path: Used by vertex ai, During training and inference the artifacts will be saved at this location.
            - Prepare the json request that will be sent to the vertex AI endpoint
            - Submit the job to vertex AI and monitor the job completion status
    """
    def __init__(self,project_id,project_path,service_account_email,sleep_time):
        """
        
        Attributes
        ----------
        
        self.scopes:List 
            Used for defining scopes for the service account.
            
        self.credentials: str
            It stores the credentials object authicated using service account.
        
        self.authed_session: object
            It stores the authenticated session object, which can be used to send request to vertex ai endpoints.
        
        self.service_account_email: str
            Email address of the service account.
        
        self.project_id: str
            ID of the project
        
        self.region: str
            where to trigger the vertex ai job. Default(us-central1) 
        
        self.bucket_id: str
            ID of the bucket
        
        self.root_path: str
            path to save the artifacts
        
        """
        self.scopes = ['https://www.googleapis.com/auth/cloud-platform']
        
        self.credentials, _ = google.auth.default(scopes=self.scopes)
        
        self.authed_session = AuthorizedSession(self.credentials)
        
        self.project_id=project_id
        self.region="us-central1"
        self.bucket_id=f"{'-'.join(self.project_id.split('-')[:2])}-ai-ml"
        self.root_path=f"gs://{self.bucket_id}/artifacts"
        
        self.project_path=project_path
        self.service_account_email=service_account_email
        self.sleep_time=sleep_time
        
        self.endpoint=f"https://us-central1-aiplatform.googleapis.com/v1"

    def prepare_request_json(self,filename:str,mode:str)->dict:
        """
        Parameters
        ----------
        filename : str
            Specify which filename to use, Eg:kmeans_training.json, cltv_training.json
        mode : str
            Specify a mode, training or inference
        """
            
        f = open(f"{self.project_path}/vertex_pipelines/{filename}")
        data=json.load(f)

        if mode=='training':
            params={
                    "project_id": {
                          "stringValue": self.project_id}
                   }
        elif mode=='inference':
            params={
                    "project_id": {
                          "stringValue": self.project_id},
                     "bucket_id": {
                          "stringValue": self.bucket_id}
                   }
        
        
        return {
                  "pipelineSpec":  data['pipelineSpec'],
                  "serviceAccount":self.service_account_email,
                  "runtimeConfig":{
                      "parameters":params, 
                      "gcsOutputDirectory": self.root_path
                                  }
                    }
    
    def submit_monitor_job(self,request_json:dict,job_id:str)->str:
        """
        Parameters
        ----------
        request_json : dict
            Specifies the json to send during post request. 
        job_id : str
            Specifies which name of the job, It should unique across all the jobs
            
        Raises
        ------
        RequestException
            if vertex ai job fails to due an unexpected reason.
        """
        
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        
        resp=self.authed_session.post(f"{self.endpoint}/projects/{self.project_id}/locations/{self.region}/pipelineJobs?pipelineJobId={job_id}-{timestamp}",json=request_json)
        
        if resp.status_code==200:
            job_id=resp.json()['name']
            
            ################ Monitor Job #####################
            job_state=resp.json()['state']
            while job_state=='PIPELINE_STATE_PENDING' or job_state=='PIPELINE_STATE_RUNNING':
                time.sleep(self.sleep_time)
                
                resp=self.authed_session.get(f"{self.endpoint}/{job_id}")
                
                job_state=resp.json()['state']
            if job_state=="PIPELINE_STATE_Failed":
                raise ValueError(job_state)
            else:
                return job_state
        else:
            raise ValueError(resp.text)
        
        
def training(**kwargs)->str:
    """
    Parameters
    ----------
    **kwargs : dict
        Specifies which model to train, Eg: {"model":"kmeans"}
    """
    
    ######### Starting model training on a particular day of the week ################
    if datetime.now().strftime("%A").lower()!=ml_model_training_day.lower():
        raise AirflowSkipException
    else:
        ################# Initializing AiPlatform ########################
        aip=AiPlatForm(project_id,project_path,service_account_email,sleep_time)

        request_json=aip.prepare_request_json(f"{kwargs['model']}_training.json","training")

        return aip.submit_monitor_job(request_json,f"{kwargs['model']}-training-pipeline")

def inference(**kwargs)->str:
    """
    Parameters
    ----------
    **kwargs : dict
        Specifies which model to run inference, Eg: {"model":"kmeans"}
    """
    ################ Initializing AiPlatform ########################
    aip=AiPlatForm(project_id,project_path,service_account_email,sleep_time)
    
    request_json=aip.prepare_request_json(f"{kwargs['model']}_inference.json","inference")
    
    return aip.submit_monitor_job(request_json,f"{kwargs['model'].replace('_','-')}-inference-pipeline") ## since vertex AI blocks pipelinename with _, the replace method added to change _ with -

def trigger_monitor_snaplogic_job(**kwargs)->str:
    """
    Parameters
    ----------
    **kwargs : dict
        Specifies taskurl and monitorurl, 
        Eg: {"taskurl":
                "https://snap-aws-dev.wendys.com/api/1/rest/feed/run/task/WendysDev/EnterpriseBI/Customer/JM%20new%20pipeline%200%20Task?bearer_token=56TS1o29lfzmGWtCguic1L6V69rJk8L7",
            "monitorurl":
                "https://snap-aws-dev.wendys.com/api/1/rest/feed/run/task/WendysDev/EnterpriseBI/Customer/JM%20new%20pipeline%200%20Task?bearer_token=56TS1o29lfzmGWtCguic1L6V69rJk8L7"}
                
    """
    
    resp=requests.get(kwargs['taskurl'])
    
    if resp.status_code ==200:
        runID=resp.json()[0]['run_id']
    else:
        raise ValueError("Job Trigger Failed")
        
    job_state=""
    while job_state=="" or job_state=='Started' or job_state=='Running':
        time.sleep(sleep_time) 

        resp=requests.get(kwargs['monitorurl'],params={"run_id":runID})
        if resp.status_code ==200:
            resp_data=resp.json()[0]
            job_state=resp_data['status']
        else:
            job_state="Failed"
        if job_state=="Failed":
            raise ValueError(job_state)
    return job_state


########################################################################### Workflow ##############################################################################################
"""
Here we are using the airflow operators to build our workflow, Following are the operators used in the pipeline

Airflow Operators
----------

DummyOperator :It is more for visualization purposes. To denote start and end of the process. 

BigQueryExecuteQueryOperator: This operator is used to trigger/submit our bigquery jobs. The Sql are read through SQL files placed in SQL folder.

PythonOperator: We using this operator to trigger/submit our vertex AI and snaplogic jobs. 
"""
start = DummyOperator(task_id="Start",dag=dag_)

truncate_incremental_tables=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Truncate_Incremental_Tables', 
                sql=f"/sql/truncate_incremental_tables.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )

######################################################################## Snaplogic Incremental TaskGroup ##########################################################################
with TaskGroup(group_id='Snaplogic_Incremental',dag=dag_) as snaplogic_incremental:
    snaplogic_tasks=[]
    for task in snaplogic_endpoints.keys():
        if task!='monitor' and task!='cdp_gcp_to_sfmc':
            task_id=re.sub(r"Task|%20","",snaplogic_endpoints[task]['url'].split("/")[-1])
            taskurl=f"{snaplogic_endpoints[task]['url']}?bearer_token={snaplogic_endpoints[task]['token']}"
            monitorurl=f"{snaplogic_endpoints['monitor']['url']}?bearer_token={snaplogic_endpoints['monitor']['token']}"
            snaplogic_tasks.append(PythonOperator(task_id=task_id, python_callable=trigger_monitor_snaplogic_job,
                                           op_kwargs={'taskurl':taskurl,'monitorurl':monitorurl}, dag=dag_))
    
    #To run snaplogic task in sequential
    chain(*snaplogic_tasks)

######################################################################## RAW Layer Incremental TaskGroup ##########################################################################
with TaskGroup(group_id='Raw_Layer',dag=dag_) as raw_layer:
    
    ######################################################################## Digital Incremental TaskGroup #######################################################################
    with TaskGroup(group_id='Digital_Incremental',dag=dag_) as digital_incremental:
    
        customer_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer', 
                sql=f"/sql/digital_customer.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_payment_method_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Payment_Method', 
                sql=f"/sql/digital_customer_payment_method.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )

        customer_deletion_request_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Deletion_Request', 
                sql=f"/sql/digital_customer_deletion_request.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        order_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Order', 
                sql=f"/sql/digital_order.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_device_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Device', 
                sql=f"/sql/digital_customer_device.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_address_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Address', 
                sql=f"/sql/digital_customer_address.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        order_tender_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Order_Tender', 
                sql=f"/sql/digital_order_tender.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        order_component_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Order_Component', 
                sql=f"/sql/digital_order_component.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        order_product_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Order_Product', 
                sql=f"/sql/digital_order_product.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_giveaway_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Giveaway', 
                sql=f"/sql/digital_customer_giveaway.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_social_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Social', 
                sql=f"/sql/digital_customer_social.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        customer_meal_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Meal', 
                sql=f"/sql/digital_customer_meal.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )

        customer_meal_product_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Meal_Product', 
                sql=f"/sql/digital_customer_meal_product.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        dpvhstcheckinfo_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='dpvhstcheckinfo', 
                sql=f"/sql/digital_dpvhstcheckinfo.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        customer_meal_component_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Customer_Meal_Component', 
                sql=f"/sql/digital_customer_meal_component.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        ######################################################################### Building Digital Dependecies #########################################################################
        [customer_bq,customer_payment_method_bq,customer_deletion_request_bq,order_bq,customer_device_bq,customer_address_bq,order_tender_bq,order_component_bq,order_product_bq,
         customer_giveaway_bq,customer_social_bq,customer_meal_bq,customer_meal_product_bq,dpvhstcheckinfo_bq,customer_meal_component_bq]
        
        
    ######################################################################## LevelUP Incremental TaskGroup #######################################################################
    with TaskGroup(group_id='LevelUP_Incremental',dag=dag_) as levelup_incremental:
               
        levelup_user_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_User', 
                sql=f"/sql/levelup_user.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_user_campaign_progress_totals_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_User_Campaign_Progress_Totals', 
                sql=f"/sql/levelup_user_campaign_progress_totals.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        levelup_orders_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Orders', 
                sql=f"/sql/levelup_orders.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_accomplishments_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Accomplishments', 
                sql=f"/sql/levelup_accomplishments.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )

        levelup_campaigns_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Campaigns', 
                sql=f"/sql/levelup_campaigns.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_credit_transactions_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Credit_Transactions', 
                sql=f"/sql/levelup_credit_transactions.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
    
        
        levelup_progress_contributions_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Progress_Contributions', 
                sql=f"/sql/levelup_progress_contributions.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_progress_redemptions_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Progress_Redemptions', 
                sql=f"/sql/levelup_progress_redemptions.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_progress_adjustments_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Progress_Adjustments', 
                sql=f"/sql/levelup_progress_adjustments.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_progress_rewards_purchases_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Progress_Rewards_Purchases', 
                sql=f"/sql/levelup_progress_rewards_purchases.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        levelup_purchasable_progress_rewards_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Purchasable_Progress_Rewards', 
                sql=f"/sql/levelup_purchasable_progress_rewards.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_spend_based_goal_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Spend_Based_Goal', 
                sql=f"/sql/levelup_spend_based_goal.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_visit_based_goals_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Visit_Based_Goals', 
                sql=f"/sql/levelup_visit_based_goals.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_refunds_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Refunds', 
                sql=f"/sql/levelup_refunds.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        levelup_locations_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Levelup_Locations', 
                sql=f"/sql/levelup_locations.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
                
        ######################################################################### Building LevelUP Dependecies #########################################################################
        [levelup_user_bq,levelup_user_campaign_progress_totals_bq,levelup_orders_bq,levelup_accomplishments_bq,levelup_campaigns_bq,levelup_credit_transactions_bq,
        levelup_progress_contributions_bq,levelup_progress_redemptions_bq,levelup_progress_adjustments_bq,levelup_progress_rewards_purchases_bq,
        levelup_purchasable_progress_rewards_bq,levelup_spend_based_goal_bq,levelup_visit_based_goals_bq,levelup_refunds_bq,levelup_locations_bq]
        
        
    ######################################################################## Digital Incremental TaskGroup #######################################################################
    with TaskGroup(group_id='SFMC_Incremental',dag=dag_) as sfmc_incremental:
        
        sfmc_click_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Click', 
                sql=f"/sql/sfmc_click.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        sfmc_jobs_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Jobs', 
                sql=f"/sql/sfmc_jobs.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        sfmc_journey_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Journey', 
                sql=f"/sql/sfmc_journey.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        sfmc_journey_activity_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Journey_Activity', 
                sql=f"/sql/sfmc_journey_activity.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        sfmc_mobile_push_tracking_details_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Mobile_Push_Tracking_Details', 
                sql=f"/sql/sfmc_mobile_push_tracking_details.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        sfmc_open_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Open', 
                sql=f"/sql/sfmc_open.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        
        sfmc_sent_bq=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='SFMC_Sent', 
                sql=f"/sql/sfmc_sent.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )
        
        [sfmc_click_bq,sfmc_jobs_bq,sfmc_journey_bq,sfmc_journey_activity_bq,sfmc_mobile_push_tracking_details_bq,sfmc_open_bq,sfmc_sent_bq]
        
    ######################################################################### Building Raw Layer Dependecies #########################################################################
    [digital_incremental,levelup_incremental,sfmc_incremental]
    

with TaskGroup(group_id='Curated_Layer',dag=dag_) as curated_layer:

    rfm_bq=BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='RFM_TABLE', 
            sql=f"/sql/t_mdl_rfm.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    customer_domain_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Customer_Domain_Table', 
            sql=f"/sql/t_dim_customer_domain.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    order_domain_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Order_Domain_Table', 
            sql=f"/sql/t_fact_order_domain.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    ga_domain_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='GA_Domain_Table', 
            sql=f"/sql/t_dim_ga_domain.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    ############################################################################# GA ###############################################################################
    """
    GA has a special case, where in dev,test,stage the BigQueryExecuteQueryOperator needs to use GA from RAW layer. When in prod it will use wendys-production project ID for GA.

    """
    if project_id =="cdp-prd-6370":
        ga_device_bq = BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='GA_Device', 
                sql=f"/sql/t_dim_ga_device.sql",                   
                params={"project_id":project_id,"ga_project_id":"wendys-production","ga_dataset_id":"analytics_167289729"},
                use_legacy_sql=False,
            )
    else:
        ga_device_bq = BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='GA_Device', 
                sql=f"/sql/t_dim_ga_device.sql",                     
                params={"project_id":project_id,"ga_project_id":project_id,"ga_dataset_id":"raw"},
                use_legacy_sql=False,
            )

    #################################################################################################################################################################

    uuid_map_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='UUID_Mapping', 
            sql=f"/sql/t_dim_uuid.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )
    
    delete_inactive_uuid = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Delete_Inactive_UUID', 
            sql=f"/sql/proc_del_inactive_uuid.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    aci_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='ACI_Table', 
            sql=f"/sql/t_dim_aci_token.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    customer_address_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Customer_Address', 
            sql=f"/sql/t_dim_address.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )
    
    
    customer_order_bq = BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Customer_Order_Trans_Table', 
            sql=f"/sql/t_fact_customer_order_trans.sql",
            params={"project_id":project_id,"gcp_wen_id":gcp_wen_project_id[project_id]},
            use_legacy_sql=False,
        )

    sfmc_bq=DummyOperator(task_id="SFMC_Table",dag=dag_)
    
    cltv_training_task= PythonOperator(task_id='cltv_training', python_callable=training,op_kwargs={'model':'cltv'}, trigger_rule="none_failed",dag=dag_)

    cltv_inference_task= PythonOperator(task_id='cltv_inference', python_callable=inference,op_kwargs={'model':'cltv'}, trigger_rule="none_failed",dag=dag_)
    
    kmeans_training_task= PythonOperator(task_id='kmeans_training', python_callable=training,op_kwargs={'model':'kmeans'}, trigger_rule="none_failed",dag=dag_)

    kmeans_inference_task= PythonOperator(task_id='kmeans_inference', python_callable=inference,op_kwargs={'model':'kmeans'}, trigger_rule="none_failed",dag=dag_)

    unified_customer_pii_bq=BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Unified_Customer_PII', 
            sql=f"/sql/curated_t_fact_unified_customer.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )

    ######################################################################### Curated Layer Dependecies #########################################################################


    [customer_domain_bq , sfmc_bq, aci_bq, ga_device_bq] 

    ga_device_bq >> ga_domain_bq

    aci_bq >> customer_order_bq >> order_domain_bq

    aci_bq >> customer_order_bq >> rfm_bq >> cltv_training_task >> cltv_inference_task >>  kmeans_training_task >> kmeans_inference_task >> order_domain_bq  

    customer_domain_bq >> customer_address_bq >> uuid_map_bq >> delete_inactive_uuid

    [customer_domain_bq,ga_domain_bq,sfmc_bq,order_domain_bq,delete_inactive_uuid] >> unified_customer_pii_bq


    
with TaskGroup(group_id='Gold_Layer',dag=dag_) as gold_layer:
    
    unified_customer_bq=BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Unified_Customer_Without_PII', 
            sql="/sql/gold_t_fact_unified_customer.sql",
            params={"project_id":project_id},
            use_legacy_sql=False,
        )
    
    breakfast_affinity_model_inference = PythonOperator(task_id='Breakfast_Affinity_Model_Inference', python_callable=inference,op_kwargs={'model':'breakfast_affinity'}, trigger_rule="none_failed",dag=dag_)

    looker_aggregation_bq=BigQueryExecuteQueryOperator(
            dag = dag_, 
            task_id='Looker_Aggregation', 
            sql="/sql/t_fact_looker_aggregation.sql",
            params={"project_id":project_id},
            destination_dataset_table=f"{project_id}.gold.t_fact_looker_aggregation",
            write_disposition='WRITE_TRUNCATE',
            use_legacy_sql=False,
        )
    
    ######################################################################### Gold Layer Dependecies #########################################################################
    unified_customer_bq >> [breakfast_affinity_model_inference, looker_aggregation_bq]

################################################### Deduplication ######################################################################
if enable_deduplication:
    deduplication=BigQueryExecuteQueryOperator(
                dag = dag_, 
                task_id='Deduplication', 
                sql="/sql/t_fact_dgtl_cust_link.sql",
                params={"project_id":project_id},
                use_legacy_sql=False,
            )    
else:
    deduplication=DummyOperator(task_id="Deduplication",dag=dag_)
########################################################################## GCP to SFMC Snaplogic ############################################################################
"""
    GCP to SFMC has a special case, where in dev and prod it will be executed. In other environments in test and stage it will be kept as dummy operator.
"""
if project_id =="cdp-dev-bdfa" or project_id =="cdp-prd-6370":
    task="cdp_gcp_to_sfmc"
    taskurl=f"{snaplogic_endpoints[task]['url']}?bearer_token={snaplogic_endpoints[task]['token']}"
    monitorurl=f"{snaplogic_endpoints['monitor']['url']}?bearer_token={snaplogic_endpoints['monitor']['token']}"
    snaplogic_sfmc= PythonOperator(task_id="Snaplogic_GCP_TO_SFMC", python_callable=trigger_monitor_snaplogic_job,
                                   op_kwargs={'taskurl':taskurl,'monitorurl':monitorurl}, dag=dag_)
else:
    snaplogic_sfmc = DummyOperator(task_id="Snaplogic_GCP_TO_SFMC",dag=dag_)
    
end = DummyOperator(task_id="End",dag=dag_)

start >> truncate_incremental_tables >> snaplogic_incremental >> raw_layer >> curated_layer >> gold_layer >> [deduplication,snaplogic_sfmc] >> end