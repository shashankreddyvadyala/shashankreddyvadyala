


--Joining digital customer table with dpvhstcheckinfo to get checkin info
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_customer_order_w_checkin OPTIONS(
  description = "harmonized layer"
) AS 
SELECT ord.*,
      checkinfo.atttext,
      checkinfo.checkid,
      checkinfo.dateofbusiness
FROM `cdp-dev-bdfa.raw_layer_demo.customer_order` as ord
left join `cdp-dev-bdfa.raw_new.dpvhstcheckinfo` as checkinfo
	on cast(ord.order_id as string)=checkinfo.atttext
left join `cdp-dev-bdfa.raw_layer_demo.customer` as c
	on ord.customer_id =c.customer_id 
where checkinfo.attname='ORDER_REFERENCE_ID'
and c.status_ind IN ('A', 'I');




--Joining curated.t_fact_sales_transactions an populating customer_id

CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id OPTIONS(
  description = "harmonized layer"
) AS 
select a.*,
b.customer_id as customer_id_dig_ord,
concat(a.business_date,"_",a.site_num,"_",a.receipt_id) as unq_order
from `cdp-dev-bdfa.raw_layer_demo.t_fact_sales_transactions`  as a 
left join cdp-dev-bdfa.harmonized_layer_demo.temp_customer_order_w_checkin as b 
on a.site_num=b.site_num
and a.business_date=b.dateofbusiness
and a.receipt_id=b.checkid
and b.order_status_cod='PREPARED';



select count(*), count(distinct customer_id), count(distinct receipt_id) 
from `cdp-dev-bdfa.raw_layer_demo.t_fact_sales_transactions`;
--3691513 0 11873 

select count(*), count(distinct customer_id), count(distinct customer_id_dig_ord), count(distinct receipt_id) 
from `cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id`;
-- 3691517 0  2906 11873 


CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.t_fact_sales_transactions_with_cust_id OPTIONS(
  description = "harmonized layer"
) AS 
select customer_id_dig_ord as customer_id,
		sales_transaction_id,site_num,business_date,transaction_number,receipt_id,maint_user_id,
		maint_tms,source_system_name,dim_site_key,dim_insight_source_key,dim_customer_key,dim_location_key,
		location_name,transaction_reason,transaction_type_desc,transaction_close_time_num,txn_close_time_utc,
		txn_close_time_local,dim_daypart_key,daypart_name,employee_num,currency_code,tender_amt,tender_cnt,
		total_tax_amt,gross_sales_amt,net_sales_amt,transaction_cnt,discount_amt,discount_cnt,kids_meal_amt,
		kids_meal_cnt,kids_meal_toy_amt,kids_meal_toy_cnt,gift_card_sales_amt,gift_card_sales_cnt,
		gift_cert_sales_amt,gift_cert_sales_cnt,local_promo_amt,local_promo_cnt,national_promo_amt,
		national_promo_cnt,manager_void_amt,manager_void_cnt,surcharge_amt,register_num,
		register_operator_void_cnt,end_of_day_complete_flag
from cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id;


select count(*), count(distinct customer_id), count(distinct receipt_id) 
from cdp-dev-bdfa.harmonized_layer_demo.t_fact_sales_transactions_with_cust_id;
-- 3691517 2906  11873 


-- Creating customer base
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base OPTIONS(
  description = "harmonized layer"
) AS 
select distinct customer_id
from cdp-dev-bdfa.harmonized_layer_demo.t_fact_sales_transactions_with_cust_id
where customer_id is not null;


select count(*) from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base;
--2906  


--12 months summary variables
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_12_mnth_summ OPTIONS(
  description = "harmonized layer"
) AS 
select a.customer_id,
        count(distinct b.unq_order) as FREQ_12MO,
		sum(b.net_sales_amt) as TOTAL_CHECK_12MO,
		sum(b.discount_amt) as DISCOUNT_AMOUNT_12MO,
        min(business_date) as LAST_VISIT_TMS,
        date_diff(current_date(), min(business_date), DAY) as DAYS_SINCE_LAST_VISIT,
		count(distinct case when  b.daypart_name = 'BREAKFAST'  then b.unq_order END) as FREQ_BKFST,
		count(distinct case when  b.daypart_name = 'LUNCH'  then b.unq_order END) as FREQ_LUNCH,
		count(distinct case when  b.daypart_name = 'AFTERNOON SNACK'  then b.unq_order END) as FREQ_AFTN,
		count(distinct case when  b.daypart_name = 'DINNER'  then b.unq_order END) as FREQ_DINNER,
		count(distinct case when  b.daypart_name = 'PM SNACK'  then b.unq_order END) as FREQ_PM_SNK,
		count(distinct case when  b.daypart_name = 'LATE NIGHT'  then b.unq_order END) as FREQ_LATE_NT,
		sum(distinct case when  b.daypart_name = 'BREAKFAST'  then b.net_sales_amt END) as TOT_CHECK_BKFST,
		sum(distinct case when  b.daypart_name = 'LUNCH'  then b.net_sales_amt END) as TOT_CHECK_LUNCH,
		sum(distinct case when  b.daypart_name = 'AFTERNOON SNACK'  then b.net_sales_amt END) as TOT_CHECK_AFTN,
		sum(distinct case when  b.daypart_name = 'DINNER'  then b.net_sales_amt END) as TOT_CHECK_DINNER,
		sum(distinct case when  b.daypart_name = 'PM SNACK'  then b.net_sales_amt END) as TOT_CHECK_PM_SNK,
		sum(distinct case when  b.daypart_name = 'LATE NIGHT'  then b.net_sales_amt END) as TOT_CHECK_LATE_NT,
		
from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id as b
on a.customer_id=b.customer_id_dig_ord
and business_date between DATE_ADD(CAST(current_date() as DATE), INTERVAL -12 MONTH) and current_date()
group by 1;



drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_12_mnth_summ_2;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_12_mnth_summ_2 OPTIONS(
  description = "harmonized layer"
) AS
select a.*,

case when ifnull(FREQ_12MO,0)=0 then 'None'
	 when ifnull(FREQ_12MO,0)>0 and ifnull(FREQ_12MO,0) <=18 then 'Low'
	 when ifnull(FREQ_12MO,0)>18 and ifnull(FREQ_12MO,0) <=36 then 'Medium'
	 else 'High' end as FREQ_CATEGORY_BIN,
case when FREQ_12MO > 1 then 1 else 0 end as REPEAT_CUST_FLAG,
case when TOTAL_CHECK_12MO > 0 then DISCOUNT_AMOUNT_12MO/TOTAL_CHECK_12MO else 0 end as PCT_DISCOUNTED,
case when FREQ_12MO>0 then TOTAL_CHECK_12MO / FREQ_12MO else 0 end as AVG_CHECK_12MO,
case when FREQ_BKFST>0 then TOT_CHECK_BKFST / FREQ_BKFST else 0 end as AVG_CHECK_BKFST,
case when FREQ_LUNCH>0 then TOT_CHECK_LUNCH / FREQ_LUNCH else 0 end as AVG_CHECK_LUNCH,
case when FREQ_AFTN>0 then TOT_CHECK_AFTN / FREQ_AFTN else 0 end as AVG_CHECK_AFTN,
case when FREQ_DINNER>0 then TOT_CHECK_DINNER / FREQ_DINNER else 0 end as AVG_CHECK_DINNER,
case when FREQ_PM_SNK>0 then TOT_CHECK_PM_SNK / FREQ_PM_SNK else 0 end as AVG_CHECK_PM_SNK,
case when FREQ_LATE_NT>0 then TOT_CHECK_LATE_NT / FREQ_LATE_NT else 0 end as AVG_CHECK_LATE_NT

from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_12_mnth_summ as a;



/*1 month summary variables*/
drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ OPTIONS(
  description = "harmonized layer"
) AS
select a.customer_id,
        count(distinct unq_order) as FREQ_1MO,
        sum(b.net_sales_amt) as TOTAL_CHECK_1MO
		
from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id as b
on a.customer_id=b.customer_id_dig_ord
and business_date between DATE_ADD(CAST(current_date() as DATE), INTERVAL -1 MONTH) and current_date()
group by 1;


drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ_2;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ_2 OPTIONS(
  description = "harmonized layer"
) AS
select a.*,
TOTAL_CHECK_1MO / FREQ_1MO as AVG_CHECK_1MO
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ as a;


/*3 month summary variables*/
drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ OPTIONS(
  description = "harmonized layer"
) AS
select a.customer_id,
        count(distinct b.unq_order) as FREQ_3MO,
        sum(b.net_sales_amt) as TOTAL_CHECK_3MO
		
from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id as b
on a.customer_id=b.customer_id_dig_ord
and business_date between DATE_ADD(CAST(current_date() as DATE), INTERVAL -3 MONTH) and current_date()
group by 1;


drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ_2;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ_2 OPTIONS(
  description = "harmonized layer"
) AS
select a.*,
TOTAL_CHECK_3MO / FREQ_3MO as AVG_CHECK_3MO
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ as a;



/*6 month summary variables*/
drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ OPTIONS(
  description = "harmonized layer"
) AS
select a.customer_id,
        count(distinct b.unq_order) as FREQ_6MO,
        sum(b.net_sales_amt) as TOTAL_CHECK_6MO
		
from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id as b
on a.customer_id=b.customer_id_dig_ord
and business_date between DATE_ADD(CAST(current_date() as DATE), INTERVAL -6 MONTH) and current_date()
group by 1;

drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ_2;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ_2 OPTIONS(
  description = "harmonized layer"
) AS
select a.*,
TOTAL_CHECK_6MO / FREQ_6MO as AVG_CHECK_6MO
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ as a;


/*March frequency*/
drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_march_mnth_summ;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_march_mnth_summ OPTIONS(
  description = "harmonized layer"
) AS
select a.customer_id,
		count(distinct case when EXTRACT(MONTH FROM b.business_date)  = 3 then b.unq_order END) as FREQ_MARCH
from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_t_fact_sales_transactions_with_cust_id as b
on a.customer_id=b.customer_id_dig_ord
and business_date between DATE_ADD(CAST(current_date() as DATE), INTERVAL -12 MONTH) and current_date()
group by 1;


--Collating all transaction data

drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ OPTIONS(
  description = "harmonized layer"
) AS
select a.customer_id,
		b.REPEAT_CUST_FLAG,
		b.FREQ_12MO,
		b.FREQ_CATEGORY_BIN,
		b.AVG_CHECK_12MO,
		b.LAST_VISIT_TMS,
		b.DAYS_SINCE_LAST_VISIT,
		b.AVG_CHECK_BKFST,
		b.AVG_CHECK_LUNCH,
		b.AVG_CHECK_AFTN,
		b.AVG_CHECK_DINNER,
		b.AVG_CHECK_PM_SNK,
		b.AVG_CHECK_LATE_NT,
		b.FREQ_BKFST,
		b.FREQ_LUNCH,
		b.FREQ_AFTN,
		b.FREQ_DINNER,
		b.FREQ_PM_SNK,
		b.FREQ_LATE_NT,
		b.PCT_DISCOUNTED,
		
		c.FREQ_1MO,
		c.AVG_CHECK_1MO,

		d.FREQ_3MO,
		d.AVG_CHECK_3MO,

		e.FREQ_6MO,
		e.AVG_CHECK_6MO,

		f.FREQ_MARCH,
		
		current_timestamp() as LAST_UPDT_TMS

from cdp-dev-bdfa.harmonized_layer_demo.temp_c360_cust_base as a
left join cdp-dev-bdfa.harmonized_layer_demo.temp_fe_12_mnth_summ_2 as b on a.customer_id=b.customer_id
left join cdp-dev-bdfa.harmonized_layer_demo.temp_fe_1_mnth_summ_2 as c on a.customer_id=c.customer_id
left join cdp-dev-bdfa.harmonized_layer_demo.temp_fe_3_mnth_summ_2 as d on a.customer_id=d.customer_id
left join cdp-dev-bdfa.harmonized_layer_demo.temp_fe_6_mnth_summ_2 as e on a.customer_id=e.customer_id
left join cdp-dev-bdfa.harmonized_layer_demo.temp_fe_march_mnth_summ as f on a.customer_id=f.customer_id;


select count(*), count(distinct customer_id)
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ;
-- 56496 	56496 



--Joining customer info

drop table cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ_cust_info;
CREATE 
OR REPLACE TABLE cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ_cust_info OPTIONS(
  description = "harmonized layer"
) AS
select a.*,
b.SF_CONTACT_ID as SFMC_CONTACT_ID,
b.VENDOR_ID as SFSC_VENDOR_ID,
b.FIRST_NAM as FIRST_NAME,
b.LAST_NAM as LAST_NAME,
b.BIRTH_DAT as BIRTH_DATE,
b.GENDER_IND as GENDER,
b.LANG_COD as LANG_CODE,
b.CNTRY_COD as COUNTRY_CODE,
b.CURRENCY_COD as CURRENCY_CODE,
b.EMAIL_ADR  as EMAIL,
b.opt_in_flg as EMAIL_OPT_IN,
b.postal_cod as POSTAL_CODE,
b.va_eligibility_flg as VETERAN_FLAG,
b.create_tms as DGTL_CUST_CREATE_TMS
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ as a
left join cdp-dev-bdfa.raw_layer_demo.customer as b on a.customer_id=b.customer_id;


select count(*), count(distinct customer_id)
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ_cust_info;
-- 56496	56496 


--Customer info is available only for 2.9K customers
select count(*)
from cdp-dev-bdfa.harmonized_layer_demo.temp_fe_summ_cust_info
where FIRST_NAME is not null;
--2986 


