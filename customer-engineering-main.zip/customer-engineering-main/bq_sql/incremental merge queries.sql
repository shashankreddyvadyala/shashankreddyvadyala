MERGE INTO `cdp-prd-6370.raw.customer` TARGET
USING `cdp-prd-6370.raw.temp_customer` SOURCE
ON TARGET.customer_id = SOURCE.customer_id
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_customer_id=SOURCE.aloha_customer_id,
TARGET.auto_reload_enabled_flg=SOURCE.auto_reload_enabled_flg,
TARGET.balance_threshold_amt=SOURCE.balance_threshold_amt,
TARGET.birth_dat=SOURCE.birth_dat,
TARGET.brierley_ip_cod=SOURCE.brierley_ip_cod,
TARGET.brierley_loyalty_id=SOURCE.brierley_loyalty_id,
TARGET.brierley_reward_id=SOURCE.brierley_reward_id,
TARGET.can_mobile_order_flg=SOURCE.can_mobile_order_flg,
TARGET.cntry_cod=SOURCE.cntry_cod,
TARGET.cop_adi_num=SOURCE.cop_adi_num,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.create_version_id=SOURCE.create_version_id,
TARGET.currency_cod=SOURCE.currency_cod,
TARGET.current_cod=SOURCE.current_cod,
TARGET.customer_id=SOURCE.customer_id,
TARGET.customer_typ=SOURCE.customer_typ,
TARGET.email_adr=SOURCE.email_adr,
TARGET.encrypt_flg=SOURCE.encrypt_flg,
TARGET.fail_attempt_num=SOURCE.fail_attempt_num,
TARGET.fail_round_num=SOURCE.fail_round_num,
TARGET.fail_tms=SOURCE.fail_tms,
TARGET.favorite_order_flg=SOURCE.favorite_order_flg,
TARGET.first_login_flg=SOURCE.first_login_flg,
TARGET.first_nam=SOURCE.first_nam,
TARGET.gender_ind=SOURCE.gender_ind,
TARGET.givex_customer_id=SOURCE.givex_customer_id,
TARGET.givex_iso_serial_num=SOURCE.givex_iso_serial_num,
TARGET.givex_num=SOURCE.givex_num,
TARGET.is_loyalty_2020=SOURCE.is_loyalty_2020,
TARGET.is_loyalty_profile=SOURCE.is_loyalty_profile,
TARGET.lang_cod=SOURCE.lang_cod,
TARGET.last_nam=SOURCE.last_nam,
TARGET.login_id=SOURCE.login_id,
TARGET.loyalty_card_flg=SOURCE.loyalty_card_flg,
TARGET.loyalty_level_cod=SOURCE.loyalty_level_cod,
TARGET.loyalty_level_tms=SOURCE.loyalty_level_tms,
TARGET.loyalty_phone_num=SOURCE.loyalty_phone_num,
TARGET.loyalty_qr_enabled=SOURCE.loyalty_qr_enabled,
TARGET.loyalty_terms_accepted_tms=SOURCE.loyalty_terms_accepted_tms,
TARGET.maint_source_cod=SOURCE.maint_source_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.maint_version_id=SOURCE.maint_version_id,
TARGET.merkle_id=SOURCE.merkle_id,
TARGET.offer_push_sent_tms=SOURCE.offer_push_sent_tms,
TARGET.opt_in_flg=SOURCE.opt_in_flg,
TARGET.passcode_txt=SOURCE.passcode_txt,
TARGET.password_txt=SOURCE.password_txt,
TARGET.plastic_customer_id=SOURCE.plastic_customer_id,
TARGET.postal_cod=SOURCE.postal_cod,
TARGET.privacy_donotsell=SOURCE.privacy_donotsell,
TARGET.reload_amt=SOURCE.reload_amt,
TARGET.sf_contact_id=SOURCE.sf_contact_id,
TARGET.status_ind=SOURCE.status_ind,
TARGET.terms_flg=SOURCE.terms_flg,
TARGET.va_eligibility_flg=SOURCE.va_eligibility_flg,
TARGET.va_member_id=SOURCE.va_member_id,
TARGET.va_signup_tms=SOURCE.va_signup_tms,
TARGET.va_status_tms=SOURCE.va_status_tms,
TARGET.vendor_encoded_id=SOURCE.vendor_encoded_id,
TARGET.vendor_id=SOURCE.vendor_id,
TARGET.verification_sent_tms=SOURCE.verification_sent_tms,
TARGET.verified_tms=SOURCE.verified_tms,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_payment_method` TARGET
USING `cdp-prd-6370.raw.temp_customer_payment_method` SOURCE
ON TARGET.customer_id = SOURCE.customer_id and TARGET.payment_method_id = SOURCE.payment_method_id
WHEN MATCHED THEN
UPDATE SET
TARGET.account_cod=SOURCE.account_cod,
TARGET.account_nam=SOURCE.account_nam,
TARGET.account_num=SOURCE.account_num,
TARGET.address_id=SOURCE.address_id,
TARGET.aloha_account_id=SOURCE.aloha_account_id,
TARGET.collect_cvv_flg=SOURCE.collect_cvv_flg,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.expire_dat=SOURCE.expire_dat,
TARGET.lp_token_id=SOURCE.lp_token_id,
TARGET.maint_source_cod=SOURCE.maint_source_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.payment_method_id=SOURCE.payment_method_id,
TARGET.status_ind=SOURCE.status_ind,
TARGET.vi_tid=SOURCE.vi_tid,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_deletion_request` TARGET
USING `cdp-prd-6370.raw.temp_customer_deletion_request` SOURCE
ON TARGET.customer_deletion_request_id = SOURCE.customer_deletion_request_id 
and TARGET.create_tms = SOURCE.create_tms
WHEN MATCHED THEN
UPDATE SET
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.create_version_id=SOURCE.create_version_id,
TARGET.customer_deletion_request_id=SOURCE.customer_deletion_request_id,
TARGET.customer_id=SOURCE.customer_id,
TARGET.dwh_process_tms=SOURCE.dwh_process_tms,
TARGET.email_adr=SOURCE.email_adr,
TARGET.givex_amt=SOURCE.givex_amt,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.order` TARGET
USING `cdp-prd-6370.raw.temp_order` SOURCE
ON TARGET.customer_order_id = SOURCE.customer_order_id 
and TARGET.create_tms = SOURCE.create_tms
WHEN MATCHED THEN
UPDATE SET
TARGET.account_cod=SOURCE.account_cod,
TARGET.account_num=SOURCE.account_num,
TARGET.address_id=SOURCE.address_id,
TARGET.aloha_account_id=SOURCE.aloha_account_id,
TARGET.aloha_order_id=SOURCE.aloha_order_id,
TARGET.aloha_site_id=SOURCE.aloha_site_id,
TARGET.ato_order_id=SOURCE.ato_order_id,
TARGET.beacon_id=SOURCE.beacon_id,
TARGET.beacon_payload_id=SOURCE.beacon_payload_id,
TARGET.breakfast_flg=SOURCE.breakfast_flg,
TARGET.cops_nam=SOURCE.cops_nam,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_source_cod_version=SOURCE.create_source_cod_version,
TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_coupon_id=SOURCE.customer_coupon_id,
TARGET.customer_id=SOURCE.customer_id,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.customer_qr_code=SOURCE.customer_qr_code,
TARGET.delivery_address_id=SOURCE.delivery_address_id,
TARGET.delivery_dropoff_des=SOURCE.delivery_dropoff_des,
TARGET.delivery_est=SOURCE.delivery_est,
TARGET.delivery_fee=SOURCE.delivery_fee,
TARGET.delivery_phone_num=SOURCE.delivery_phone_num,
TARGET.delivery_provider=SOURCE.delivery_provider,
TARGET.delivery_tip=SOURCE.delivery_tip,
TARGET.delivery_tracking_url=SOURCE.delivery_tracking_url,
TARGET.delivery_trans_fee=SOURCE.delivery_trans_fee,
TARGET.device_id=SOURCE.device_id,
TARGET.digital_payment_type=SOURCE.digital_payment_type,
TARGET.discount_amt=SOURCE.discount_amt,
TARGET.latitude_num=SOURCE.latitude_num,
TARGET.longitude_num=SOURCE.longitude_num,
TARGET.lunch_flg=SOURCE.lunch_flg,
TARGET.order_id=SOURCE.order_id,
TARGET.order_mode_id=SOURCE.order_mode_id,
TARGET.order_status_cod=SOURCE.order_status_cod,
TARGET.organization_fee=SOURCE.organization_fee,
TARGET.payment_method_id=SOURCE.payment_method_id,
TARGET.pos_order_num=SOURCE.pos_order_num,
TARGET.proc_loy_flg=SOURCE.proc_loy_flg,
TARGET.promo_cod=SOURCE.promo_cod,
TARGET.promocodes_json=SOURCE.promocodes_json,
TARGET.puck_num=SOURCE.puck_num,
TARGET.site_num=SOURCE.site_num,
TARGET.sub_total_amt=SOURCE.sub_total_amt,
TARGET.tax_amt=SOURCE.tax_amt,
TARGET.tax_exempt_flg=SOURCE.tax_exempt_flg,
TARGET.total_amt=SOURCE.total_amt,
TARGET.user_type=SOURCE.user_type,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.customer_device` TARGET
USING `cdp-prd-6370.raw.temp_customer_device` SOURCE
ON TARGET.device_id = SOURCE.device_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.channel_id=SOURCE.channel_id,
TARGET.create_tms=SOURCE.create_tms,
TARGET.device_id=SOURCE.device_id,
TARGET.device_nam=SOURCE.device_nam,
TARGET.kount_session_id=SOURCE.kount_session_id,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.manufacturer_txt=SOURCE.manufacturer_txt,
TARGET.model_txt=SOURCE.model_txt,
TARGET.offer_push_sent_tms=SOURCE.offer_push_sent_tms,
TARGET.os_typ=SOURCE.os_typ,
TARGET.os_version=SOURCE.os_version,
TARGET.phone_flg=SOURCE.phone_flg,
TARGET.print_id=SOURCE.print_id,
TARGET.screen_height_num=SOURCE.screen_height_num,
TARGET.screen_width_num=SOURCE.screen_width_num,
TARGET.source_cod=SOURCE.source_cod,
TARGET.tm_session_id=SOURCE.tm_session_id,
TARGET.user_agent_txt=SOURCE.user_agent_txt,
TARGET.version_id=SOURCE.version_id,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_address` TARGET
USING `cdp-prd-6370.raw.temp_customer_address` SOURCE
ON TARGET.customer_id = SOURCE.customer_id and TARGET.address_id = SOURCE.address_id 
and TARGET.create_tms = SOURCE.create_tms
WHEN MATCHED THEN
UPDATE SET
TARGET.address_id=SOURCE.address_id,
TARGET.address_typ=SOURCE.address_typ,
TARGET.address1_txt=SOURCE.address1_txt,
TARGET.address2_txt=SOURCE.address2_txt,
TARGET.city_txt=SOURCE.city_txt,
TARGET.cntry_cod=SOURCE.cntry_cod,
TARGET.create_source_cod=SOURCE.create_source_cod,
TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.latitude_num=SOURCE.latitude_num,
TARGET.longitude_num=SOURCE.longitude_num,
TARGET.maint_source_cod=SOURCE.maint_source_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.postal_cod=SOURCE.postal_cod,
TARGET.state_cod=SOURCE.state_cod,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.order_tender` TARGET
USING `cdp-prd-6370.raw.temp_order_tender` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.tender_seq=SOURCE.tender_seq  AND TARGET.create_tms=SOURCE.create_tms

)
WHEN MATCHED THEN
UPDATE SET
TARGET.account_cod=SOURCE.account_cod,
TARGET.account_num=SOURCE.account_num,
TARGET.aloha_account_id=SOURCE.aloha_account_id,
TARGET.aloha_tender_id=SOURCE.aloha_tender_id,
TARGET.authorization_num=SOURCE.authorization_num,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.digital_payment_type=SOURCE.digital_payment_type,
TARGET.lp_div_num=SOURCE.lp_div_num,
TARGET.lp_token_id=SOURCE.lp_token_id,
TARGET.mag_device_serial_num=SOURCE.mag_device_serial_num,
TARGET.payment_method_id=SOURCE.payment_method_id,
TARGET.tender_amt=SOURCE.tender_amt,
TARGET.tender_seq=SOURCE.tender_seq,
TARGET.transaction_id=SOURCE.transaction_id,
TARGET.create_tms=SOURCE.create_tms,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.order_component` TARGET
USING `cdp-prd-6370.raw.temp_order_component` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.product_seq=SOURCE.product_seq AND TARGET.create_tms=SOURCE.create_tms
AND TARGET.component_seq=SOURCE.component_seq

)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_action_id=SOURCE.aloha_action_id,
TARGET.aloha_modifier_group_id=SOURCE.aloha_modifier_group_id,
TARGET.aloha_modifier_id=SOURCE.aloha_modifier_id,
TARGET.aloha_nam=SOURCE.aloha_nam,
TARGET.aloha_pos_group_id=SOURCE.aloha_pos_group_id,
TARGET.aloha_pos_item_id=SOURCE.aloha_pos_item_id,
TARGET.comp_id=SOURCE.comp_id,
TARGET.component_seq=SOURCE.component_seq,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.extended_prc=SOURCE.extended_prc,
TARGET.product_seq=SOURCE.product_seq,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.unit_prc=SOURCE.unit_prc,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.create_tms=SOURCE.create_tms
WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.order_product` TARGET
USING `cdp-prd-6370.raw.temp_order_product` SOURCE
ON (TARGET.customer_order_id=SOURCE.customer_order_id AND TARGET.product_seq=SOURCE.product_seq AND TARGET.create_tms=SOURCE.create_tms

)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_menu_item_id=SOURCE.aloha_menu_item_id,
TARGET.aloha_nam=SOURCE.aloha_nam,
TARGET.aloha_pos_item_id=SOURCE.aloha_pos_item_id,
TARGET.aloha_sales_item_id=SOURCE.aloha_sales_item_id,
TARGET.brierley_member_reward_id=SOURCE.brierley_member_reward_id,
TARGET.customer_order_id=SOURCE.customer_order_id,
TARGET.extended_prc=SOURCE.extended_prc,
TARGET.message=SOURCE.message,
TARGET.prod_id=SOURCE.prod_id,
TARGET.product_seq=SOURCE.product_seq,
TARGET.promo_cod=SOURCE.promo_cod,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.reward_pos_item_id=SOURCE.reward_pos_item_id,
TARGET.unit_prc=SOURCE.unit_prc,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.create_tms=SOURCE.create_tms

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.customer_giveaway` TARGET
USING `cdp-prd-6370.raw.temp_customer_giveaway` SOURCE
ON ( TARGET.redemption_cod=SOURCE.redemption_cod AND TARGET.customer_id=SOURCE.customer_id

)
WHEN MATCHED THEN
UPDATE SET
TARGET.assignment_tms=SOURCE.assignment_tms,
TARGET.category=SOURCE.category,
TARGET.customer_id=SOURCE.customer_id,
TARGET.device_id=SOURCE.device_id,
TARGET.end_dat=SOURCE.end_dat,
TARGET.giveaway_amt=SOURCE.giveaway_amt,
TARGET.giveaway_type=SOURCE.giveaway_type,
TARGET.redemption_cod=SOURCE.redemption_cod,
TARGET.redemption_tms=SOURCE.redemption_tms,
TARGET.start_dat=SOURCE.start_dat,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.customer_social` TARGET
USING `cdp-prd-6370.raw.temp_customer_social` SOURCE
ON (TARGET.social_id=SOURCE.social_id AND TARGET.social_typ=SOURCE.social_typ AND TARGET.customer_id=SOURCE.customer_id

)
WHEN MATCHED THEN
UPDATE SET
TARGET.customer_id=SOURCE.customer_id,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.social_id=SOURCE.social_id,
TARGET.social_typ=SOURCE.social_typ,
TARGET.source_cod=SOURCE.source_cod,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_meal` TARGET
USING `cdp-prd-6370.raw.temp_customer_meal` SOURCE
ON TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID and TARGET.meal_nam = SOURCE.meal_nam 
WHEN MATCHED THEN
UPDATE SET

TARGET.create_tms=SOURCE.create_tms,
TARGET.customer_id=SOURCE.customer_id,
TARGET.default_flg=SOURCE.default_flg,	
TARGET.favorite_type_cod=SOURCE.favorite_type_cod,
TARGET.maint_tms=SOURCE.maint_tms,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_meal_product` TARGET
USING `cdp-prd-6370.raw.temp_customer_meal_product` SOURCE
ON (TARGET.CUSTOMER_ID = SOURCE.CUSTOMER_ID and TARGET.meal_nam = SOURCE.meal_nam  
and TARGET.slot_num = SOURCE.slot_num and TARGET.prod_id = SOURCE.prod_id)
WHEN MATCHED THEN
UPDATE SET

TARGET.customer_id=SOURCE.customer_id,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.prod_id=SOURCE.prod_id,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.set_num=SOURCE.set_num,
TARGET.slot_num=SOURCE.slot_num,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.maint_tms=SOURCE.maint_tms

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.dpvhstcheckinfo` TARGET
USING `cdp-prd-6370.raw.temp_dpvhstcheckinfo` SOURCE
ON (TARGET.dateofbusiness=SOURCE.dateofbusiness and TARGET.distkey=SOURCE.distkey  
and TARGET.uniqueid=SOURCE.uniqueid)
WHEN MATCHED THEN
UPDATE SET

TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.attname=SOURCE.attname,
TARGET.atttext=SOURCE.atttext,
TARGET.checkid=SOURCE.checkid,
TARGET.dateofbusiness=SOURCE.dateofbusiness,
TARGET.datetimestamp=SOURCE.datetimestamp,
TARGET.dim_insight_source_key=SOURCE.dim_insight_source_key,
TARGET.distkey=SOURCE.distkey,
TARGET.fkemployeenumber=SOURCE.fkemployeenumber,
TARGET.fkoccasionid=SOURCE.fkoccasionid,
TARGET.fkstoreid=SOURCE.fkstoreid,
TARGET.importchecksum=SOURCE.importchecksum,
TARGET.last_maint_tms=SOURCE.last_maint_tms,
TARGET.queueid=SOURCE.queueid,
TARGET.tableid=SOURCE.tableid,
TARGET.uniqueid=SOURCE.uniqueid

WHEN NOT MATCHED THEN
INSERT ROW;

MERGE INTO `cdp-prd-6370.raw.customer_meal_component` TARGET
USING `cdp-prd-6370.raw.temp_customer_meal_component` SOURCE
ON (TARGET.customer_id = SOURCE.customer_id AND TARGET.meal_nam = SOURCE.meal_nam AND TARGET.slot_num=SOURCE.slot_num AND TARGET.prod_id=SOURCE.prod_id
AND TARGET.comp_id=SOURCE.comp_id)
WHEN MATCHED THEN
UPDATE SET
TARGET.aloha_action_id=SOURCE.aloha_action_id,
TARGET.comp_id=SOURCE.comp_id,
TARGET.customer_id=SOURCE.customer_id,
TARGET.meal_nam=SOURCE.meal_nam,
TARGET.prod_id=SOURCE.prod_id,
TARGET.quantity_num=SOURCE.quantity_num,
TARGET.slot_num=SOURCE.slot_num,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.maint_tms=SOURCE.maint_tms
WHEN NOT MATCHED THEN
INSERT ROW;



/*temp_levelup_user  to levelup_user*/

MERGE INTO cdp-prd-6370.raw.levelup_user TARGET
USING cdp-prd-6370.raw.temp_levelup_user SOURCE
ON TARGET.loyalty_id = SOURCE.loyalty_id
WHEN MATCHED THEN
UPDATE SET
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.first_name = SOURCE.first_name,
TARGET.last_name=SOURCE.last_name,
TARGET.email=SOURCE.email,
TARGET.phone=SOURCE.phone,
TARGET.registered_at=SOURCE.registered_at,
TARGET.registered_device_type=SOURCE.registered_device_type,
TARGET.account_type=SOURCE.account_type,
TARGET.subscribed_to_emails =SOURCE.subscribed_to_emails,
TARGET.birthdate=SOURCE.birthdate,
TARGET.gender=SOURCE.gender,
TARGET.favorite_location=SOURCE.favorite_location,
TARGET.first_order_created_at=SOURCE.first_order_created_at,
TARGET.last_order_created_at=SOURCE.last_order_created_at,
TARGET.number_of_visits=SOURCE.number_of_visits,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_user_campaign_progress_totals  to levelup_user_campaign_progress_totals*/

MERGE INTO cdp-prd-6370.raw.levelup_user_campaign_progress_totals TARGET
USING cdp-prd-6370.raw.temp_levelup_user_campaign_progress_totals SOURCE
ON (TARGET.loyalty_id = SOURCE.loyalty_id AND TARGET.id= SOURCE.id)
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.total_order_contribution=SOURCE.total_order_contribution,
TARGET.total_adjustment=SOURCE.total_adjustment,
TARGET.progress_period_type=SOURCE.progress_period_type,
TARGET.current_progress=SOURCE.current_progress,
TARGET.fixed_progress_period_starts_at=SOURCE.fixed_progress_period_starts_at,
TARGET.fixed_progress_period_resets_at=SOURCE.fixed_progress_period_resets_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_orders  to levelup_orders*/

MERGE INTO cdp-prd-6370.raw.levelup_orders TARGET
USING cdp-prd-6370.raw.temp_levelup_orders SOURCE
ON (TARGET.order_id = SOURCE.order_id AND TARGET.created_at = SOURCE.created_at)
WHEN MATCHED THEN
UPDATE SET
TARGET.order_id=SOURCE.order_id,
TARGET.created_at=SOURCE.created_at,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.food_and_beverage=SOURCE.food_and_beverage,
TARGET.tax_amount=SOURCE.tax_amount,
TARGET.tip=SOURCE.tip,
TARGET.location_id=SOURCE.location_id,
TARGET.street_address=SOURCE.street_address,
TARGET.order_source=SOURCE.order_source,
TARGET.reward_credit_redeemed=SOURCE.reward_credit_redeemed,
TARGET.channel=SOURCE.channel,
TARGET.business_order_id=SOURCE.business_order_id,
TARGET.order_uuid=SOURCE.order_uuid,
TARGET.state=SOURCE.state,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_accomplishments  to levelup_accomplishments*/

MERGE INTO cdp-prd-6370.raw.levelup_accomplishments TARGET
USING cdp-prd-6370.raw.temp_levelup_accomplishments SOURCE
ON TARGET.id = SOURCE.id 
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.goal_id=SOURCE.goal_id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.threshold_as_integer=SOURCE.threshold_as_integer,
TARGET.expires_at=SOURCE.expires_at,
TARGET.goal_type=SOURCE.goal_type,
TARGET.overtaken=SOURCE.overtaken,
TARGET.terminal=SOURCE.terminal,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_campaigns to levelup_campaigns*/

MERGE INTO cdp-prd-6370.raw.levelup_campaigns TARGET
USING cdp-prd-6370.raw.temp_levelup_campaigns SOURCE
ON TARGET.id = SOURCE.id 
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.opens_at=SOURCE.opens_at,
TARGET.closes_at=SOURCE.closes_at,
TARGET.value_amount=SOURCE.value_amount,
TARGET.campaign_type=SOURCE.campaign_type,
TARGET.custom_name=SOURCE.custom_name,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;



/*temp_levelup_credit_transactions to levelup_credit_transactions*/

INSERT INTO `cdp-prd-6370.raw.levelup_credit_transactions`
SELECT * FROM `cdp-prd-6370.raw.temp_levelup_credit_transactions`;


/*temp_levelup_item_based_goal  to levelup_item_based_goal*/

MERGE INTO cdp-prd-6370.raw.levelup_item_based_goal TARGET
USING cdp-prd-6370.raw.temp_levelup_item_based_goal SOURCE
ON TARGET.id = SOURCE.id 
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.required_item_count=SOURCE.required_item_count,
TARGET.concept_modifier=SOURCE.concept_modifier,
TARGET.concept_type=SOURCE.concept_type,
TARGET.description=SOURCE.description,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;



/*temp_levelup_progress_contributions to levelup_progress_contributions */

MERGE INTO cdp-prd-6370.raw.levelup_progress_contributions TARGET
USING cdp-prd-6370.raw.temp_levelup_progress_contributions SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.order_id=SOURCE.order_id,
TARGET.user_campaign_progress_total_id=SOURCE.user_campaign_progress_total_id,
TARGET.contribution=SOURCE.contribution,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_progress_redemptions to levelup_progress_redemptions */

MERGE INTO cdp-prd-6370.raw.levelup_progress_redemptions TARGET
USING cdp-prd-6370.raw.temp_levelup_progress_redemptions SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.created_at=SOURCE.created_at,
TARGET.id=SOURCE.id,
TARGET.progress_amount=SOURCE.progress_amount,
TARGET.progress_reward_purchases_id=SOURCE.progress_reward_purchases_id,
TARGET.progress_source_id=SOURCE.progress_source_id,
TARGET.progress_source_type=SOURCE.progress_source_type,
TARGET.purchasable_progress_reward_id=SOURCE.purchasable_progress_reward_id,
TARGET.updated_at=SOURCE.updated_at,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_progress_adjustments to levelup_progress_adjustments */

MERGE INTO cdp-prd-6370.raw.levelup_progress_adjustments TARGET
USING cdp-prd-6370.raw.temp_levelup_progress_adjustments SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.user_campaign_progress_total_id=SOURCE.user_campaign_progress_total_id,
TARGET.adjustment=SOURCE.adjustment,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_progress_rewards_purchases to levelup_progress_rewards_purchases */

MERGE INTO cdp-prd-6370.raw.levelup_progress_rewards_purchases TARGET
USING cdp-prd-6370.raw.temp_levelup_progress_rewards_purchases SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.created_at=SOURCE.created_at,
TARGET.id=SOURCE.id,
TARGET.loyalty_id=SOURCE.loyalty_id,
TARGET.purchasable_progress_reward_id=SOURCE.purchasable_progress_reward_id,
TARGET.reward_id=SOURCE.reward_id,
TARGET.reward_type=SOURCE.reward_type,
TARGET.updated_at=SOURCE.updated_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;

/*temp_levelup_purchasable_progress_rewards to levelup_purchasable_progress_rewards */

MERGE INTO cdp-prd-6370.raw.levelup_purchasable_progress_rewards TARGET
USING cdp-prd-6370.raw.temp_levelup_purchasable_progress_rewards SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.active=SOURCE.active,
TARGET.description=SOURCE.description,
TARGET.details=SOURCE.details,
TARGET.name=SOURCE.name,
TARGET.purchasable_until=SOURCE.purchasable_until,
TARGET.required_progress_amount=SOURCE.required_progress_amount,
TARGET.source_campaign_id=SOURCE.source_campaign_id,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,  
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_spend_based_goal to levelup_spend_based_goal*/

MERGE INTO cdp-prd-6370.raw.levelup_spend_based_goal TARGET
USING cdp-prd-6370.raw.temp_levelup_spend_based_goal SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.required_spend_amount=SOURCE.required_spend_amount,
TARGET.concept_modifier=SOURCE.concept_modifier,
TARGET.concept_type=SOURCE.concept_type,
TARGET.description=SOURCE.description,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
 TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_visit_based_goals to levelup_visit_based_goals*/

MERGE INTO cdp-prd-6370.raw.levelup_visit_based_goals TARGET
USING cdp-prd-6370.raw.temp_levelup_visit_based_goals SOURCE
ON TARGET.id = SOURCE.id
WHEN MATCHED THEN
UPDATE SET
TARGET.id=SOURCE.id,
TARGET.created_at=SOURCE.created_at,
TARGET.updated_at=SOURCE.updated_at,
TARGET.campaign_id=SOURCE.campaign_id,
TARGET.required_visit_count=SOURCE.required_visit_count,
TARGET.concept_modifier=SOURCE.concept_modifier,
TARGET.concept_type=SOURCE.concept_type,
TARGET.description=SOURCE.description,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_refunds to levelup_refunds*/

MERGE INTO cdp-prd-6370.raw.levelup_refunds TARGET
USING cdp-prd-6370.raw.temp_levelup_refunds SOURCE
ON (TARGET.order_id = SOURCE.order_id AND TARGET.refunded_at = SOURCE.refunded_at)
WHEN MATCHED THEN
UPDATE SET
TARGET.order_id=SOURCE.order_id,
TARGET.refunded_at=SOURCE.refunded_at,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


/*temp_levelup_locations to levelup_locations*/

MERGE INTO cdp-prd-6370.raw.levelup_locations TARGET
USING cdp-prd-6370.raw.temp_levelup_locations SOURCE
ON TARGET.location_id = SOURCE.location_id 
WHEN MATCHED THEN
UPDATE SET
TARGET.location_id=SOURCE.location_id,
TARGET.reference_name=SOURCE.reference_name,
TARGET.latitude=SOURCE.latitude,
TARGET.longitude=SOURCE.longitude,
TARGET.street_address=SOURCE.street_address,
TARGET.extended_address=SOURCE.extended_address,
TARGET.locality=SOURCE.locality,
TARGET.region=SOURCE.region,
TARGET.postal_code=SOURCE.postal_code,
TARGET.terminated=SOURCE.terminated,
TARGET.time_zone=SOURCE.time_zone,
TARGET.visible=SOURCE.visible,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms
WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO cdp-prd-6370.raw.SFMC_Click TARGET
USING cdp-prd-6370.raw.temp_SFMC_Click SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.SubscriberKey=SOURCE.SubscriberKey AND TARGET.EventDate=SOURCE.EventDate
WHEN MATCHED THEN
UPDATE SET
TARGET.AccountID=SOURCE.AccountID,
TARGET.BatchID=SOURCE.BatchID,
TARGET.Domain=SOURCE.Domain,
TARGET.EventDate=SOURCE.EventDate,
TARGET.IsUnique=SOURCE.IsUnique,
TARGET.JobID=SOURCE.JobID,
TARGET.LinkContent=SOURCE.LinkContent,
TARGET.LinkName=SOURCE.LinkName,
TARGET.ListID=SOURCE.ListID,
TARGET.OYBAccountID=SOURCE.OYBAccountID,
TARGET.SubscriberID=SOURCE.SubscriberID,
TARGET.SubscriberKey=SOURCE.SubscriberKey,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.URL=SOURCE.URL,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.EventFullDate=SOURCE.EventFullDate

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_Jobs` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_Jobs` SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.DeliveredTime=SOURCE.DeliveredTime
WHEN MATCHED THEN
UPDATE SET
TARGET.CreatedDate=SOURCE.CreatedDate,
TARGET.DeduplicateByEmail=SOURCE.DeduplicateByEmail,
TARGET.DeliveredTime=SOURCE.DeliveredTime,
TARGET.DynamicEmailSubject=SOURCE.DynamicEmailSubject,
TARGET.EmailID=SOURCE.EmailID,
TARGET.EmailName=SOURCE.EmailName,
TARGET.EmailSendDefinition=SOURCE.EmailSendDefinition,
TARGET.EmailSubject=SOURCE.EmailSubject,
TARGET.EventID=SOURCE.EventID,
TARGET.FromEmail=SOURCE.FromEmail,
TARGET.FromName=SOURCE.FromName,
TARGET.IPAddress=SOURCE.IPAddress,
TARGET.IsMultipart=SOURCE.IsMultipart,
TARGET.IsWrapped=SOURCE.IsWrapped,
TARGET.JobID=SOURCE.JobID,
TARGET.JobStatus=SOURCE.JobStatus,
TARGET.JobType=SOURCE.JobType,
TARGET.ModifiedBy=SOURCE.ModifiedBy,
TARGET.ModifiedDate=SOURCE.ModifiedDate,
TARGET.OriginalSchedTime=SOURCE.OriginalSchedTime,
TARGET.PickupTime=SOURCE.PickupTime,
TARGET.ResolveLinksWithCurrentData=SOURCE.ResolveLinksWithCurrentData,
TARGET.SalesForceErrorSubscriberCount=SOURCE.SalesForceErrorSubscriberCount,
TARGET.SalesForceTotalSubscriberCount=SOURCE.SalesForceTotalSubscriberCount,
TARGET.SchedTime=SOURCE.SchedTime,
TARGET.SendClassification=SOURCE.SendClassification,
TARGET.SendClassificationType=SOURCE.SendClassificationType,
TARGET.SendType=SOURCE.SendType,
TARGET.SuppressTracking=SOURCE.SuppressTracking,
TARGET.TestEmailAddr=SOURCE.TestEmailAddr,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.CreatedFullDate=SOURCE.CreatedFullDate,
TARGET.DeliveredFullTime=SOURCE.DeliveredFullTime,
TARGET.ModifiedFullDate=SOURCE.ModifiedFullDate,
TARGET.OriginalFullSchedTime=SOURCE.OriginalFullSchedTime,
TARGET.PickupFullTime=SOURCE.PickupFullTime,
TARGET.SchedFullTime=SOURCE.SchedFullTime

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_Journey` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_Journey` SOURCE
ON TARGET.JourneyID=SOURCE.JourneyID AND TARGET.VersionID=SOURCE.VersionID
WHEN MATCHED THEN
UPDATE SET
TARGET.CreatedDate=SOURCE.CreatedDate,
TARGET.JourneyID=SOURCE.JourneyID,
TARGET.JourneyName=SOURCE.JourneyName,
TARGET.JourneyStatus=SOURCE.JourneyStatus,
TARGET.LastPublishedDate=SOURCE.LastPublishedDate,
TARGET.ModifiedDate=SOURCE.ModifiedDate,
TARGET.VersionID=SOURCE.VersionID,
TARGET.VersionNumber=SOURCE.VersionNumber,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.CreatedFullDate=SOURCE.CreatedFullDate,
TARGET.LastPublishedFullDate=SOURCE.LastPublishedFullDate,
TARGET.ModifiedFullDate=SOURCE.ModifiedFullDate

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_JourneyActivity` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_JourneyActivity` SOURCE
ON TARGET.ActivityID=SOURCE.ActivityID AND TARGET.VersionID=SOURCE.VersionID
WHEN MATCHED THEN
UPDATE SET
TARGET.ActivityExternalKey=SOURCE.ActivityExternalKey,
TARGET.ActivityID=SOURCE.ActivityID,
TARGET.ActivityName=SOURCE.ActivityName,
TARGET.ActivityType=SOURCE.ActivityType,
TARGET.JourneyActivityObjectID=SOURCE.JourneyActivityObjectID,
TARGET.VersionID=SOURCE.VersionID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_MobilePushTrackingDetails` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_MobilePushTrackingDetails` SOURCE
ON TARGET.ContactKey=SOURCE.ContactKey AND TARGET.PushJobId=SOURCE.PushJobId AND TARGET.DateTimeSend=SOURCE.DateTimeSend
WHEN MATCHED THEN
UPDATE SET
TARGET.AndroidMediaUrl=SOURCE.AndroidMediaUrl,
TARGET.AppName=SOURCE.AppName,
TARGET.Campaigns=SOURCE.Campaigns,
TARGET.ContactKey=SOURCE.ContactKey,
TARGET.DateTimeSend=SOURCE.DateTimeSend,
TARGET.DeviceId=SOURCE.DeviceId,
TARGET.Format=SOURCE.Format,
TARGET.GeofenceName=SOURCE.GeofenceName,
TARGET.InboxMessageDownloaded=SOURCE.InboxMessageDownloaded,
TARGET.IosMediaUrl=SOURCE.IosMediaUrl,
TARGET.MediaAlt=SOURCE.MediaAlt,
TARGET.MessageContent=SOURCE.MessageContent,
TARGET.MessageID=SOURCE.MessageID,
TARGET.MessageName=SOURCE.MessageName,
TARGET.MessageOpened=SOURCE.MessageOpened,
TARGET.OpenDate=SOURCE.OpenDate,
TARGET.PageName=SOURCE.PageName,
TARGET.Platform=SOURCE.Platform,
TARGET.PushJobId=SOURCE.PushJobId,
TARGET.RequestId=SOURCE.RequestId,
TARGET.ServiceResponse=SOURCE.ServiceResponse,
TARGET.Status=SOURCE.Status,
TARGET.SystemToken=SOURCE.SystemToken,
TARGET.Template=SOURCE.Template,
TARGET.TimeInApp=SOURCE.TimeInApp,
TARGET.DateTimeSendFull=SOURCE.DateTimeSendFull,
TARGET.OpenDateFull=SOURCE.OpenDateFull,
TARGET.TimeInAppFull=SOURCE.TimeInAppFull
WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_Open` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_Open` SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.SubscriberKey=SOURCE.SubscriberKey AND TARGET.EventDate=SOURCE.EventDate
WHEN MATCHED THEN
UPDATE SET
TARGET.AccountID=SOURCE.AccountID,
TARGET.BatchID=SOURCE.BatchID,
TARGET.Domain=SOURCE.Domain,
TARGET.EventDate=SOURCE.EventDate,
TARGET.IsUnique=SOURCE.IsUnique,
TARGET.JobID=SOURCE.JobID,
TARGET.ListID=SOURCE.ListID,
TARGET.OYBAccountID=SOURCE.OYBAccountID,
TARGET.SubscriberID=SOURCE.SubscriberID,
TARGET.SubscriberKey=SOURCE.SubscriberKey,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.EventFullDate=SOURCE.EventFullDate

WHEN NOT MATCHED THEN
INSERT ROW;


MERGE INTO `cdp-prd-6370.raw.SFMC_Sent` TARGET
USING `cdp-prd-6370.raw.temp_SFMC_Sent` SOURCE
ON TARGET.JobID=SOURCE.JobID AND TARGET.SubscriberKey=SOURCE.SubscriberKey AND TARGET.EventDate=SOURCE.EventDate
WHEN MATCHED THEN
UPDATE SET
TARGET.AccountID=SOURCE.AccountID,
TARGET.BatchID=SOURCE.BatchID,
TARGET.Domain=SOURCE.Domain,
TARGET.EventDate=SOURCE.EventDate,
TARGET.JobID=SOURCE.JobID,
TARGET.ListID=SOURCE.ListID,
TARGET.OYBAccountID=SOURCE.OYBAccountID,
TARGET.SubscriberID=SOURCE.SubscriberID,
TARGET.SubscriberKey=SOURCE.SubscriberKey,
TARGET.TriggeredSendCustomerKey=SOURCE.TriggeredSendCustomerKey,
TARGET.TriggererSendDefinitionObjectID=SOURCE.TriggererSendDefinitionObjectID,
TARGET.sl_date=SOURCE.sl_date,
TARGET.sl_user=SOURCE.sl_user,
TARGET.Ingestion_tms=SOURCE.Ingestion_tms,
TARGET.EventFullDate=SOURCE.EventFullDate

WHEN NOT MATCHED THEN
INSERT ROW;



















