CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_Click`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(128),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  LinkContent STRING(1000),
  LinkName STRING,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING,
  URL STRING(1000),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
  PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_Journey`
(
  CreatedDate DATETIME,
  JourneyID STRING(255),
  JourneyName STRING(255),
  JourneyStatus STRING(255),
  LastPublishedDate DATETIME,
  ModifiedDate DATETIME,
  VersionID STRING(255),
  VersionNumber INT64,
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  CreatedFullDate String(255),
  LastPublishedFullDate String(255),
  ModifiedFullDate String(255)
);
CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_Sent`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate String
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_Open`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey STRING(255),
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_JourneyActivity`
(
  ActivityExternalKey STRING,
  ActivityID STRING,
  ActivityName STRING,
  ActivityType STRING,
  JourneyActivityObjectID STRING,
  VersionID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME
);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_Jobs`
(
  AccountID INT64,
  AccountUserID INT64,
  BccEmail STRING,
  Category STRING,
  CharacterSet STRING,
  CreatedDate DATETIME,
  DeduplicateByEmail STRING,
  DeliveredTime DATETIME,
  DynamicEmailSubject STRING,
  EmailID STRING,
  EmailName STRING,
  EmailSendDefinition STRING,
  EmailSubject STRING,
  EventID STRING,
  FromEmail STRING,
  FromName STRING,
  IPAddress STRING,
  IsMultipart STRING,
  IsWrapped STRING,
  JobID INT64,
  JobStatus STRING,
  JobType STRING,
  ModifiedBy STRING,
  ModifiedDate DATETIME,
  OriginalSchedTime DATETIME,
  PickupTime DATETIME,
  ResolveLinksWithCurrentData STRING,
  SalesForceErrorSubscriberCount STRING,
  SalesForceTotalSubscriberCount STRING,
  SchedTime DATETIME,
  SendClassification STRING,
  SendClassificationType STRING,
  SendType STRING,
  SuppressTracking STRING,
  TestEmailAddr STRING,
  TriggeredSendCustomerKey STRING,
  TriggererSendDefinitionObjectID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME,
  CreatedFullDate STRING,
DeliveredFullTime STRING,
ModifiedFullDate STRING,
OriginalFullSchedTime STRING,
PickupFullTime STRING,
SchedFullTime STRING
)
 PARTITION BY DATE(DeliveredTime);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.SFMC_MobilePushTrackingDetails`
(
AndroidMediaUrl STRING(1000),
AppName STRING(255),
Campaigns STRING(255),
ContactKey STRING(255),
DateTimeSend DATETIME,
DeviceId STRING(255),
Format STRING(255),
GeofenceName STRING(255),
InboxMessageDownloaded STRING(1000),
IosMediaUrl STRING(1000),
MediaAlt STRING(1000),
MessageContent STRING(1000),
MessageID STRING(1000),
MessageName STRING(1000),
MessageOpened STRING(1000),
OpenDate DATETIME,
PageName STRING(255),
Platform STRING(255),
PushJobId STRING(255),
RequestId STRING(255),
ServiceResponse STRING(255),
Status STRING(255),
SystemToken STRING(255),
Template STRING(255),
TimeInApp DATETIME,
DateTimeSendFull STRING(255),
OpenDateFull STRING(255),
TimeInAppFull STRING(255)

)
 PARTITION BY DATE(DateTimeSend);



CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Click`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(128),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  LinkContent STRING(1000),
  LinkName STRING,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING,
  URL STRING(1000),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
  PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Journey`
(
  CreatedDate DATETIME,
  JourneyID STRING(255),
  JourneyName STRING(255),
  JourneyStatus STRING(255),
  LastPublishedDate DATETIME,
  ModifiedDate DATETIME,
  VersionID STRING(255),
  VersionNumber INT64,
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  CreatedFullDate String(255),
  LastPublishedFullDate String(255),
  ModifiedFullDate String(255)
);
CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Sent`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate String
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Open`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey STRING(255),
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_JourneyActivity`
(
  ActivityExternalKey STRING,
  ActivityID STRING,
  ActivityName STRING,
  ActivityType STRING,
  JourneyActivityObjectID STRING,
  VersionID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME
);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Jobs`
(
  AccountID INT64,
  AccountUserID INT64,
  BccEmail STRING,
  Category STRING,
  CharacterSet STRING,
  CreatedDate DATETIME,
  DeduplicateByEmail STRING,
  DeliveredTime DATETIME,
  DynamicEmailSubject STRING,
  EmailID STRING,
  EmailName STRING,
  EmailSendDefinition STRING,
  EmailSubject STRING,
  EventID STRING,
  FromEmail STRING,
  FromName STRING,
  IPAddress STRING,
  IsMultipart STRING,
  IsWrapped STRING,
  JobID INT64,
  JobStatus STRING,
  JobType STRING,
  ModifiedBy STRING,
  ModifiedDate DATETIME,
  OriginalSchedTime DATETIME,
  PickupTime DATETIME,
  ResolveLinksWithCurrentData STRING,
  SalesForceErrorSubscriberCount STRING,
  SalesForceTotalSubscriberCount STRING,
  SchedTime DATETIME,
  SendClassification STRING,
  SendClassificationType STRING,
  SendType STRING,
  SuppressTracking STRING,
  TestEmailAddr STRING,
  TriggeredSendCustomerKey STRING,
  TriggererSendDefinitionObjectID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME,
  CreatedFullDate STRING,
DeliveredFullTime STRING,
ModifiedFullDate STRING,
OriginalFullSchedTime STRING,
PickupFullTime STRING,
SchedFullTime STRING
)
 PARTITION BY DATE(DeliveredTime);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_MobilePushTrackingDetails`
(
AndroidMediaUrl STRING(1000),
AppName STRING(255),
Campaigns STRING(255),
ContactKey STRING(255),
DateTimeSend DATETIME,
DeviceId STRING(255),
Format STRING(255),
GeofenceName STRING(255),
InboxMessageDownloaded STRING(1000),
IosMediaUrl STRING(1000),
MediaAlt STRING(1000),
MessageContent STRING(1000),
MessageID STRING(1000),
MessageName STRING(1000),
MessageOpened STRING(1000),
OpenDate DATETIME,
PageName STRING(255),
Platform STRING(255),
PushJobId STRING(255),
RequestId STRING(255),
ServiceResponse STRING(255),
Status STRING(255),
SystemToken STRING(255),
Template STRING(255),
TimeInApp DATETIME,
DateTimeSendFull STRING(255),
OpenDateFull STRING(255),
TimeInAppFull STRING(255)

)
 PARTITION BY DATE(DateTimeSend);