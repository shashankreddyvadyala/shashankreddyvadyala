CREATE TABLE `cdp-prd-6370.raw.temp_order`
(
account_cod STRING(20),
account_num STRING(128),
address_id INT64,
aloha_account_id STRING(64),
aloha_order_id INT64,
aloha_site_id INT64,
ato_order_id INT64,
beacon_id STRING(128),
beacon_payload_id STRING(128),
breakfast_flg STRING(1),
cops_nam STRING(100),
create_source_cod STRING(20),
create_source_cod_version STRING(64),
create_tms DATETIME,
customer_coupon_id INT64,
customer_id INT64,
customer_order_id INT64,
customer_qr_code STRING(40),
delivery_address_id INT64,
delivery_dropoff_des STRING(256),
delivery_est FLOAT64,
delivery_fee FLOAT64,
delivery_phone_num STRING(25),
delivery_provider STRING(22),
delivery_tip FLOAT64,
delivery_tracking_url STRING(256),
delivery_trans_fee FLOAT64,
device_id STRING(128),
digital_payment_type STRING(256),
discount_amt FLOAT64,
latitude_num FLOAT64,
longitude_num FLOAT64,
lunch_flg STRING(1),
order_id FLOAT64,
order_mode_id FLOAT64,
order_status_cod STRING(20),
organization_fee FLOAT64,
payment_method_id FLOAT64,
pos_order_num FLOAT64,
proc_loy_flg STRING(1),
promo_cod STRING(20),
promocodes_json STRING(100),
puck_num FLOAT64,
site_num FLOAT64,
sub_total_amt FLOAT64,
tax_amt FLOAT64,
tax_exempt_flg STRING(1),
total_amt FLOAT64,
user_type STRING(255),
Ingestion_tms DATETIME
)
PARTITION BY DATE(create_tms);
 
 
 
 
 
 
 
CREATE TABLE `cdp-prd-6370.raw.temp_customer_device`( 
 
 
 
channel_id STRING(100), 
 
create_tms DATETIME, 
 
device_id STRING(128), 
 
device_nam STRING(128), 
 
kount_session_id STRING(32), 
 
maint_tms DATETIME, 
 
manufacturer_txt STRING(100), 
 
model_txt STRING(100), 
 
offer_push_sent_tms DATETIME, 
 
os_typ STRING(100), 
 
os_version STRING(25), 
 
phone_flg STRING(1), 
 
print_id STRING(4000), 
 
screen_height_num INT64, 
 
screen_width_num INT64, 
 
source_cod STRING(20), 
 
tm_session_id STRING(128), 
 
user_agent_txt STRING(256), 
 
version_id STRING(20), 
 
Ingestion_tms DATETIME, 
 
 
 
) 
 
 
 
PARTITION BY DATE(maint_tms); 
 
 
 
CREATE TABLE `cdp-prd-6370.raw.temp_customer_deletion_request`( 
 
 
 
create_source_cod STRING(20), 
 
create_tms DATETIME, 
 
create_version_id STRING(20), 
 
customer_deletion_request_id INT64, 
 
customer_id INT64, 
 
dwh_process_tms DATETIME, 
 
email_adr STRING(100), 
 
givex_amt FLOAT64, 
 
Ingestion_tms DATETIME, 
 
 
 
)
 
 
 
PARTITION BY DATE(create_tms); 
 
 
 
 
 
CREATE TABLE `cdp-prd-6370.raw.temp_customer_address`( 
 
 
 
address_id INT64, 
 
address_typ STRING(20), 
 
address1_txt STRING(200), 
 
address2_txt STRING(200), 
 
city_txt STRING(50), 
 
cntry_cod STRING(2), 
 
create_source_cod STRING(20), 
 
create_tms DATETIME, 
 
customer_id INT64, 
 
latitude_num FLOAT64, 
 
longitude_num FLOAT64, 
 
maint_source_cod STRING(20), 
 
maint_tms DATETIME, 
 
postal_cod STRING(20), 
 
state_cod STRING(2), 
 
Ingestion_tms DATETIME, 
 
) 
 
 
 
PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000)); 
 
 
 
 
 
CREATE TABLE `cdp-prd-6370.raw.temp_customer_payment_method`( 
 
 
 
account_cod STRING(20), 
 
account_nam STRING(128), 
 
account_num STRING(128), 
 
address_id INT64, 
 
aloha_account_id STRING(64), 
 
collect_cvv_flg STRING(1), 
 
create_source_cod STRING(20), 
 
create_tms DATETIME, 
 
customer_id INT64, 
 
expire_dat DATETIME, 
 
lp_token_id STRING(20), 
 
maint_source_cod STRING(20), 
 
maint_tms DATETIME, 
 
payment_method_id INT64, 
 
status_ind STRING(1), 
 
vi_tid STRING(20), 
 
Ingestion_tms DATETIME, 
 
 
 
 
 
) 
 
 
 
PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000)); 
 
 
 
CREATE TABLE `cdp-prd-6370.raw.temp_customer`
(
  aloha_customer_id STRING(150),
  auto_reload_enabled_flg STRING(1),
  balance_threshold_amt FLOAT64,
  birth_dat DATETIME,
  brierley_ip_cod INT64,
  brierley_loyalty_id STRING(255),
  brierley_reward_id INT64,
  can_mobile_order_flg STRING(1),
  cntry_cod STRING(2),
  cop_adi_num INT64,
  create_source_cod STRING(20),
  create_tms DATETIME,
  create_version_id STRING(20),
  currency_cod STRING(20),
  current_cod STRING(1),
  customer_id INT64,
  customer_typ STRING(40),
  email_adr STRING(100),
  encrypt_flg STRING(1),
  fail_attempt_num INT64,
  fail_round_num INT64,
  fail_tms DATETIME,
  favorite_order_flg STRING(1),
  first_login_flg STRING(1),
  first_nam STRING(150),
  gender_ind STRING(1),
  givex_customer_id STRING(120),
  givex_iso_serial_num STRING(120),
  givex_num STRING(120),
  is_loyalty_2020 STRING(1),
  is_loyalty_profile STRING(1),
  lang_cod STRING(2),
  last_nam STRING(50),
  login_id STRING(100),
  loyalty_card_flg STRING(1),
  loyalty_level_cod STRING(20),
  loyalty_level_tms DATETIME,
  loyalty_phone_num STRING(25),
  loyalty_qr_enabled STRING(1),
  loyalty_terms_accepted_tms DATETIME,
  maint_source_cod STRING(20),
  maint_tms DATETIME,
  maint_version_id STRING(20),
  merkle_id FLOAT64,
  offer_push_sent_tms DATETIME,
  opt_in_flg STRING(1),
  passcode_txt STRING(75),
  password_txt STRING(75),
  plastic_customer_id STRING(120),
  postal_cod STRING(20),
  privacy_donotsell STRING(1000),
  reload_amt FLOAT64,
  sf_contact_id STRING(18),
  status_ind STRING(1),
  terms_flg STRING(1),
  va_eligibility_flg STRING(1),
  va_member_id STRING(16),
  va_signup_tms DATETIME,
  va_status_tms DATETIME,
  vendor_encoded_id STRING(90),
  vendor_id STRING(40),
  verification_sent_tms DATETIME,
  verified_tms DATETIME,
  Ingestion_tms DATETIME
)
PARTITION BY RANGE_BUCKET(customer_id, GENERATE_ARRAY(0, 1000000000, 200000));



CREATE TABLE `cdp-prd-6370.raw.temp_LUIS_completed_order`( 


 Ingestion_tms DATETIME, 


CANCELLED BOOLEAN, 


CREATE_DATE DATETIME, 


CUSTOMER_COUNTRY STRING(255), 


CUSTOMER_LANGUAGE STRING(255), 


LEVELUP_COMPLETED_ORDER_ID STRING(255), 


OBJECT_TTL INT64, 


WENDYS_ORDER_ID INT64, 


CREATED_TMS STRING(255), 

) 


PARTITION BY DATE(CREATE_DATE); 


 


 


CREATE TABLE `cdp-prd-6370.raw.temp_LUIS_location`( 


 Ingestion_tms DATETIME, 

WENDYS_SITE_NUM INT64, 


LEVELUP_LOCATION_ID INT64, 


); 


 

CREATE TABLE `cdp-prd-6370.raw.temp_LUIS_customer`
(
  Ingestion_tms DATETIME,
  CREATE_DATE DATETIME,
  CUSTOMER_COUNTRY STRING(255),
  CUSTOMER_LANGUAGE STRING(255),
  LEVELUP_CUSTOMER_ID INT64,
  WENDYS_CUSTOMER_ID INT64,
  CREATED_TMS STRING(255),
  sl_date DATETIME
);
 

CREATE TABLE `cdp-prd-6370.raw.temp_customer_social`(

customer_id INT64,
maint_tms DATETIME,
social_id STRING(100),
social_typ STRING(30),
source_cod STRING(20),
Ingestion_tms DATETIME,


)

PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000));


CREATE TABLE `cdp-prd-6370.raw.temp_customer_meal_component`(

 aloha_action_id INT64,
comp_id INT64,
customer_id INT64,
meal_nam STRING(100),
prod_id INT64,
quantity_num INT64,
slot_num INT64,
Ingestion_tms DATETIME,
maint_tms DATETIME,



)
PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000));	


CREATE TABLE `cdp-prd-6370.raw.temp_order_tender`(

 account_cod STRING(20),
account_num STRING(4),
aloha_account_id STRING(64),
aloha_tender_id INT64,
authorization_num STRING(20),
customer_order_id INT64,
digital_payment_type STRING(400),
lp_div_num STRING(20),
lp_token_id STRING(20),
mag_device_serial_num STRING(20),
payment_method_id INT64,
tender_amt FLOAT64,
tender_seq INT64,
transaction_id STRING(128),
create_tms DATETIME,
Ingestion_tms DATETIME,

)
PARTITION BY DATE(create_tms);


CREATE TABLE `cdp-prd-6370.raw.temp_order_product`(

 aloha_menu_item_id INT64,
aloha_nam STRING(200),
aloha_pos_item_id INT64,
aloha_sales_item_id INT64,
brierley_member_reward_id INT64,
customer_order_id INT64,
extended_prc FLOAT64,
message STRING(30),
prod_id INT64,
product_seq INT64,
promo_cod STRING(20),
quantity_num INT64,
reward_pos_item_id INT64,
unit_prc FLOAT64,
Ingestion_tms DATETIME,
create_tms DATETIME,
)

PARTITION BY DATE(create_tms);


CREATE TABLE `cdp-prd-6370.raw.temp_customer_meal_product`(

 customer_id INT64,
meal_nam STRING(100),
prod_id INT64,
quantity_num INT64,
set_num INT64,
slot_num INT64,
Ingestion_tms DATETIME,
maint_tms DATETIME,


)

PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000));


CREATE TABLE `cdp-prd-6370.raw.temp_order_component`(

 aloha_action_id INT64,
aloha_modifier_group_id INT64,
aloha_modifier_id INT64,
aloha_nam STRING(200),
aloha_pos_group_id INT64,
aloha_pos_item_id INT64,
comp_id INT64,
component_seq INT64,
customer_order_id INT64,
extended_prc FLOAT64,
product_seq INT64,
quantity_num INT64,
unit_prc FLOAT64,
Ingestion_tms DATETIME,
create_tms DATETIME,


)

PARTITION BY DATE(create_tms);


CREATE TABLE `cdp-prd-6370.raw.temp_customer_giveaway`(

assignment_tms TIMESTAMP,
category STRING(40),
customer_id INT64,
device_id STRING(128),
end_dat DATETIME,
giveaway_amt FLOAT64,
giveaway_type STRING(20),
redemption_cod STRING(9),
redemption_tms DATETIME,
start_dat DATETIME,
Ingestion_tms DATETIME,


)
PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000));


CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_customer_meal`(
 
create_tms DATETIME,
customer_id INT64,
default_flg STRING(1),
favorite_type_cod STRING(20),
maint_tms DATETIME,
meal_nam STRING(100),
Ingestion_tms DATETIME,
 
 
)
PARTITION BY RANGE_BUCKET(customer_id,GENERATE_ARRAY(1, 1000000000, 200000));







CREATE TABLE `cdp-prd-6370.raw.temp_dpvhstcheckinfo`
(
  
  Ingestion_tms DATETIME,
  attname STRING(255),
  atttext STRING(255),
  checkid INT64,
  dateofbusiness DATETIME,
  datetimestamp DATETIME,
  dim_insight_source_key INT64,
  distkey STRING(255),
  fkemployeenumber INT64,
  fkoccasionid INT64,
  fkstoreid INT64,
  importchecksum INT64,
  last_maint_tms DATETIME,
  queueid INT64,
  tableid INT64,
  uniqueid INT64
)

PARTITION BY DATE(dateofbusiness);



/* Levelup Accomplishments */

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_accomplishments` (
id INT64,
created_at Datetime,
updated_at Datetime,
goal_id INT64,
loyalty_id INT64,
threshold_as_integer INT64,
expires_at Datetime,
goal_type STRING(255),
overtaken boolean,
terminal boolean,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime,


)
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));

/* Levelup Campaigns */

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_campaigns` (
  id INT64,
created_at Datetime,
updated_at Datetime,
opens_at Datetime,
closes_at Datetime,
value_amount INT64,
campaign_type STRING(255),
custom_name STRING(255),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime,

  )
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));

/* Levelup Credit transactions */

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_credit_transactions` (
created_at Datetime,
transaction_type STRING(255),
claim_id INT64,
gift_card_id INT64,
campaign_id INT64,
customer_id INT64,
order_id INT64,
location_id INT64,
expires_at Datetime,
value_amount INT64,
campaign_name STRING(255),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime,

  )
  PARTITION BY DATE(created_at);
/* Item Based Goal */

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_item_based_goal` (
id INT64,
created_at Datetime,
updated_at Datetime,
campaign_id INT64,
required_item_count INT64,
concept_modifier STRING(256),
concept_type STRING(256),
description STRING(256),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime

  )
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));

/* Items */
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_items` (
order_id INT64,
sku STRING(255),
name STRING(255),
quantity INT64,
standard_price_amount INT64,
charged_price_amount INT64,
children_json STRING,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime



  )
  PARTITION BY RANGE_BUCKET(order_id,GENERATE_ARRAY(1, 1000000000, 200000));


/* lOCATIONS */
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_locations` (
location_id INT64,
reference_name STRING(255),
latitude Float64,
longitude Float64,
street_address STRING(255),
extended_address STRING(255),
locality STRING(255),
region STRING(255),
postal_code STRING(255),
terminated boolean,
time_zone STRING(255),
visible boolean,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime


  );


	

/* levelup_progress_adjustments */
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_progress_adjustments` (
id INT64,
created_at Datetime,
updated_at Datetime,
user_campaign_progress_total_id INT64,
adjustment INT64,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime


  )
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));



 /* levelup_progress_contributions */

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_progress_contributions` (
id INT64,
created_at Datetime,
updated_at Datetime,
order_id INT64,
user_campaign_progress_total_id INT64,
contribution INT64,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime

  )
  
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));

 
 
 /* levelup_refunds */ 
 
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_refunds` (
order_id INT64,
refunded_at DATETIME,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime
  )
  
  PARTITION BY DATE(refunded_at);

  
 /* levelup_visit_based_goals */ 

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_visit_based_goals` (
id INT64,
created_at Datetime,
updated_at Datetime,
campaign_id INT64,
required_visit_count INT64,
concept_modifier STRING(255),
concept_type STRING(255),
description STRING(255),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime


  )
  
 PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));



 /* levelup_user_campaign_progress_totals */ 
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_user_campaign_progress_totals` (
id INT64,
created_at Datetime,
updated_at Datetime,
campaign_id INT64,
loyalty_id INT64,
total_order_contribution INT64,
total_adjustment INT64,
progress_period_type STRING(255),
current_progress INT64,
fixed_progress_period_starts_at Datetime,
fixed_progress_period_resets_at Datetime,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime




  )
   PARTITION BY RANGE_BUCKET(loyalty_id,GENERATE_ARRAY(1, 1000000000, 200000));
 

/* levelup_spend_based_goal */  
  
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_spend_based_goal` (
id INT64,
created_at Datetime,
updated_at Datetime,
campaign_id INT64,
required_spend_amount INT64,
concept_modifier STRING(255),
concept_type STRING(255),
description STRING(255),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime


  )
   PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));
 


/* purchaseable_progress_redemptions */
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_progress_redemptions` (
sl_date Datetime,
sl_user STRING(256),
created_at Datetime,
id INT64,
progress_amount INT64,
progress_reward_purchases_id INT64,
progress_source_id INT64,
progress_source_type STRING(255),
purchasable_progress_reward_id INT64,
updated_at Datetime,
Ingestion_tms Datetime


  )
  PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));



/* users */
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_user` (
loyalty_id INT64,
first_name STRING(255),
last_name STRING(255),
email STRING(255),
phone STRING(255),
registered_at Datetime,
registered_device_type STRING(255),
account_type STRING(255),
subscribed_to_emails boolean,
birthdate Datetime,
gender STRING(255),
favorite_location STRING(255),
first_order_created_at Datetime,
last_order_created_at Datetime,
number_of_visits INT64,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime



  )
  PARTITION BY RANGE_BUCKET(loyalty_id,GENERATE_ARRAY(1, 1000000000, 200000));



/* orders */
 
CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_orders` (
order_id INT64,
created_at Datetime,
loyalty_id INT64,
food_and_beverage INT64,
tax_amount INT64,
tip INT64,
location_id INT64,
street_address STRING(255),
order_source STRING(255),
reward_credit_redeemed Float64,
channel STRING(255),
business_order_id STRING(255),
order_uuid STRING(255),
state STRING(255),
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime

  )
   PARTITION BY DATE(created_at);

/*purchaseable_progress_rewards*/

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_purchasable_progress_rewards` (
id INT64,
created_at Datetime,
updated_at Datetime,
active boolean,
description STRING(255),
details STRING(255),
name STRING(255),
purchasable_until Datetime,
required_progress_amount INT64,
source_campaign_id INT64,
sl_date Datetime,
sl_user STRING(256),
Ingestion_tms Datetime,

  )
   PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));

/*progress_purchases_rewards*/

CREATE OR REPLACE TABLE `cdp-prd-6370.raw.temp_levelup_progress_rewards_purchases` (
created_at Datetime,
id INT64,
loyalty_id INT64,
purchasable_progress_reward_id INT64,
reward_id INT64,
reward_type STRING(255),
updated_at Datetime,
sl_date Datetime,
sl_user STRING,
Ingestion_tms Datetime,



  )
   PARTITION BY RANGE_BUCKET(id,GENERATE_ARRAY(1, 1000000000, 200000));



CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Click`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(128),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  LinkContent STRING(1000),
  LinkName STRING,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING,
  URL STRING(1000),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
  PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Journey`
(
  CreatedDate DATETIME,
  JourneyID STRING(255),
  JourneyName STRING(255),
  JourneyStatus STRING(255),
  LastPublishedDate DATETIME,
  ModifiedDate DATETIME,
  VersionID STRING(255),
  VersionNumber INT64,
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  CreatedFullDate String(255),
  LastPublishedFullDate String(255),
  ModifiedFullDate String(255)
);
CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Sent`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey INT64,
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate String
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Open`
(
  AccountID INT64,
  BatchID INT64,
  Domain STRING(64),
  EventDate DATETIME,
  IsUnique BOOLEAN,
  JobID INT64,
  ListID INT64,
  OYBAccountID INT64,
  SubscriberID INT64,
  SubscriberKey STRING(64),
  TriggeredSendCustomerKey STRING(255),
  TriggererSendDefinitionObjectID STRING(255),
  sl_date DATETIME,
  sl_user STRING(255),
  Ingestion_tms DATETIME,
  EventFullDate STRING
)
 PARTITION BY DATE(EventDate);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_JourneyActivity`
(
  ActivityExternalKey STRING,
  ActivityID STRING,
  ActivityName STRING,
  ActivityType STRING,
  JourneyActivityObjectID STRING,
  VersionID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME
);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_Jobs`
(
  AccountID INT64,
  AccountUserID INT64,
  BccEmail STRING,
  Category STRING,
  CharacterSet STRING,
  CreatedDate DATETIME,
  DeduplicateByEmail STRING,
  DeliveredTime DATETIME,
  DynamicEmailSubject STRING,
  EmailID STRING,
  EmailName STRING,
  EmailSendDefinition STRING,
  EmailSubject STRING,
  EventID STRING,
  FromEmail STRING,
  FromName STRING,
  IPAddress STRING,
  IsMultipart STRING,
  IsWrapped STRING,
  JobID INT64,
  JobStatus STRING,
  JobType STRING,
  ModifiedBy STRING,
  ModifiedDate DATETIME,
  OriginalSchedTime DATETIME,
  PickupTime DATETIME,
  ResolveLinksWithCurrentData STRING,
  SalesForceErrorSubscriberCount STRING,
  SalesForceTotalSubscriberCount STRING,
  SchedTime DATETIME,
  SendClassification STRING,
  SendClassificationType STRING,
  SendType STRING,
  SuppressTracking STRING,
  TestEmailAddr STRING,
  TriggeredSendCustomerKey STRING,
  TriggererSendDefinitionObjectID STRING,
  sl_date DATETIME,
  sl_user STRING,
  Ingestion_tms DATETIME,
  CreatedFullDate STRING,
DeliveredFullTime STRING,
ModifiedFullDate STRING,
OriginalFullSchedTime STRING,
PickupFullTime STRING,
SchedFullTime STRING
)
 PARTITION BY DATE(DeliveredTime);

CREATE or REPLACE TABLE `cdp-prd-6370.raw.temp_SFMC_MobilePushTrackingDetails`
(
AndroidMediaUrl STRING(1000),
AppName STRING(255),
Campaigns STRING(255),
ContactKey STRING(255),
DateTimeSend DATETIME,
DeviceId STRING(255),
Format STRING(255),
GeofenceName STRING(255),
InboxMessageDownloaded STRING(1000),
IosMediaUrl STRING(1000),
MediaAlt STRING(1000),
MessageContent STRING(1000),
MessageID STRING(1000),
MessageName STRING(1000),
MessageOpened STRING(1000),
OpenDate DATETIME,
PageName STRING(255),
Platform STRING(255),
PushJobId STRING(255),
RequestId STRING(255),
ServiceResponse STRING(255),
Status STRING(255),
SystemToken STRING(255),
Template STRING(255),
TimeInApp DATETIME,
DateTimeSendFull STRING(255),
OpenDateFull STRING(255),
TimeInAppFull STRING(255)

)
 PARTITION BY DATE(DateTimeSend);
