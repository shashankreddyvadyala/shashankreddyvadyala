CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.raw.temp_idr_customer`
(
  DGTL_CUST_ID INT64  OPTIONS( description="Digital customer ID"),
  FN_cleaned STRING  OPTIONS( description="FN_cleaned"),
  LN_cleaned STRING  OPTIONS( description="LN_cleaned"),
  FIRST_NAME STRING  OPTIONS( description="First Name(PII)"),
  LAST_NAME STRING  OPTIONS( description="Last Name(PII)"),
  EMAIL STRING  OPTIONS( description="Email(PII)"),
  EMAIL_REGEX STRING  OPTIONS( description="Regex applied email"),
  EMAIL_SUBSTRING STRING  OPTIONS( description="Email substring"),
  BIRTH_MONTH INT64  OPTIONS( description="Birth Month(PII)"),
  BIRTH_DAY INT64  OPTIONS( description="Birth Day(PII)"),
  POSTAL_CODE STRING  OPTIONS( description="Postal Code"),
  CC_POSTAL_CODES ARRAY<STRING>  OPTIONS( description="Array of postal codes tied to credit cards that the customer has added to his/her digital payment profile(PII)"),
  FAVORITE_LOCATION STRING  OPTIONS( description="favorite location"),
  VISITED_SITE_NUMS ARRAY<INT64>  OPTIONS( description="Array of restaurant numbers where customer has made purchases"),
  DEVICE_ARRAY ARRAY<STRING>  OPTIONS( description="Array of devices customer used to make a purchase")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.raw.temp_idr_cust_dev_match`
(
  dgtl_cust_id_a INT64  OPTIONS( description="Digital customer ID"),
  dgtl_cust_id_b INT64  OPTIONS( description="Digital customer ID")
);

CREATE TABLE IF NOT EXISTS `cdp-dev-bdfa.curated.t_fact_dgtl_cust_link`
(
  dgtl_cust_id INT64  OPTIONS( description="Digital customer ID"),
  dgtl_cust_link_id INT64  OPTIONS( description="Digital customer link ID")
);

CREATE SCHEMA IF NOT EXISTS 
  `cdp-dev-bdfa.cdp_audiences` OPTIONS( description="cdp audiences Layer" );


CREATE TABLE IF NOT EXISTS
  `cdp-dev-bdfa.cdp_audiences.t_mdl_breakfast_audience_checkpoints` (
    MODEL_VERSION INT64 OPTIONS(description="Version of the model"),
    MODEL_PATH STRING OPTIONS(description="Path of the parameter file in GCS"),
    TRAINING_DATASET_SIZE INT64 OPTIONS(description="Size of the training data"),
    AUC FLOAT64 OPTIONS(description="Model area under the curve"),
    CREATED_TMS TIMESTAMP OPTIONS(description="Model creation timestamp")
 ) ;

CREATE TABLE IF NOT EXISTS 

  `cdp-dev-bdfa.cdp_audiences.cdp_breakfast_audience` (

    UUID STRING OPTIONS(description="Customer's unique ID") ,

    SF_CONTACT_ID STRING OPTIONS(description="Salesforce Marketing Cloud ID"),

    CUSTOMER_TYPE STRING OPTIONS(description="Breakfast or Non-breakfast customer"),

    PROB_BREAKFAST FLOAT64 OPTIONS(description="Probability of being a breakfast customer"),

    CREATED_DATE DATE OPTIONS(description="Audience creation date")

  ) PARTITION BY CREATED_DATE;


