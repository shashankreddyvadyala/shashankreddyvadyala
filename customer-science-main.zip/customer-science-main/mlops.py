from google.cloud import bigquery,storage
import pandas as pd
import os
import google.auth
import google.auth.impersonated_credentials
import argparse
import io
from datetime import datetime

class Mlops:
    def __init__(self,sa_ml_prd:str,sa_cdp:str,cdp_project_id:str,bqtable:str):
        
        self.target_scopes = [
            "https://www.googleapis.com/auth/bigquery",
            "https://www.googleapis.com/auth/devstorage.full_control"
            ]


        self.creds, self.pid = google.auth.default()
        print(f"Obtained default credentials for the project {self.pid}")
        
        
        self.sa_ml_prd_creds = google.auth.impersonated_credentials.Credentials(
                source_credentials=self.creds,
                target_principal=sa_ml_prd,
                target_scopes=self.target_scopes,
                )
        
                
        self.sa_cdp = google.auth.impersonated_credentials.Credentials(
                source_credentials=self.creds,
                target_principal=sa_cdp,
                target_scopes=self.target_scopes,
                )
        
        self.bqtable=bqtable
        self.cdp_ml_prd_id="cdp-ml-prd-ba23"
        self.cdp_project_id=cdp_project_id
        self.cdp_bucket_id=f"{'-'.join(self.cdp_project_id.split('-')[:2])}-ai-ml"
        
        self.model_info=self.model_local_path=None

        
    def get_latest_model(self):
        
        print(f"Accessing {self.cdp_ml_prd_id}.{self.bqtable}")
        client = bigquery.Client(project=self.cdp_ml_prd_id,credentials=self.sa_ml_prd_creds) 
                
        self.model_info=client.query(f"""SELECT * FROM `{self.bqtable}` 
                                          WHERE MODEL_VERSION=(SELECT max(MODEL_VERSION) FROM `{self.bqtable}`)""").to_dataframe()        
        self.model_info=self.model_info.iloc[0,:]  # To handle duplicates
        
        print(f"Accessing {self.cdp_ml_prd_id} GCS")
        bucket=storage.Client(project=self.cdp_ml_prd_id,credentials=self.sa_ml_prd_creds).bucket(self.model_info["MODEL_PATH"].split("/")[2])
                
        path_=self.model_info['MODEL_PATH'].split("/")[3:]
        path_='/'.join(map(str, path_))
        blob = bucket.blob(path_)
        print(f"Downloading blob:{blob.name}")

        self.model_local_path =self.model_info['MODEL_PATH'].split("/")[-1]
        print("Destination_path",self.model_local_path)
        blob.download_to_filename(self.model_local_path)
        
        client.close()
        
    
    def deploy(self):
        
        try:
        
            self.get_latest_model()

            client = bigquery.Client(project=self.cdp_project_id,credentials=self.sa_cdp) 

            ## Changing the project ID in model path URL to CDP
            self.model_info['MODEL_PATH']=self.model_info['MODEL_PATH'].split("/")
            self.model_info['MODEL_PATH'][2]=self.cdp_bucket_id
            self.model_info['MODEL_PATH']="/".join(self.model_info['MODEL_PATH'])

            print(f"Uploading model to {self.model_info['MODEL_PATH']}")
            bucket = storage.Client(project=self.cdp_project_id,credentials=self.sa_cdp).bucket(self.cdp_bucket_id)
            gcs_path=self.model_info['MODEL_PATH'].split("/")[3:]
            gcs_path='/'.join(map(str, gcs_path))
            blob = bucket.blob(gcs_path)
            blob.upload_from_filename(self.model_local_path)

            print(f"Accessing {self.cdp_project_id}.{self.bqtable}")

            print(f"Getting the table schema")
            dataset_ref = client.dataset(self.bqtable.split(".")[0], project=self.cdp_project_id)
            table_ref = dataset_ref.table(self.bqtable.split(".")[1])
            table = client.get_table(table_ref)

            table_schema = io.StringIO("")
            client.schema_to_json(table.schema, table_schema)
            table_schema=eval(table_schema.getvalue())

            print("Building the record")
            record={}
            for i in table_schema:
                if i['type']=="INTEGER":
                    record[i['name']]= int(self.model_info[i['name']])
                elif i['type']=="FLOAT":
                    record[i['name']]= float(self.model_info[i['name']])
                elif i['type']=="STRING":
                    record[i['name']]= str(self.model_info[i['name']])
                elif i['type']=="TIMESTAMP":
                    f = '%Y-%m-%d %H:%M:%S'
                    record[i['name']]= self.model_info[i['name']].strftime(f)
            

            # Checking if the same model version exist
            check=client.query(f"""SELECT count(*) as length FROM {self.bqtable} WHERE MODEL_VERSION={int(self.model_info['MODEL_VERSION'])}""").to_dataframe()
            if check['length'].values[0]>=1:     
                print("Found existing Model version, Updating the record")

                update_sql=f"""
                            update {self.bqtable}
                            SET
                        """
                for i in record.keys():
                    if "/" in str(record[i]) or i=='CREATED_TMS':
                        update_sql+=i+f"='{record[i]}', "
                    else:
                        update_sql+=i+f"={record[i]}, "
                
                update_sql=f"{update_sql[:-2]} where MODEL_VERSION={int(self.model_info['MODEL_VERSION'])}"
                
                client.query(update_sql).to_dataframe()

            else:
                print("Inserting record")

                insert_sql=f"""
                            insert into {self.bqtable} VALUES(

                        """
                for i in record.keys():
                    if "/" in str(record[i]) or i=='CREATED_TMS':
                        insert_sql+=f"'{record[i]}', "
                    else:
                        insert_sql+=f"{record[i]}, "

                insert_sql=f"{insert_sql[:-2]})"
                client.query(insert_sql).to_dataframe()

            
            print("Model Checkpoints Saved")
            print("Deployment Successful")
        except Exception as e:
            print(e)
            

if __name__=="__main__":
    
    
    parser = argparse.ArgumentParser()

    # Argument Parser
    parser.add_argument('--sa_cdp', type=str, required=True, help='CDP Service account') 
    parser.add_argument('--sa_ml_prd', type=str, required=True,help='CDP ML Prod Service account')
    parser.add_argument('--cdp_project_id', type=str, required=True,help='CDP project ID')
    parser.add_argument('--bqtable', type=str, required=True,help='Source BQ table name to retrieve checkpoints record Eg:cdp_audiences.t_mdl_breakfast_audience_checkpoints')

    args = parser.parse_args()
    
    
    Mlops(args.sa_ml_prd,args.sa_cdp,args.cdp_project_id,args.bqtable).deploy()

    
