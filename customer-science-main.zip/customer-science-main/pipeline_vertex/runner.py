#CLTV Model Imports
from models.cltv_model.trainer import pipeline as cltv_training_pipeline
from models.cltv_model.inference import pipeline as cltv_infernce_pipeline

# #kmeans Model Imports
from models.kmeans_model.trainer import pipeline as kmeans_training_pipeline
from models.kmeans_model.inference import pipeline as kmeans_inference_pipeline

# Breakfast Affinity Model Imports
from models.breakfast_affinity_model.inference import pipeline as breakfast_affinity_model

from kfp.v2 import compiler
from google.cloud import aiplatform
from datetime import datetime
import argparse


TIMESTAMP = datetime.now().strftime("%Y%m%d%H%M%S")
parser = argparse.ArgumentParser()

# Add an argument
parser.add_argument('--model', type=str, required=True)
parser.add_argument('--mode', type=str, required=True)

SERVICE_ACCOUNT="sa-cdp-ai-ml@cdp-dev-bdfa.iam.gserviceaccount.com"
PROJECT_ID='cdp-dev-bdfa'
BUCKET_ID=f"{'-'.join(PROJECT_ID.split('-')[:2])}-ai-ml"
ROOT_PATH=f"gs://{BUCKET_ID}/artifacts"


if __name__=="__main__":
    args = parser.parse_args()
    
    # If block for CLTV model training and inference
    if args.model=='cltv':
        if args.mode=='training':
            compiler.Compiler().compile(pipeline_func=cltv_training_pipeline, package_path="./artifacts/cltv_training.json")
            
            job = aiplatform.PipelineJob(display_name="cltv-training-lifetime-pipeline",template_path="./artifacts/cltv_training.json",
                                        job_id="cltv-training-lifetime-pipeline-{0}".format(TIMESTAMP),
                                         pipeline_root=ROOT_PATH, parameter_values={'project_id': PROJECT_ID})
            
            job.submit(service_account=SERVICE_ACCOUNT)
            
            
        elif args.mode=="inference":            
            compiler.Compiler().compile(pipeline_func=cltv_infernce_pipeline, package_path="./artifacts/cltv_inference.json")
            
            job = aiplatform.PipelineJob(display_name="cltv-inference-lifetime-pipeline",template_path="./artifacts/cltv_inference.json",
                                        job_id="cltv-inference-lifetime-pipeline-{0}".format(TIMESTAMP),
                                        pipeline_root=ROOT_PATH, parameter_values={'project_id': PROJECT_ID,'bucket_id':BUCKET_ID})
            
            job.submit(service_account=SERVICE_ACCOUNT)
    
    # If block for kmeans model training and inference
    elif args.model=='kmeans':
        if args.mode=='training':
            compiler.Compiler().compile(pipeline_func=kmeans_training_pipeline, package_path="./artifacts/kmeans_training.json")
            
            job = aiplatform.PipelineJob(display_name="kmeans-training-pipeline",template_path="./artifacts/kmeans_training.json",
                                        job_id="kmeans-training-pipeline-{0}".format(TIMESTAMP),
                                        pipeline_root=ROOT_PATH, parameter_values={'project_id': PROJECT_ID})
            
            job.submit(service_account=SERVICE_ACCOUNT)
        elif args.mode=="inference":
            compiler.Compiler().compile(pipeline_func=kmeans_inference_pipeline, package_path="./artifacts/kmeans_inference.json")
            
            job = aiplatform.PipelineJob(display_name="kmeans-inference-pipeline",template_path="./artifacts/kmeans_inference.json",
                                        job_id="kmeans-inference-pipeline-{0}".format(TIMESTAMP),
                                        pipeline_root=ROOT_PATH, parameter_values={'project_id': PROJECT_ID,'bucket_id':BUCKET_ID})
            
            job.submit(service_account=SERVICE_ACCOUNT)
    
        # If block for kmeans model training and inference
    elif args.model=='breakfast_affinity':
        if args.mode=='inference':
            compiler.Compiler().compile(pipeline_func=breakfast_affinity_model, package_path="./artifacts/breakfast_affinity_inference.json")
            
            job = aiplatform.PipelineJob(display_name="breakfast-affinity-inference-pipeline",template_path="./artifacts/breakfast_affinity_inference.json",
                                        job_id="breakfast-affinity-inference-pipeline-{0}".format(TIMESTAMP),
                                        pipeline_root=ROOT_PATH,  parameter_values={'project_id': PROJECT_ID,'bucket_id':BUCKET_ID})
            
            job.submit(service_account=SERVICE_ACCOUNT)
            