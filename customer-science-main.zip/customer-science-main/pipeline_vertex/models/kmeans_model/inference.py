################################################################### Module Imports ################################################################################
from models.kmeans_model.constants import (CHECKPOINTS_TABLE,CLTV_PREDICTIONS_TABLE,
                                          BATCH_SIZE,PREDICTIONS_TABLE,BASE_IMAGE,PREDICTION_TABLE_SCHEMA)
import pandas as pd
from kfp.v2.dsl import component,pipeline,Dataset,Output,Input,Model,Condition
from typing import NamedTuple

################################################################## Code Description ################################################################################

"""
The code build using kubeflow pipeline, which helps vertex AI to run inference in a serverless manner.

What is a pipeline?
A pipeline is a description of an ML workflow, including all of the components in the workflow and how they combine in the form of a graph.The pipeline includes the definition of the inputs (parameters) required to run the pipeline and the inputs and outputs of each component.

Components Descriptions: 
-----------------------
    
    - data_check
        since lower envrioments dont have sufficient data to train the CLTV model.
        
        Pseudo Code:
            - Intialize the bigquery client
            - check the frequency is greater than 1 in RFM table
            - If length of the dataframe is less than equal to 1
                - set Not enough data in cltv prediction table, Skipping Inference
            - If length of the dataframe is not less than equal to 1
                - set Data found in cltv prediction table, Starting inference
            - Clean the previous prediction
                
            
    - get_model Component:
            This component allows us to get the latest trained model.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Get the latest model version number from checkpoints table using max(model_no)
            - Download the latest model from GCS, and save it in a path where vertex pipeline can access.
    
    - prepare_batches Component:
            This component allows us to prepare batches for batchwise predictions.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Get total number of distinct customers from RFM table
            - Get the batch size from constants
            - Loop through the total number of distinct customers
            - Create a dictionary and append the limit and offset to against a batch
            
    - inference Component:
                This components allows us to run inference on the provided batch and computes the required KPI's
            
         Pseudo Code:
            -  Intialize the bigquery client
            -  Intialize kmeans model and  standard scalers
            -  Get the batch data
            -  compute kpi's
            - Saving the computed KPI's to prediction table using pandas gbq
                  
    - Pipeline Component:
                This component will help us to stitch data_check, get_model, prepare_batches and inference components together. 
                
        Pseudo Code:
            -  Intialize data_check component
            -  Check the status from data_check component
            -  Intialize get_model component
            -  Intialize prepare_batches component
            -  Intialize inference component 
"""

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_data_check.yaml",packages_to_install=["pandas-gbq==0.17.4"])
def data_check(project_id:str,cltv_predictions_table:str,prediction_table:str,prediction_table_schema:list)-> NamedTuple(
    "Outputs",
    [
       ("data_check_status",str)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    cltv_predictions_table : str
        CLTV predictions table ID
        
    prediction_table : str
        Model prediction table
        
    prediction_table_schema : list
        Schema for model prediction table

    """
    
    from google.cloud import bigquery,storage
    import pandas as pd
    import pandas_gbq
    import datetime

    client = bigquery.Client(project=project_id)   
    
    df=client.query( f"""select count(*) as length from  `{cltv_predictions_table}` """).to_dataframe()
    if int(df['length'].values[0])<=1:
        data_check_status="Not enough data in cltv prediction table, Skipping Inference"
    else:
        data_check_status="Data found in cltv prediction table, Starting inference"
        
    ################# Cleaning previous prediction #################
    df=pd.DataFrame(columns=['CUSTOMER_ID','CLUSTER_ID','CLTV_SEGMENT','CREATED_TMS'])
    pandas_gbq.to_gbq(df, prediction_table, project_id=project_id,if_exists="replace",table_schema=prediction_table_schema)
    
    return (data_check_status,)



@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_get_model.yaml")
def get_model(project_name:str,checkpoints_table:str,bucket_id:str,
                          kmeans_model_path:Output[Model],scaler_model_path:Output[Model])-> NamedTuple(
    "Outputs",
    [
       ("model_info",list)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    checkpoints_table : str
        Model checkpoints table
        
    bucket_id : str
        GCS bucket id to save and retrieve the model 
        
    kmeans_model_path:Output[Model]
        Kmeans Model GCS path
    
    scaler_model_path:Output[Model]
        Standard Scalar GCS path

    """
    
    
    from google.cloud import bigquery,storage

    
    client = bigquery.Client(project=project_name)   
    # Get the latest model
    model_info=client.query(f"""SELECT MODEL_NO, MODEL_PATH,CLUSTER_ID,CLTV_SEGMENT FROM `{checkpoints_table}` 
                                          WHERE MODEL_NO=(SELECT max(MODEL_NO) FROM `{checkpoints_table}`)""").to_dataframe()
    
    model_number=int(model_info['MODEL_NO'].values[0])

    bucket=storage.Client(project=project_name).bucket(bucket_id)
    
    path_=model_info['MODEL_PATH'].values[0][0].split("/")[3:]
    path_='/'.join(map(str, path_))
    blob = bucket.blob(path_)
    print(f"Downloading blob:{blob.name}")

    destination_uri = f"{kmeans_model_path.path}_{model_number}.joblib"
    print("Destination_path",destination_uri)
    blob.download_to_filename(destination_uri)
    
    path_=model_info['MODEL_PATH'].values[0][1].split("/")[3:]
    path_='/'.join(map(str, path_))
    blob = bucket.blob(path_)
    print(f"Downloading blob:{blob.name}")
    
    destination_uri = f"{scaler_model_path.path}_{model_number}.joblib"
    print("Destination_path",destination_uri)
    blob.download_to_filename(destination_uri)
    
    return (eval(model_info.to_json(orient='records')),)

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_get_batches.yaml")
def prepare_batches(project_name:str,batch_size:int,cltv_predictions_table:str)-> NamedTuple(
    "Outputs",
    [
       ("batches",dict)
    ],):
    
                    
    """
    Parameters
    ----------
    project_name : str
        GCP project ID 
        
    batch_size : int
        Number rows in a batch
        
    cltv_predictions_table : str
        Bigquery Cltv predictions table ID.

    """    
    
    print("Preparing Data in Batches")
    
    from google.cloud import bigquery
    
    client = bigquery.Client(project=project_name)   

    total_rows=client.query(f"SELECT count(distinct CUSTOMER_ID) as total_row  FROM `{cltv_predictions_table}`").to_dataframe().values[0][0]

    batches={}

    for index,offset  in enumerate(range(0,total_rows,batch_size)):
        batches[f"batch{index}"]={'limit':batch_size,'offset':offset}
        
    return (batches,)


@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_get_model.yaml",packages_to_install=["pandas-gbq==0.17.4"])
def inference(project_id:str,batches:dict,model_info:list,kmeans_model_path:Input[Model],
              scaler_model_path:Input[Model],prediction_table:str,cltv_prediction_table:str):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    batches : dict
        The batches to run inference
        
    model_info : list
        Latest  trained Model info from checkpoints table 
        
    kmeans_model_path:Input[Model]
        Kmeans model GCS path
    
    scaler_model_path:Input[Model]
        Standard Scaler GCS path
    
    prediction_table:str
        Bigquery prediction table ID
    
    cltv_prediction_table:str
        Bigquery CLTV prediction table ID

    """
    
    import joblib
    import pandas as pd
    import pandas_gbq
    import datetime
    from google.cloud import bigquery
                    
    model_info=pd.DataFrame(model_info)
    model_no=int(model_info['MODEL_NO'].values[0])
    
    print("Loading Kmeans Model")
    kmeans=joblib.load(f"{kmeans_model_path.path}_{model_no}.joblib")
    
    print("Loading scaler")
    scaler=joblib.load(f"{scaler_model_path.path}_{model_no}.joblib")
    
    client = bigquery.Client(project=project_id)
    
    def get_data_batch(limit:int, offset:int) -> pd.DataFrame:
    
        print("Fetching Data")

        sql_query = (f"""select FUTURE_12MO_PURCHASE,CUSTOMER_ID from `{cltv_prediction_table}` limit {limit} offset {offset}""")

        df = client.query(sql_query).to_dataframe().set_index('CUSTOMER_ID')

        return df
            
    def compute_kpi(data:pd.DataFrame) -> pd.DataFrame:
        
        scaled_features=scaler.transform(data)
        
        data['CLUSTER_ID']=kmeans.predict(scaled_features)
        
        data=pd.merge(data.reset_index(),model_info.drop(['MODEL_NO','MODEL_PATH'],axis=1),left_on='CLUSTER_ID',right_on='CLUSTER_ID')
        
        return data

    def save_metric_bq(data:pd.DataFrame):
        print("Saving computed KPI's to bigquery")
        
        table_id=f"{prediction_table}"
        pandas_gbq.to_gbq(data.drop(['FUTURE_12MO_PURCHASE'],axis=1), table_id, project_id=project_id,if_exists="append")
    
    def batch_prediction():
        
        for key,value in batches.items():

            #Loading the data
            df=get_data_batch(value['limit'],value['offset'])  
            
            #computing KPI's for next 12 months
            df=compute_kpi(df)
            
            #adding timestamp to the dataframe
            f = '%Y-%m-%d %H:%M:%S'
            timestamp_now = datetime.datetime.now().strftime(f)
            df['CREATED_TMS']=timestamp_now
            
            save_metric_bq(df)
        print("Batch Prediction Completed")
        
    batch_prediction()

        
@pipeline(name="kmeans-inference")            
def pipeline(project_id:str,bucket_id:str):  
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    bucket_id:str
        GCP bucket ID
    
    """
    
    data_check_status=(data_check(project_id,CLTV_PREDICTIONS_TABLE,PREDICTIONS_TABLE,PREDICTION_TABLE_SCHEMA)).set_caching_options(False)
    
    with Condition(data_check_status.outputs["data_check_status"]=="Data found in cltv prediction table, Starting inference", name="Data-check"):
        
        checkpoints=(get_model(project_id,CHECKPOINTS_TABLE,bucket_id)).set_caching_options(False)

        batches=(prepare_batches(project_id,BATCH_SIZE,CLTV_PREDICTIONS_TABLE)).set_caching_options(False)

        (inference(project_id,batches.outputs['batches'],checkpoints.outputs['model_info'],checkpoints.outputs["kmeans_model_path"],
                  checkpoints.outputs["scaler_model_path"],PREDICTIONS_TABLE,CLTV_PREDICTIONS_TABLE)).set_caching_options(False)