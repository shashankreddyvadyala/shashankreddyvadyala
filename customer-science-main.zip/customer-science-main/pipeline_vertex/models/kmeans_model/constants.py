CLTV_PREDICTIONS_TABLE='curated.t_mdl_cltv_predictions'
PREDICTIONS_TABLE='curated.t_mdl_kmeans_predictions'
CHECKPOINTS_TABLE='curated.t_mdl_kmeans_checkpoints'
BATCH_SIZE=10000000
SELECTED_FEATURES=['FUTURE_12MO_PURCHASE']
KMEANS_KWARGS = {
     "init": "random",
     "n_init": 10,
     "max_iter": 300,
    "random_state": 42,
}
BASE_IMAGE="gcr.io/deeplearning-platform-release/sklearn-cpu"
NUMBER_CLUSTER=3
CLUSTER_LABELS=['Low Engaged','Medium Engaged','High Engaged']
PREDICTION_TABLE_SCHEMA=[
    
    {'name': 'CUSTOMER_ID', 'type': 'INTEGER'},
    {'name': 'CLUSTER_ID', 'type': 'INTEGER'},
    {'name': 'CLTV_SEGMENT', 'type': 'STRING'},
    {'name': 'CREATED_TMS', 'type': 'STRING'}

]