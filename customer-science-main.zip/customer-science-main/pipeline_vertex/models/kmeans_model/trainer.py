################################################################### Module Imports ################################################################################
from models.kmeans_model.constants import (SELECTED_FEATURES,CHECKPOINTS_TABLE,
                                           KMEANS_KWARGS,CLUSTER_LABELS,
                                           BASE_IMAGE,CLTV_PREDICTIONS_TABLE,NUMBER_CLUSTER)

from kfp.v2.dsl import component,pipeline,Dataset,Output,Input,Model,Condition
from typing import NamedTuple
import pandas as pd

################################################################## Code Description ################################################################################
"""
The code build using kubeflow pipeline, which helps vertex AI to run training in a serverless manner.

What is a pipeline?
A pipeline is a description of an ML workflow, including all of the components in the workflow and how they combine in the form of a graph.The pipeline includes the definition of the inputs (parameters) required to run the pipeline and the inputs and outputs of each component.

Components Descriptions: 
-----------------------
    
    - data_check
        since lower envrioments dont have sufficient data to train the CLTV model.
        
        Pseudo Code:
            - Intialize the bigquery client
            - check the length of the cltv_prediction table
            - If length of the dataframe is less than equal to 2
                - set Not enough data in cltv prediction table, Skipping Training
            - If length of the dataframe is not less than equal to 2
                - set Data found in cltv prediction table, Starting Training                
            
    - Train Component:
            This component allows us to train the kmeans model
            
        Pseudo Code:
            - Intialize the bigquery client
            - Intialize kmeans from sklearn
            - Load the data using get_train_data() from cltv_prediction table.
            - Trasnform the data using sklearn standard scalar
            - Get the model version number                    
            - Train kmeans model
            - Interpret kmeans predictions using Decision tree.
            - Generate rules based on kmeans predictions
            - Map cluster to a given segments such as high,mid and low based on centriods value
            - Saving the model to GCS
    
    - Save Checkpoints Component:
                This components allows us to checkpoint our trained model in BQ under checkpoints table.
            
         Pseudo Code:
            -  Intialize the bigquery client
            -  prepare the data in json format
            -  using insert_rows_json() to save the checkpoints in BQ table.
            -  If errors:
                  Raise "Encountered erros while processing"
                  
    - Pipeline Component:
                This component will help us to stitch data_check, train,  and save checkpoints components together. 
                
        Pseudo Code:
            -  Intialize data_check component
            -  Check the status from data_check component
            -  Intialize the train component
            -  Intialize the Save Checkpoints component
"""

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_data_check.yaml")
def data_check(project_id:str,cltv_predictions_table:str)-> NamedTuple(
    "Outputs",
    [
       ("data_check_status",str)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    cltv_predictions_table : str
        CLTV prediction table ID

    """
    
    from google.cloud import bigquery,storage
    import pandas as pd
    import datetime

    client = bigquery.Client(project=project_id)   
    
    df=client.query( f"""select count(*) as length from  `{cltv_predictions_table}` """).to_dataframe()
    if int(df['length'].values[0])<=2:
        data_check_status="Not enough data in cltv prediction table, Skipping Training"
    else:
        data_check_status="Data found in cltv prediction table, Starting Training"
    
    return (data_check_status,)


@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_trainer.yaml")
def train(project_id:str,cltv_predictions_table:str,number_cluster:int,
          kmeans_kwargs:dict,selected_features:list,checkpoints_table:str,cluster_labels:list,
         scaler_model_path:Output[Model],kmeans_model_path:Output[Model])-> NamedTuple("Outputs",
                                                                                [
                                                                                    ("model_metric_data", list),
                                                                                    ("model_version_number",int),
                                                                                    ("train_status",str)
                                                                                ],):
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    cltv_predictions_table : str
        CLTV prediction table ID
        
    number_cluster:int
        kmeans cluster size(Default:3)
    
    kmeans_kwargs:dict
        kmeans default arguments
    
    selected_features:list
        selected features to be passed during kmeans model training
    
    checkpoints_table:str
        kmeans checkpoints table ID
    
    cluster_labels:list
        clusters mapped with a defined set of labels. such as low, mid and high
        
     scaler_model_path:Output[Model]
         Standard scaler .pkl GCS path
     
     kmeans_model_path:Output[Model]
         kmeans model .pkl GCS path

    """

    ################################ Required Imports ##########################################
    from google.cloud import bigquery,storage
    from sklearn.cluster import KMeans
    from sklearn.metrics import silhouette_score 
    from sklearn.preprocessing import StandardScaler
    from sklearn.tree import _tree, DecisionTreeClassifier
    import joblib
    import pandas as pd
    import datetime

    
    ########################## Configs ########################################################
    client = bigquery.Client(project=project_id)
    scaler = StandardScaler()
    kmeans = KMeans(n_clusters=number_cluster, **kmeans_kwargs)

    
    ####################### Data Loader ##########################################################
    def get_train_data() -> pd.DataFrame:
    
        print("Fetching Training Data")

        sql_query = (f"""SELECT FUTURE_12MO_PURCHASE,Count(CUSTOMER_ID) as SEGMENTS FROM `{cltv_predictions_table}` GROUP BY FUTURE_12MO_PURCHASE""")

        df = client.query(sql_query).to_dataframe()

        return df
    
    ################# Recursive Decision Tree to Extract Rules #####################################
    def get_class_rules(tree: DecisionTreeClassifier, feature_names: list) -> dict:
        inner_tree: _tree.Tree = tree.tree_
        classes = tree.classes_
        class_rules_dict = dict()

        def tree_dfs(node_id=0, current_rule=[]):
            # feature[i] holds the feature to split on, for the internal node i.
            split_feature = inner_tree.feature[node_id]
            if split_feature != _tree.TREE_UNDEFINED: # internal node
                name = feature_names[split_feature]
                threshold = inner_tree.threshold[node_id]
                # left child
                left_rule = current_rule + [{name+"_rule":f"<= {threshold}"}]
                tree_dfs(inner_tree.children_left[node_id], left_rule)
                # right child
                right_rule = current_rule + [{name+"_rule":f"> {threshold}"}]
                tree_dfs(inner_tree.children_right[node_id], right_rule)
            else: # leaf
                dist = inner_tree.value[node_id][0]
                dist = dist/dist.sum()
                max_idx = dist.argmax()
                if len(current_rule) == 0:
                    rule_string = ["ALL"]
                else:
                    rule_string = current_rule
                # register new rule to dictionary
                selected_class = classes[max_idx]
                class_probability = dist[max_idx]
                class_rules = class_rules_dict.get(selected_class, [])
                print(rule_string)
                class_rules.append(rule_string+ [{"CONCENTRATION":class_probability}])
                class_rules_dict[selected_class] = class_rules
    
        tree_dfs() # start from root, node_id = 0
        return class_rules_dict
    
    ######################### Interpreting cluster result by fitting a decision tree #############################
    def interpret_cluster_results(data: pd.DataFrame, clusters, min_samples_leaf=50, pruning_level=0.01) -> pd.DataFrame:
        # Create Model
        tree = DecisionTreeClassifier(min_samples_leaf=min_samples_leaf, ccp_alpha=pruning_level)
        tree.fit(data, clusters)

        # Generate Report
        feature_names = data.columns
        class_rule_dict = get_class_rules(tree, feature_names)
        rules_df = pd.DataFrame(columns=data.columns.to_series().add_suffix('_rule').index.tolist()+['CONCENTRATION','CLUSTER_ID'])
        report_class_list=[]
        for class_name in class_rule_dict.keys():
            rule_list = class_rule_dict[class_name]
            combined_string = ""
            temp={}
            for rule in rule_list:
                for value_ in rule:
                    if value_!='ALL':
                        temp.update(value_)
                temp['CLUSTER_ID']=class_name
                rules_df=pd.concat([rules_df,pd.DataFrame([temp])])

        cluster_instance_df = pd.Series(clusters).value_counts().reset_index()
        cluster_instance_df.columns = ['CLUSTER_ID', 'INSTANCE_COUNT']
        # report_df = pd.DataFrame(report_class_list, columns=['class_name', 'rule_list'])
        report_df = pd.merge(cluster_instance_df, rules_df, on='CLUSTER_ID', how='left')
        report_df=report_df.drop_duplicates(['CLUSTER_ID'])
        return report_df
            
     
    ######################### Getting the train data and scaling the data using scaler #############################
    train_data = get_train_data()
    
    if len(train_data) <=1:
        train_status="Not enough data in cltv prediction table to train the model,Skipping Training"
        return ([],0,train_status)
    
    scaled_train_data= scaler.fit_transform(train_data.loc[:,selected_features])

    # Model Version, Get the latest model Number
    model_version_number=client.query(f"SELECT max(MODEL_NO) FROM `{checkpoints_table}`").to_dataframe()
    if model_version_number.isna().values[0]:
        model_version_number=1
    else:
        model_version_number+=1
        model_version_number=int(model_version_number.values[0][0])
        
    ######################### Kmeans  Training ######################################    
    kmeans_cluster=kmeans.fit_predict(scaled_train_data,sample_weight=train_data['SEGMENTS'])
    score = silhouette_score(scaled_train_data, kmeans.labels_).round(2)

    print(f"Number of Cluster:{number_cluster}, Score:{score}")
    
    ######################## Interpreting the cluster results ###################################
    model_metric_data=interpret_cluster_results(train_data.drop(['SEGMENTS'],axis=1),kmeans_cluster).fillna(0)
    #Appending model params to model checkpoints table
    f = '%Y-%m-%d %H:%M:%S'
    timestamp_now = datetime.datetime.now().strftime(f)
    model_metric_data['CREATED_TMS']=timestamp_now
    model_metric_data['MODEL_NO']=model_version_number

    ######################### Mapping Clusters with label names #################################
    array_=pd.DataFrame(scaler.inverse_transform(kmeans.cluster_centers_),columns=['FUTURE_12MO_PURCHASE_MEAN'])
    array_['multiplier']= array_['FUTURE_12MO_PURCHASE_MEAN']
    array_['CLUSTER_ID']=array_.index.values
    array_['CLTV_SEGMENT']=pd.qcut(array_['multiplier'],3,labels=cluster_labels)
    model_metric_data['RULES']='FUTURE_12MO_PURCHASE:'+model_metric_data['FUTURE_12MO_PURCHASE_rule'].astype(str)
    model_metric_data=pd.merge(model_metric_data.drop(['FUTURE_12MO_PURCHASE_rule'],axis=1),
                               array_.drop(['multiplier'],axis=1),left_on='CLUSTER_ID',right_on="CLUSTER_ID")
    model_metric_data['CONCENTRATION']=pd.to_numeric(model_metric_data['CONCENTRATION'])
    
    model_metric_data['TRAINING_DATASET_SIZE']=train_data['SEGMENTS'].sum()
    
    model_metric_data=eval(model_metric_data.to_json(orient='records'))
    
    ########################## Saving model to GCS ################################################
    kmeans_path=f"{kmeans_model_path.path}_{model_version_number}.joblib"
    scalar_path=f"{scaler_model_path.path}_{model_version_number}.joblib"

    joblib.dump(kmeans,kmeans_path)
    joblib.dump(scaler,scalar_path)
    
    return (model_metric_data,model_version_number,"Completed")

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/kmeans_save_checkpoints.yaml")
def save_model_checkpoints_bq(project_id:str,checkpoints_table:str,kmeans_model_path:Input[Model],
                              scaler_model_path:Input[Model],model_metric_data:list,model_version_number:int):
        
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    checkpoints_table : str
        Checkpoints table ID
        
    kmeans_model_path : Input[Model]
        Kmeans model GCS path 
        
    scaler_model_path : Input[Model]
       Standard Scaler GCS path
       
    model_version_number : int
       Model Version Number
       
    model_metric_data : list
       model metric data such as rules, instance count, cltv_segment, cluster_id, concentration and training dataset size.
    """
    
    import numpy as np
    from google.cloud import bigquery
    
    client = bigquery.Client(project=project_id)

    for i in range(len(model_metric_data)):
        model_metric_data[i]['MODEL_PATH']=[f"{kmeans_model_path.path}_{model_version_number}.joblib",
                                                f"{scaler_model_path.path}_{model_version_number}.joblib"]


    errors=client.insert_rows_json(checkpoints_table,model_metric_data)

    if errors == []:
        print("Model Checkpoints Saved")
    else:
        print("Encountered errors while saving Model Checkpoints: {}".format(errors))

@pipeline(name="kmeans-training")            
def pipeline(project_id:str):
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
    
    """
   
    data_check_status=(data_check(project_id,CLTV_PREDICTIONS_TABLE)).set_caching_options(False)
    
    with Condition(data_check_status.outputs["data_check_status"]=="Data found in cltv prediction table, Starting Training", name="model-training-data-check"):
    
        print("Training Started")

        model=(train(project_id,CLTV_PREDICTIONS_TABLE,NUMBER_CLUSTER,KMEANS_KWARGS,SELECTED_FEATURES,CHECKPOINTS_TABLE,CLUSTER_LABELS)).set_caching_options(False)

        print("Training Completed")

        print("Saving Checkpoints to big query")

        (save_model_checkpoints_bq(project_id,CHECKPOINTS_TABLE,model.outputs['kmeans_model_path'],
                                  model.outputs['scaler_model_path'],model.outputs['model_metric_data'],model.outputs['model_version_number'])).set_caching_options(False)