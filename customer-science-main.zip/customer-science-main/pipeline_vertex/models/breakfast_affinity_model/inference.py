################################################################### Module Imports ################################################################################
from models.breakfast_affinity_model.constants import (CHECKPOINTS_TABLE,PREDICTIONS_TABLE,
                                          BASE_IMAGE,GOLDEN_RECORDS_TABLE,DECILE_SELECTION)
import pandas as pd
from kfp.v2.dsl import component,pipeline,Dataset,Output,Input,Model,Condition
from typing import NamedTuple

################################################################## Code Description ################################################################################

"""
The code build using kubeflow pipeline, which helps vertex AI to run inference in a serverless manner.

What is a pipeline?
A pipeline is a description of an ML workflow, including all of the components in the workflow and how they combine in the form of a graph.The pipeline includes the definition of the inputs (parameters) required to run the pipeline and the inputs and outputs of each component.

Components Descriptions: 
-----------------------
    
    - data_check
        since lower envrioments dont have sufficient data to train the CLTV model.
        
        Pseudo Code:
            - Intialize the bigquery client
            - check the data is greater than 1 in golden records table
            - If length of the dataframe is less than equal to 1
                - set Not enough data in Golden Records table, Skipping Inference
            - If length of the dataframe is not less than equal to 1
                - set Data found in Golden Records table, Starting inference
            - Clean the previous prediction
                
            
    - get_model Component:
            This component allows us to get the latest trained model.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Get the latest model version number from checkpoints table using max(model_no)
            - Download the latest model from GCS, and save it in a path where vertex pipeline can access.
            
    - inference Component:
                This components allows us to run inference on the provided batch and computes the required KPI's
            
         Pseudo Code:
            -  Intialize the bigquery client
            -  Intialize breakfast affinity model parameters
            -  Compute the prediction data in BQ
            -  Saving the computed audience to prediction table using pandas gbq
                  
    - Pipeline Component:
                This component will help us to stitch data_check, get_model and inference components together. 
                
        Pseudo Code:
            -  Intialize data_check component
            -  Check the status from data_check component
            -  Intialize get_model component
            -  Intialize inference component 
"""

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/breakfast_affinity_data_check.yaml")
def data_check(project_id:str,golden_records_table:str,prediction_table:str)-> NamedTuple(
    "Outputs",
    [
       ("data_check_status",str)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    golden_records_table : str
        Golden records table ID
        
    prediction_table : str
        Model prediction table

    """
    
    from google.cloud import bigquery,storage
    from datetime import datetime

    client = bigquery.Client(project=project_id)   
    
    df=client.query( f"""select count(*) as length from `{golden_records_table}` """).to_dataframe()
    if int(df['length'].values[0])<=1:
        data_check_status="Not enough data in Golden Records table, Skipping Inference"
    else:
        data_check_status="Data found in Golden Records table, Starting inference"
    
    ################# Deleting audience for the current date if it exists #################
    current_date=datetime.today().strftime('%Y-%m-%d')
    query =f"""DELETE FROM {project_id}.{prediction_table} WHERE CREATED_DATE ={current_date}"""
    client = bigquery.Client(project_id)
    client.query(query)  
    
    return (data_check_status,)



@component(base_image=BASE_IMAGE, output_component_file="./artifacts/breakfast_affinity_get_model.yaml")
def get_model(project_name:str,checkpoints_table:str,bucket_id:str,model_path:Output[Model])-> NamedTuple(
    "Outputs",
    [
       ("model_number",int)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    checkpoints_table : str
        Model checkpoints table
        
    bucket_id : str
        GCS bucket id to save and retrieve the model 
        
    model_path:Output[Model]
        Breakfast Affinity Model GCS path
    """
    
    
    from google.cloud import bigquery,storage

    
    client = bigquery.Client(project=project_name)   
    # Get the latest model
    model_info=client.query(f"""SELECT MODEL_VERSION, MODEL_PATH, FROM `{checkpoints_table}` 
                                          WHERE MODEL_VERSION=(SELECT max(MODEL_VERSION) FROM `{checkpoints_table}`)""").to_dataframe()
    
    model_number=int(model_info['MODEL_VERSION'].values[0])

    bucket=storage.Client(project=project_name).bucket(bucket_id)
    
    path_=model_info['MODEL_PATH'].values[0].split("/")[3:]
    path_='/'.join(map(str, path_))
    blob = bucket.blob(path_)
    print(f"Downloading blob:{blob.name}")

    destination_uri = f"{model_path.path}_{model_number}.pkl"
    print("Destination_path",destination_uri)
    blob.download_to_filename(destination_uri)
    
    return (model_number,)

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/breakfast_affinity_inference.yaml",packages_to_install=["pandas-gbq==0.17.4"])
def inference(project_id:str,model_number:int,model_path:Input[Model],prediction_table:str,golden_records_table:str,decile_selection:list):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    kmeans_model_path:Input[Model]
        Breakfast Affinity model GCS path
    
    prediction_table:str
        Bigquery prediction table ID
    
    golden_records_table:str
         Golden records table ID

    """
    
    import pandas as pd
    import pandas_gbq
    import datetime
    from google.cloud import bigquery
    import numpy as np
    from datetime import datetime
                    
    print("Loading Breakfast Affinity Model Parameters")
    propensity_model_parameters = pd.read_pickle(f"{model_path.path}_{model_number}.pkl")
    
    client = bigquery.Client(project=project_id)
    
    def get_prediction_data() -> pd.DataFrame:
        
        print("creating the linear term")
        feature_list = [x if x != 'Intercept' else '1' for x in propensity_model_parameters.index]
        coeff_list = propensity_model_parameters.to_list()
        linear_term = ' + '.join(['(' + \
                                  str(coeff_list[i]) + \
                                  ') * IFNULL(' + \
                                  feature_list[i] + \
                                  ', 0)' for i in range(len(coeff_list))
                                 ])
    
    
        print("Fetching Data")
        # querying the gold layer
        sql_query = f""" SELECT UUID, SF_CONTACT_ID, {linear_term} AS LINEAR_TERM, 
                          (CASE
                              WHEN FREQ_BKFST = 0 THEN "NON-BREAKFAST"
                            ELSE
                            "BREAKFAST"
                          END
                            ) AS CUSTOMER_TYPE
                        FROM
                          `{golden_records_table}`
                        WHERE
                          FREQ_CATEGORY_BIN <> 'Inactive';"""

        df = client.query(sql_query).to_dataframe()
        
        return df
            
    prediction_data=get_prediction_data()  

    # calculate probability & deciles
    prediction_data['PROB_BREAKFAST'] = np.exp(prediction_data['LINEAR_TERM'])/ (1 + np.exp(prediction_data['LINEAR_TERM']))
    prediction_data['DECILE'] = pd.qcut(prediction_data['PROB_BREAKFAST'], 10, labels = False) + 1

    # create audience
    audience_condition = (prediction_data['CUSTOMER_TYPE'] == 'NON-BREAKFAST') & \
                            (prediction_data['DECILE'].isin([decile_selection]))
    final_columns = ['UUID', 'SF_CONTACT_ID', 'CUSTOMER_TYPE', 'PROB_BREAKFAST']
    cdp_breakfast_audience = prediction_data[final_columns][audience_condition]
    cdp_breakfast_audience['CREATED_DATE'] = datetime.today().strftime('%Y-%m-%d')
        
    # write back to bigquery audience table
    pandas_gbq.to_gbq(cdp_breakfast_audience, 
                destination_table = prediction_table, 
                project_id = project_id, 
                if_exists="append",
                table_schema=[{'name':'CREATED_DATE','type': 'DATE'}]
               )

        
@pipeline(name="breakfast-affinity-inference")            
def pipeline(project_id:str,bucket_id:str):  
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    bucket_id:str
        GCP bucket ID
    
    """

    data_check_status=(data_check(project_id,GOLDEN_RECORDS_TABLE,PREDICTIONS_TABLE)).set_caching_options(False)
    
    with Condition(data_check_status.outputs["data_check_status"]=="Data found in Golden Records table, Starting inference", name="Data-check"):
        
        checkpoints=(get_model(project_id,CHECKPOINTS_TABLE,bucket_id)).set_caching_options(False)

        (inference(project_id,checkpoints.outputs['model_number'],checkpoints.outputs["model_path"],
                   PREDICTIONS_TABLE,GOLDEN_RECORDS_TABLE,DECILE_SELECTION)).set_caching_options(False)