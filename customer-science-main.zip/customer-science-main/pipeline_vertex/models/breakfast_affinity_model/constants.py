BASE_IMAGE="gcr.io/deeplearning-platform-release/sklearn-cpu"
CHECKPOINTS_TABLE = 'cdp_audiences.t_mdl_breakfast_audience_checkpoints'
PREDICTIONS_TABLE = 'cdp_audiences.cdp_breakfast_audience'
GOLDEN_RECORDS_TABLE='gold.t_fact_unified_customer'
DECILE_SELECTION=[10]