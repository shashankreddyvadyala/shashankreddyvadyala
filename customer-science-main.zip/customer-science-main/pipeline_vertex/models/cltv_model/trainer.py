################################################################### Module Imports ################################################################################
from models.cltv_model.constants import BASE_IMAGE,CHECKPOINTS_TABLE,RFM_TABLE,MONETARY_VALUE_THRESHOLD
from kfp.v2.dsl import component,pipeline,Dataset,Output,Input,Model,Condition
from typing import NamedTuple
import pandas as pd

################################################################## Code Description ################################################################################
"""
The code build using kubeflow pipeline, which helps vertex AI to run training in a serverless manner.

What is a pipeline?
A pipeline is a description of an ML workflow, including all of the components in the workflow and how they combine in the form of a graph.The pipeline includes the definition of the inputs (parameters) required to run the pipeline and the inputs and outputs of each component.

Components Descriptions: 
-----------------------
    
    - data_check
        since lower envrioments dont have sufficient data to train the CLTV model.
        
        Pseudo Code:
            - Intialize the bigquery client
            - check the frequency and monetary value are greater than 1 in RFM table
            - If length of the dataframe is less than equal to 0
                - set No frequency in the data
            - If length of the dataframe is not less than equal to 0
                - set RFM Data Check Completed, Starting Training
            - Get the latest model number
                
            
    - Train pnf Component:
            This component allows us to train the pareto nbd model, it uses sklearn base image, upon base image we are installing lifetime package for cltv computation.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Load the data using get_train_data() from RFM table.
            - Intialize pareto nbd from liftetime package.
            - Train pareto nbd model                    
            - Save the model in GCS
            - Compute RMSE
    
    - Train ggf(Gamma Gamma Model) Component:
            This component allows us to train the gamma gamma model, it uses sklearn base image, upon base image we are installing lifetime package for cltv computation.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Load the data using get_train_data() from RFM table.
            - Intialize  gamma gamma model from liftetime package.
            - Train gamma gamma model                    
            - Save the model in GCS
            - Compute RMSE
            
    - Save Checkpoints Component:
                This components allows us to checkpoint our trained model in BQ under checkpoints table.
            
         Pseudo Code:
            -  Intialize the bigquery client
            -  prepare the data in json format
            -  using insert_rows_json() to save the checkpoints in BQ table.
            -  If errors:
                  Raise "Encountered erros while processing"
                  
    - Pipeline Component:
                This component will help us to stitch data_check, train_pnf, train_ggf and save checkpoints components together. 
                
        Pseudo Code:
            -  Intialize data_check component
            -  Check the status from data_check component
            -  Intialize the train_pnf component
            -  Intialize the train_ggf component
            -  Intialize the Save Checkpoints component
"""

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_data_check.yaml")
def data_check(project_id:str,rfm_table:str,checkpoints_table:str)-> NamedTuple(
    "Outputs",   
    [
       ("data_check_status",str), ("model_version_number", int)
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    rfm_table : str
        RFM table ID
        
    checkpoints_table : str
        Model checkpoints table

    """
    
    
    from google.cloud import bigquery,storage
    import pandas as pd
    import datetime

    client = bigquery.Client(project=project_id)   
    
    df=client.query( f""" SELECT FREQUENCY,MONETARY_VALUE,CUSTOMER_ID FROM `{rfm_table}`
                        WHERE CREATED_DATE=(SELECT MAX(CREATED_DATE) FROM `{rfm_table}`) AND FREQUENCY > 0 AND MONETARY_VALUE >0
                        """).to_dataframe()
    
    if len(df)<=0:
        data_check_status="No frequency in the data"
    else:
        data_check_status="RFM Data Check Completed, Starting Training"
        
    # Model Version, Get the latest model Number
    model_version_number=client.query(f"SELECT max(MODEL_NO) FROM `{checkpoints_table}`").to_dataframe()
    if model_version_number.isna().values[0]:
        model_version_number=1
    else:
        model_version_number+=1
        model_version_number=int(model_version_number.values[0][0])
    
    return (data_check_status,model_version_number,)


@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_pnf_trainer.yaml",packages_to_install=["Lifetimes==0.11.3"])
def train_pnf(project_id:str,model_version_number:int,rfm_table:str,pnf_model:Output[Model])-> NamedTuple(
    "Outputs",
    [
        ("rmse", float),
        ("pnf_params", dict),
        ("train_dataset_size", int),
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    rfm_table : str
        RFM table ID
        
    model_version_number : int
        Model Version Number
        
    pnf_model : Output[Model]
        Saved GCS Model Path

    """
    
    from lifetimes import ParetoNBDFitter,GammaGammaFitter
    from google.cloud import bigquery,storage
    import numpy as np
    
    print("Training Pareto NBD Model")
    
    def get_train_data(client: bigquery.Client,rfm_table:str):
        print("Fetching Training Data For Pareto NBD Model")
        
        sql_query = (f""" SELECT FREQUENCY,RECENCY,T,Count(CUSTOMER_ID) as SEGMENTS FROM `{rfm_table}`
                    WHERE CREATED_DATE=(SELECT MAX(CREATED_DATE) FROM `{rfm_table}`)
                    GROUP BY FREQUENCY,RECENCY,T """)

        df = client.query(sql_query).to_dataframe().set_index('SEGMENTS')

        return df
    
    
    client = bigquery.Client(project=project_id)
    train_data=get_train_data(client,rfm_table)
    
    pnf = ParetoNBDFitter(penalizer_coef=0.0)
    
    pnf.fit(train_data['FREQUENCY'], train_data['RECENCY'], train_data['T'],weights=train_data.index.tolist())
    
    #Computing RMSE
    simulated_data = pnf.generate_new_data(size=pnf.data.shape[0])
    rmse=np.sqrt(np.mean(np.square(train_data['FREQUENCY'] - simulated_data['frequency'])))

    pnf_path=f"{pnf_model.path}_{model_version_number}.pkl"
    
    pnf.save_model(pnf_path, save_data=False, save_generate_data_method=False)

    return (rmse,eval(pnf.params_.to_json()),int(train_data.index.get_level_values('SEGMENTS').values.sum()))

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_ggf_trainer.yaml",packages_to_install=["Lifetimes==0.11.3"])
def train_ggf(project_id:str,model_version_number:int,rfm_table:str,monetary_value_threshold:int,ggf_model:Output[Model])-> NamedTuple(    
    "Outputs",
    [
        ("ggf_params", dict),
    ],):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    rfm_table : str
        RFM table ID
        
    model_version_number : int
        Model Version Number
        
    ggf_model : Output[Model]
       Saved GCS Model Path

    """
    
    from lifetimes import ParetoNBDFitter,GammaGammaFitter
    from google.cloud import bigquery,storage
    import numpy as np
    
    print("Training GAMMA GAMMA Model")
    
    def get_train_data(client: bigquery.Client,rfm_table:str):
        print("Fetching Training Data For GAMMA GAMMA Model")

        sql_query = (f""" SELECT FREQUENCY,MONETARY_VALUE,CUSTOMER_ID FROM `{rfm_table}`
                    WHERE CREATED_DATE=(SELECT MAX(CREATED_DATE) FROM `{rfm_table}`) AND FREQUENCY > 0 AND MONETARY_VALUE >0 AND MONETARY_VALUE <={monetary_value_threshold}
                    """)

        df = client.query(sql_query).to_dataframe()

        return df
    
    
    client = bigquery.Client(project=project_id)
    train_data=get_train_data(client,rfm_table)
    
    ggf = GammaGammaFitter(penalizer_coef=0)
    
    ggf.fit(train_data['FREQUENCY'],train_data['MONETARY_VALUE'])
        
    ggf_path=f"{ggf_model.path}_{model_version_number}.pkl"
    
    ggf.save_model(ggf_path, save_data=False, save_generate_data_method=False)

    return (eval(ggf.params_.to_json()),)
        
@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_save_checkpoints.yaml")
def save_model_checkpoints_bq(project_id:str,checkpoints_table:str,rmse:float,pnf_fitter_param:dict,
                              ggf_fitter_param:dict,pnf_path:Input[Model],ggf_path:Input[Model],model_version_number:int,train_dataset_size:int):
    
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    CHECKPOINTS_TABLE : str
        Checkpoints table ID
        
    rmse : float
        Root Mean Squared Error
     
    pnf_fitter_param : dict
        Pareto NBD model hyper parameters
        
    ggf_fitter_param : dict
        Gamma Gamma model hyper parameters
        
    pnf_model : Input[Model]
        Saved GCS Model Path
        
    ggf_model : Input[Model]
       Saved GCS Model Path
       
    model_version_number : int
       Model Version Number
       
    train_dataset_size : int
       Length of the training dataset
    """
    
    import numpy as np
    import datetime
    from google.cloud import bigquery,storage

    client = bigquery.Client(project=project_id)

    #Appending model params to model checkpoints table
    f = '%Y-%m-%d %H:%M:%S'
    timestamp_now = datetime.datetime.now().strftime(f)

    #Getting the gcs model paths
    model_path=[f"{pnf_path.path}_{model_version_number}.pkl",
                f"{ggf_path.path}_{model_version_number}.pkl"]

    
    data=[{"CREATED_TMS":timestamp_now,'PARETO_NBD_R':pnf_fitter_param['r'],'PARETO_NBD_ALPHA':pnf_fitter_param['alpha'],'PARETO_NBD_S':pnf_fitter_param['s'],'PARETO_NBD_BETA':pnf_fitter_param['beta'],
       'GAMMA_GAMMA_P':ggf_fitter_param['p'],'GAMMA_GAMMA_Q':ggf_fitter_param['q'],'GAMMA_GAMMA_V':ggf_fitter_param['v'],'RMSE':rmse,
       'MODEL_NO':model_version_number,'TRAINING_DATASET_SIZE':train_dataset_size,'MODEL_PATH':model_path}]

    errors=client.insert_rows_json(checkpoints_table,data)

    if errors == []:
        print("Model Checkpoints Saved")
    else:
        print("Encountered errors while saving Model Checkpoints: {}".format(errors))
            
        
            
@pipeline(name="cltv-training-lifetime")            
def pipeline(project_id:str): 
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
    
    """
    
    print("Training Data Check")
    
    data_check_status=(data_check(project_id,RFM_TABLE,CHECKPOINTS_TABLE)).set_caching_options(False)
    
    with Condition(data_check_status.outputs["data_check_status"]=="RFM Data Check Completed, Starting Training", name="model-training-data-check"):

        print("Training Started")

        pnf_model=(train_pnf(project_id,data_check_status.outputs["model_version_number"],RFM_TABLE)).set_caching_options(False)

        ggf_model=(train_ggf(project_id,data_check_status.outputs["model_version_number"],RFM_TABLE,MONETARY_VALUE_THRESHOLD)).set_caching_options(False)

        print("Training Completed")

        print("Saving Checkpoints to big query")

        (save_model_checkpoints_bq(project_id,CHECKPOINTS_TABLE,pnf_model.outputs['rmse'],pnf_model.outputs['pnf_params'],
                                  ggf_model.outputs['ggf_params'],pnf_model.outputs['pnf_model'],ggf_model.outputs['ggf_model'],
                                   data_check_status.outputs['model_version_number'],pnf_model.outputs['train_dataset_size'])).set_caching_options(False)