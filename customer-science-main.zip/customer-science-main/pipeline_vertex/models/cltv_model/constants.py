RFM_TABLE='curated.t_mdl_rfm'
PREDICTIONS_TABLE='curated.t_mdl_cltv_predictions'
CHECKPOINTS_TABLE='curated.t_mdl_cltv_checkpoints'
BATCH_SIZE=1000000
BASE_IMAGE="gcr.io/deeplearning-platform-release/sklearn-cpu"
CLTV_PERIOD=12 #months
CLTV_EXPECTED_TRIPS_PERIOD=365 #days
PREDICTION_TABLE_SCHEMA=[
    
    {'name': 'CUSTOMER_ID', 'type': 'INTEGER'},
    {'name': 'CLTV_12MO', 'type': 'FLOAT'},
    {'name': 'ALIVE_PROB', 'type': 'FLOAT'},
    {'name': 'FUTURE_12MO_PURCHASE', 'type': 'FLOAT'},
    {'name': 'CREATED_TMS', 'type': 'STRING'}

]
MONETARY_VALUE_THRESHOLD=1000
