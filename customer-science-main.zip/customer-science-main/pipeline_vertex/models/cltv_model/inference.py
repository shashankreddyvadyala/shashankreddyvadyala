################################################################### Module Imports ################################################################################
import pandas as pd
from models.cltv_model.constants import (BASE_IMAGE, CHECKPOINTS_TABLE,
                                         RFM_TABLE,BATCH_SIZE,PREDICTIONS_TABLE,
                                        CLTV_PERIOD,CLTV_EXPECTED_TRIPS_PERIOD,PREDICTION_TABLE_SCHEMA)

from kfp.v2.dsl import component,pipeline,Dataset,Output,Input,Model,Condition,ParallelFor
from typing import NamedTuple,List,Dict

################################################################## Code Description ################################################################################
"""
The code build using kubeflow pipeline, which helps vertex AI to run inference in a serverless manner.

What is a pipeline?
A pipeline is a description of an ML workflow, including all of the components in the workflow and how they combine in the form of a graph.The pipeline includes the definition of the inputs (parameters) required to run the pipeline and the inputs and outputs of each component.

Components Descriptions: 
-----------------------
    
    - data_check
        since lower envrioments dont have sufficient data to train the CLTV model.
        
        Pseudo Code:
            - Intialize the bigquery client
            - check the frequency is greater than 1 in RFM table
            - If length of the dataframe is less than equal to 0
                - set No frequency in the data, Skipping Inference
            - If length of the dataframe is not less than equal to 0
                - set RFM Data Check Completed, Starting Inference
            - Clean the previous prediction
                
            
    - get_model Component:
            This component allows us to get the latest trained model.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Get the latest model version number from checkpoints table using max(model_no)
            - Download the latest model from GCS, and save it in a path where vertex pipeline can access.
    
    - prepare_batches Component:
            This component allows us to prepare batches for batchwise predictions.
            
        Pseudo Code:
            - Intialize the bigquery client
            - Get total number of distinct customers from RFM table
            - Get the batch size from constants
            - Loop through the total number of distinct customers
            - Create a dictionary and append the limit and offset to against a batch
            
    - inference Component:
                This components allows us to run inference on the provided batch and computes the required KPI's
            
         Pseudo Code:
            -  Intialize the bigquery client
            -  Intialize pareto-nbd and gamma gamma model
            -  Get the batch data
            -  compute kpi's
                - CLTV_12MO
                - FUTURE_12MO_PURCHASE
                - ALIVE_PROB
            - Saving the computed KPI's to prediction table using pandas gbq
                  
    - Pipeline Component:
                This component will help us to stitch data_check, get_model, prepare_batches and inference components together. 
                
        Pseudo Code:
            -  Intialize data_check component
            -  Check the status from data_check component
            -  Intialize get_model component
            -  Intialize prepare_batches component
            -  Set parallelfor to run multiple batch prediction
                -Intialize inference component 
"""



@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_data_check.yaml",packages_to_install=["pandas-gbq==0.17.4"])
def data_check(project_id:str,rfm_table:str,prediction_table:str,prediction_table_schema:list)-> NamedTuple(
    "Outputs",
    [
       ("data_check_status",str)
    ],):
        
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    rfm_table : str
        RFM table ID
        
    prediction_table : str
        Model prediction table
        
    prediction_table_schema : list
        Schema for model prediction table

    """
    
    from google.cloud import bigquery,storage
    import pandas as pd
    import pandas_gbq
    import datetime

    client = bigquery.Client(project=project_id)   
    
    df=client.query( f"""select count(*) as length from  `{rfm_table}` 
                          WHERE CREATED_DATE=(SELECT MAX(CREATED_DATE) FROM `{rfm_table}`) AND FREQUENCY>0""").to_dataframe()
    if df['length'].values[0]<=0:
        data_check_status="No frequency in the data, Skipping Inference"
    else:
        data_check_status="RFM Data Check Completed, Starting inference"
        
    ################# Cleaning previous prediction #################
    df=pd.DataFrame(columns=['CUSTOMER_ID','CLTV_12MO','FUTURE_12MO_PURCHASE','ALIVE_PROB','CREATED_TMS'])
    pandas_gbq.to_gbq(df, prediction_table, project_id=project_id,if_exists="replace",table_schema=prediction_table_schema)

    return (data_check_status,)
    
    
@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_get_model.yaml")
def get_model(project_id:str,checkpoints_table:str,bucket_id:str,
                          pnf_model:Output[Model],ggf_model:Output[Model])-> NamedTuple(
    "Outputs",
    [
       ("model_number",int)
    ],):
            
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    checkpoints_table : str
        Model checkpoints table
        
    bucket_id : str
        GCS bucket id to save and retrieve the model 
        
    pnf_model:Output[Model]
        pareto nbd GCS path
    
    ggf_model:Output[Model]
        Gamma Gamma GCS path

    """
    
    from google.cloud import bigquery,storage

    
    client = bigquery.Client(project=project_id)   
    # Get the latest model
    model_info=client.query(f"""SELECT MODEL_NO, MODEL_PATH FROM `{checkpoints_table}` 
                                          WHERE MODEL_NO=(SELECT max(MODEL_NO) FROM `{checkpoints_table}`)""").to_dataframe()
    
    model_number=int(model_info['MODEL_NO'].values[0])

    bucket=storage.Client(project=project_id).bucket(bucket_id)
    
    path_=model_info['MODEL_PATH'].values[0][0].split("/")[3:]
    path_='/'.join(map(str, path_))
    blob = bucket.blob(path_)
    print(f"Downloading blob:{blob.name}")

    destination_uri = f"{pnf_model.path}_{model_number}.pkl"
    print("Destination_path",destination_uri)
    blob.download_to_filename(destination_uri)
    
    path_=model_info['MODEL_PATH'].values[0][1].split("/")[3:]
    path_='/'.join(map(str, path_))
    blob = bucket.blob(path_)
    print(f"Downloading blob:{blob.name}")
    destination_uri = f"{ggf_model.path}_{model_number}.pkl"
    print("Destination_path",destination_uri)
    blob.download_to_filename(destination_uri)
    
    return (model_number,)

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_get_batches.yaml")
def prepare_batches(project_id:str,batch_size:int,rfm_table:str)-> NamedTuple(
    "Outputs",
    [
       ("batches",List[Dict])
    ],):
    
                
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    batch_size : int
        Number rows in a batch
        
    rfm_table : str
        Bigquery RFM table ID.

    """

    print("Preparing Data in Batches")
    
    from google.cloud import bigquery
    
    client = bigquery.Client(project=project_id)   

    total_rows=client.query(f"SELECT count(distinct CUSTOMER_ID) as total_row  FROM `{rfm_table}`").to_dataframe().values[0][0]

    batches=[]

    for index,offset  in enumerate(range(0,total_rows,batch_size)):
        batches.append({f"batch{index}":{'limit':batch_size,'offset':offset}})
        
    return (batches,)

@component(base_image=BASE_IMAGE, output_component_file="./artifacts/cltv_inference.yaml",packages_to_install=["Lifetimes==0.11.3","pandas-gbq==0.17.4"])
def inference(project_id:str,batch:dict,model_no:int,pnf_model:Input[Model],
              ggf_model:Input[Model],prediction_table:str,cltv_period:int,
              cltv_expected_trips_period:int,rfm_table:str):               
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    batch : dict
        The batch to run inference
        
    model_no : int
        Model version number.
        
    pnf_model:Input[Model]
        Pareto NBD model GCS path
    
    ggf_model:Input[Model]
        Gamma Gamma model GCS path
    
    prediction_table:str
        Bigquery prediction table ID
    
    cltv_period:int
        Constant used in the model to calculate CLTV. The supplied input value to be in unit of months
    
    cltv_expected_trips_period:int
        Constant used in the model to predict expected future trips. The supplied input value to be in unit of days
    
    rfm_table:str
        Bigquery RFM table ID

    """
    from lifetimes import ParetoNBDFitter,GammaGammaFitter
    import numpy as np
    from google.cloud import bigquery
    import pandas as pd
    import pandas_gbq
    from google.cloud import bigquery
    import datetime

    pnf = ParetoNBDFitter(penalizer_coef=0.0)
    ggf = GammaGammaFitter(penalizer_coef=0)
    print("Loading Pareto/NBD Model")
    pnf.load_model(f"{pnf_model.path}_{model_no}.pkl")
    print("Loading Gamma-Gamma Model")
    ggf.load_model(f"{ggf_model.path}_{model_no}.pkl")

    client = bigquery.Client(project=project_id)
        
    def get_data_batch(limit:int, offset:int) -> pd.DataFrame:

        print("Fetching Data")

        sql_query = (f"select * from {rfm_table}  WHERE CREATED_DATE=(SELECT MAX(CREATED_DATE) FROM `{rfm_table}`) limit {limit} offset {offset}")

        df = client.query(sql_query).to_dataframe().set_index('CUSTOMER_ID')

        return df
            
    def compute_kpi(data:pd.DataFrame) -> pd.DataFrame:
        
        #Generating CLTV Values
        cltv_values=ggf.customer_lifetime_value(
                        pnf, #the model to use to predict the number of future transactions
                        data['FREQUENCY'],
                        data['RECENCY'],
                        data['T'],
                        data['MONETARY_VALUE'],
                        time=cltv_period, # months
                        discount_rate=0.00) 
        cltv_values.name="CLTV_12MO"
        
        """Generating future expected number of purchase, Here t is in periods which is measured in dates"""
        cltv_future_purchase=pnf.conditional_expected_number_of_purchases_up_to_time(cltv_expected_trips_period,data['FREQUENCY'], data['RECENCY'], data['T'])
        cltv_future_purchase.name="FUTURE_12MO_PURCHASE"
        
        
        """Generating conditional probabilty of being alive,It calculates the probability of a customer being currently alive or not"""
        cltv_prob_alive=pnf.conditional_probability_alive(data['FREQUENCY'], data['RECENCY'], data['T'])
        cltv_prob_alive.name="ALIVE_PROB"
        
        return pd.concat([cltv_values,cltv_prob_alive,cltv_future_purchase],axis=1)

    def save_metric_bq(data:pd.DataFrame):
        print("Saving computed KPI's to bigquery")
        
        table_id=f"{prediction_table}"
        pandas_gbq.to_gbq(data.round(2).reset_index(), table_id, project_id=project_id,if_exists="append")
    
    def batch_prediction():  
        for key,value in batch.items():

            #Loading the data
            df=get_data_batch(value['limit'],value['offset'])  

            #computing KPI's for next 12 months
            df=compute_kpi(df)

            #adding timestamp to the dataframe
            f = '%Y-%m-%d %H:%M:%S'
            timestamp_now = datetime.datetime.now().strftime(f)
            df['CREATED_TMS']=timestamp_now
            save_metric_bq(df)
        print("Batch Prediction Completed")
        
    batch_prediction()



@pipeline(name="cltv-inference-lifetime")            
def pipeline(project_id:str,bucket_id:str):
    """
    Parameters
    ----------
    project_id : str
        GCP project ID 
        
    bucket_id:str
        GCP bucket ID
    
    """
    
    data_check_status=(data_check(project_id,RFM_TABLE,PREDICTIONS_TABLE,PREDICTION_TABLE_SCHEMA)).set_caching_options(False)
    
    with Condition(data_check_status.outputs["data_check_status"]=="RFM Data Check Completed, Starting inference", name="Data-check"):
        checkpoints=(get_model(project_id,CHECKPOINTS_TABLE,bucket_id)).set_caching_options(False)

        batches=(prepare_batches(project_id,BATCH_SIZE,RFM_TABLE)).set_caching_options(False)
        with ParallelFor(batches.outputs['batches']) as batch:
            
            (inference(project_id,batch,checkpoints.outputs['model_number'],checkpoints.outputs["pnf_model"],
                       checkpoints.outputs["ggf_model"],PREDICTIONS_TABLE,CLTV_PERIOD,CLTV_EXPECTED_TRIPS_PERIOD,RFM_TABLE)).set_caching_options(False)

